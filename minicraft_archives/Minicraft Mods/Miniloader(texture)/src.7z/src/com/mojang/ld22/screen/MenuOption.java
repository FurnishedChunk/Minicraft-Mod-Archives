package com.mojang.ld22.screen;

public abstract class MenuOption {
	
	public String text = "";
	protected Object o;
	public Menu parent;
	
	public MenuOption(String text, Object o) {
		this.text = text;
		this.o = o;
	}
	
	public MenuOption(String text) {
		this.text = text;
	}
	
	public abstract void selected();

}
