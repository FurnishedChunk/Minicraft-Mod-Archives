package com.mojang.ld22;

import java.awt.event.KeyEvent;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.net.Socket;
import java.net.URISyntaxException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Random;
import java.util.zip.*;

import com.mojang.ld22.crafting.Crafting;
import com.mojang.ld22.crafting.Recipe;
import com.mojang.ld22.entity.Creature;
import com.mojang.ld22.gfx.ColorSet;
import com.mojang.ld22.level.levelgen.Default;
import com.mojang.ld22.level.levelgen.LevelGen;
import com.mojang.ld22.nbt.CompressedStreamTools;
import com.mojang.ld22.nbt.NBTCompound;
import com.mojang.ld22.screen.Menu;
import com.mojang.ld22.screen.MenuOption;
import com.mojang.ld22.screen.ModMenu;

public class MiniLoader {
	
	private static ArrayList<BaseMod> modList = new ArrayList<BaseMod>();
	@SuppressWarnings("rawtypes")
	private static ArrayList<Class> Mobs = new ArrayList<Class>();
	
	private static ArrayList<MenuOption> titleOptions = new ArrayList<MenuOption>();
	public static ArrayList<MenuOption> modOptions = new ArrayList<MenuOption>();
	public static ArrayList<MenuOption> texturePacks = new ArrayList<MenuOption>();
	public static ArrayList<LevelGen> levelGens = new ArrayList<LevelGen>();
	
	public static Game game;
	public static boolean online = false;
	public static boolean couldConnect = true;
	public static String playerName;
	private static Socket socket;
	
	public static void addAnvilRecipe(Recipe i) {
		Crafting.anvilRecipes.add(i);
	}
	
    public static void addFurnaceRecipe(Recipe i) {
		Crafting.furnaceRecipes.add(i);
	}

	public static void addLevelGenerator(LevelGen levelGen) {
		levelGens.add(levelGen);
	}
    
	@SuppressWarnings("rawtypes")
	public static void addMob(Class mob) {
		Mobs.add(mob);
	}
	
	@SuppressWarnings({ "rawtypes" })
	private static void addMod(ClassLoader classloader, String s1) {
		try {
			Package package1 = (com.mojang.ld22.MiniLoader.class).getPackage();
			if (package1 != null) {
				s1 = (new StringBuilder(String.valueOf(package1.getName()))).append(".").append(s1).toString();
				}
			Class class1 = classloader.loadClass(s1);
			if (!(com.mojang.ld22.BaseMod.class).isAssignableFrom(class1)) {
				return;
			}
            BaseMod basemod = (BaseMod)class1.newInstance();
            if (basemod != null) {
            	modList.add(basemod);
            	System.out.println((new StringBuilder("Mod Initialized: ")).append(basemod.toString()).toString());
            }
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
	}
	
	public static void addModOption(MenuOption option) {
		modOptions.add(option);
	}
	
	public static void addOvenRecipe(Recipe i) {
		Crafting.ovenRecipes.add(i);
	}
	
	@SuppressWarnings({ "rawtypes" })
	private static void addTex(ClassLoader classloader, String s1) {
		try {
			Package package1 = (com.mojang.ld22.MiniLoader.class).getPackage();
			if (package1 != null) {
				s1 = (new StringBuilder(String.valueOf(package1.getName()))).append(".").append(s1).toString();
				}
			Class class1 = classloader.loadClass(s1);
			if (!(com.mojang.ld22.BaseTex.class).isAssignableFrom(class1)) {
				return;
			}
            BaseTex basetex = (BaseTex)class1.newInstance();
            if (basetex != null) {
            	texturePacks.add(new MenuOption(basetex.Name(), basetex) {
					public void selected() {
						((BaseTex) o).load();
					}
            	});
            	System.out.println((new StringBuilder("Texture Pack added: ")).append(basetex.Name()).toString());

            	}
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
	}
	
	public static void addTitleOption(MenuOption option) {
		titleOptions.add(option);
	}
	
	public static void addWorkbenchRecipe(Recipe i) {
		Crafting.workbenchRecipes.add(i);
	}

	public static Game getGame() {
		return game;
	}
	
	public static ArrayList<MenuOption> getTitleOptions(Menu parent) {
		for (int i = 0; i < titleOptions.size(); i++) {
			titleOptions.get(i).parent = parent;
		}
		return titleOptions;
	}
	
	public static void init(Game g) {
		game = g;
		new ColorSet().load();
		Mobs.add(com.mojang.ld22.entity.Slime.class);
		Mobs.add(com.mojang.ld22.entity.Zombie.class);
		levelGens.add(new Default());
		if (online) {
			try {
				socket = new Socket("serv.r00t.la", 6464);
				NBTCompound send = new NBTCompound();
				send.setInteger("id", 1);
				send.setString("name", playerName);
				send(send, socket.getOutputStream());
			} catch (IOException e) {
				couldConnect = false;
			}
		} else {
			new File("saves").mkdir();
			try {
				File file = new File((com.mojang.ld22.MiniLoader.class).getProtectionDomain().getCodeSource().getLocation().toURI());
				readFromClassPath(file);
			} catch (URISyntaxException | IOException e) {
				e.printStackTrace();
			}
			
			for (int i = 0; i < modList.size(); i++) {
				modList.get(i).load();
			}
		}
	}
	
	public static void keyPress(KeyEvent ke, boolean pressed) {
		for (int i = 0; i < modList.size(); i++) {
			modList.get(i).keyPress(ke, pressed);
		}
	}
	
	public static NBTCompound loadFromFile(File file) {
		try {
			return CompressedStreamTools.readCompressed(new FileInputStream(file));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private static void readFromClassPath(File file) throws FileNotFoundException, IOException
    {
        ClassLoader classloader = (com.mojang.ld22.MiniLoader.class).getClassLoader();
        if (file.isFile() && (file.getName().endsWith(".jar") || file.getName().endsWith(".zip")))
        {
            ZipInputStream zipinputstream = new ZipInputStream(new FileInputStream(file));
            do
            {
                ZipEntry zipentry = zipinputstream.getNextEntry();
                if (zipentry == null)
                {
                    break;
                }
                String s1 = zipentry.getName();
                if (!zipentry.isDirectory() && s1.startsWith("mod_") && s1.endsWith(".class"))
                {
                    addMod(classloader, s1.split(".class")[0]);
                }
                if (!zipentry.isDirectory() && s1.startsWith("com/mojang/ld22/mod_") && s1.endsWith(".class"))
                {
                    addMod(classloader, s1.split(".class")[0].split("com/mojang/ld22/")[1]);
                }
                if (!zipentry.isDirectory() && s1.startsWith("tex_") && s1.endsWith(".class"))
                {
                    addTex(classloader, s1.split(".class")[0]);
                }
                if (!zipentry.isDirectory() && s1.startsWith("com/mojang/ld22/tex_") && s1.endsWith(".class"))
                {
                    addTex(classloader, s1.split(".class")[0].split("com/mojang/ld22/")[1]);
                }
            }
            while (true);
            zipinputstream.close();
        }
        else if (file.isDirectory())
        {
            Package package1 = (com.mojang.ld22.MiniLoader.class).getPackage();
            if (package1 != null)
            {
                String s = package1.getName().replace('.', File.separatorChar);
                file = new File(file, s);
            }
            File afile[] = file.listFiles();
            if (afile != null)
            {
                for (int i = 0; i < afile.length; i++)
                {
                    String s2 = afile[i].getName();
                    if (afile[i].isFile() && s2.startsWith("mod_") && s2.endsWith(".class"))
                    {
                        addMod(classloader, s2.split(".class")[0]);
                    }
                    if (afile[i].isFile() && s2.startsWith("tex_") && s2.endsWith(".class"))
                    {
                        addTex(classloader, s2.split(".class")[0]);
                    }
                }
            }
        }
    }
	
	public static void saveToFile(File file, NBTCompound tag) {
		try {
			CompressedStreamTools.writeCompressed(tag, new FileOutputStream(file));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static Creature spawnRandom(Random random, int lvl, int depth) {
		int i = random.nextInt(Mobs.size());
			try {
				return (Creature) Mobs.get(i).getConstructors()[0].newInstance(lvl);
			} catch (InstantiationException | IllegalAccessException
					| InvocationTargetException | SecurityException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				try {
					return (Creature) Mobs.get(i).getConstructors()[1].newInstance(lvl);
				} catch (InstantiationException | IllegalAccessException
						| IllegalArgumentException | InvocationTargetException
						| SecurityException e1) {
					e1.printStackTrace();
				}
			}
			return null;
	}
	
	public static void tick() {
		if (game.input.mod.clicked) {
			game.setMenu(new ModMenu(null));
		}
		for (int i = 0; i < modList.size(); i++) {
			modList.get(i).tick();
		}
	}
	
	public static void save() {
		if (online) {
			try {
				NBTCompound send = new NBTCompound();
				send = game.save();
				send.setInteger("id", 2);
				send(send, socket.getOutputStream());
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			saveToFile(new File("saves/" + Long.toString(System.currentTimeMillis()) + ".sav"), game.save());
		}
	}
	
	public static NBTCompound loadFromServer() {
		try {
			do {
				NBTCompound send = new NBTCompound();
				send.setInteger("id", 3);
				send(send, socket.getOutputStream());
				
				NBTCompound packet = getNextPacket(socket.getInputStream());
				if (packet.getInteger("id") == 100) {
					return packet;
				}
				if (packet.getInteger("id") == 111) {
					return null;
				}
			} while (true);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private static void send(NBTCompound nbt, OutputStream out) throws IOException {
		byte[] a = CompressedStreamTools.compress(nbt);
		ByteBuffer length = ByteBuffer.allocate(4).putInt(a.length);
		
		out.write(length.array());
		out.write(ByteBuffer.wrap(a).order(ByteOrder.LITTLE_ENDIAN).array());
	}
	
	private static NBTCompound getNextPacket(InputStream in) {
		DataInputStream read = new DataInputStream(in);
		try {
		byte[] a = new byte[4];
		read.read(a, 0, 4);
		ByteBuffer a1 = ByteBuffer.wrap(a);
		int length = a1.getInt();

		byte[] b = new byte[length];
		for (int i = 0; i < length; i++) {
		b[i] = read.readByte();
		}
		b = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).array();
		
		NBTCompound nbt = CompressedStreamTools.decompress(b);
		if (nbt != null) {
			return nbt;
		}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static void stop() {
		NBTCompound send = new NBTCompound();
		send.setInteger("id", 4);
		try {
			send(send, socket.getOutputStream());
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
