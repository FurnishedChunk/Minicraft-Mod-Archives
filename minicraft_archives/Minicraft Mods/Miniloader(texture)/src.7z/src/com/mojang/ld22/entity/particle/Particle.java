package com.mojang.ld22.entity.particle;

import com.mojang.ld22.entity.Entity;

public abstract class Particle extends Entity {
	
}
