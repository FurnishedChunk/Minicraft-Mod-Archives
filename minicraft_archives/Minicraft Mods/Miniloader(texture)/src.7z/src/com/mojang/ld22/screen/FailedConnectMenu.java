package com.mojang.ld22.screen;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;

public class FailedConnectMenu extends Menu {

	public FailedConnectMenu(Menu parent) {
		super(parent);
	}
	
	public void tick() {
		if (input.attack.clicked || input.menu.clicked) {
			kill();
		}
	}

	public void render(Screen screen) {
		screen.clear(0);

		Font.draw("Connection Failed", screen, 2 * 8 + 4, 5 * 8, Color.colors.get("MenuSelectedText"));
	}

}
