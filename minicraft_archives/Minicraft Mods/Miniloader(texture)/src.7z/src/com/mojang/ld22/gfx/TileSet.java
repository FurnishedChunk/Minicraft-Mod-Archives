package com.mojang.ld22.gfx;

import com.mojang.ld22.level.Level;

public class TileSet {
	
	public int cactus(Level level) {
		return Color.get(20, 40, 50, level.sandColor);
	}
	
	public int cloudCactus(Level level) {
		return Color.get(444, 111, 333, 555);
	}
	
	public int cloud(boolean trans, Level level) {
		if (trans) {
			return Color.get(333, 444, 555, -1);
		} else {
			return Color.get(444, 444, 555, 555);
		}
	}
	
	public int dirt(Level level) {
		return Color.get(level.dirtColor, level.dirtColor, level.dirtColor - 111, level.dirtColor - 111);
	}
	
	public int farm(Level level) {
		return Color.get(level.dirtColor - 121, level.dirtColor - 11, level.dirtColor, level.dirtColor + 111);
	}
	
	public int flower(Level level) {
		return Color.get(10, level.grassColor, 555, 440);
	}
	
	public int grass(boolean trans, Level level) {
		if (trans) {
			return Color.get(level.grassColor - 111, level.grassColor, level.grassColor + 111, level.dirtColor);
		} else {
			return Color.get(level.grassColor, level.grassColor, level.grassColor + 111, level.grassColor + 111);
		}
	}
	
	public int hardRock(boolean trans, Level level) {
		if (trans) {
			return Color.get(001, 334, 445, level.dirtColor);
		} else {
			return Color.get(334, 334, 223, 223);
		}
	}
	
	public int hole(boolean trans, boolean sand, Level level) {
		if (trans) {
			if (sand) {
				return Color.get(3, 111, level.sandColor - 110, level.sandColor);
			} else {
				return Color.get(3, 111, level.dirtColor - 111, level.dirtColor);
			}
		} else {
			return Color.get(111, 111, 110, 110);
		}
	}
	
	public int lava(boolean trans, boolean sand, Level level) {
		if (trans) {
			if (sand) {
				return Color.get(3, 500, level.sandColor - 110, level.sandColor);
			} else {
				return Color.get(3, 500, level.dirtColor - 111, level.dirtColor);
			}
		} else {
			return Color.get(500, 500, 520, 550);
		}
	}
	
	public int ore(Level level, int col) {
		return (col & 0xffffff00) + Color.get(level.dirtColor);
	}
	
	public int rock(boolean trans, Level level) {
		if (trans) {
			return Color.get(111, 444, 555, level.dirtColor);
		} else {
			return Color.get(444, 444, 333, 333);
		}
	}
	
	public int sand(boolean trans, Level level) {
		if (trans) {
			return Color.get(level.sandColor - 110, level.sandColor, level.sandColor - 110, level.dirtColor);
		} else {
			return Color.get(level.sandColor + 2, level.sandColor, level.sandColor - 110, level.sandColor - 110);
		}
	}
	
	public int sapling(Level level) {
		return Color.get(10, 40, 50, -1);
	}
	
	public int stairs(Level level) {
		return Color.get(level.dirtColor, 000, 333, 444);
	}
	
	public int stone(Level level) {
		return Color.get(111, level.dirtColor, 333, 555);
	}
	
	public int tree(boolean isBark, boolean type, Level level) {
		if (isBark) {
			if (type) {
				return Color.get(10, 30, 320, level.grassColor);
			} else {
				return Color.get(10, 30, 430, level.grassColor);
			}
		} else {
			return Color.get(10, 30, 151, level.grassColor);
		}
	}
	
	public int water(boolean trans, boolean sand, Level level) {
		if (trans) {
			if (sand) {
				return Color.get(3, 005, level.sandColor - 110, level.sandColor);
			} else {
				return Color.get(3, 005, level.dirtColor - 111, level.dirtColor);
			}
		} else {
			return Color.get(005, 005, 115, 115);
		}
	}
	
	public int wheat(boolean aged, boolean old, Level level, int age) {
		if (aged) {
			if (old) {
				return Color.get(0, 0, 50 + (age) * 100, 40 + (age - 3) * 2 * 100);
			} else {
				return Color.get(level.dirtColor - 121, level.dirtColor - 11, 50 + (age) * 100, 40 + (age - 3) * 2 * 100);
			}
		} else {
			return Color.get(level.dirtColor - 121, level.dirtColor - 11, level.dirtColor, 50);
		}
	}

}
