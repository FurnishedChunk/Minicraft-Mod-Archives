package com.mojang.ld22.item;

import java.util.Random;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.ItemEntity;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.nbt.NBTCompound;

public class ToolItem extends Item {
	private Random random = new Random();

	public ToolType type;
	public Material material;
	
	/**
	 * Used Only For Loading!
	 */
	public ToolItem(){}

	public ToolItem(ToolType type, Material material) {
		this.type = type;
		this.material = material;
	}

	public int getColor() {
		return material.color;
	}

	public int getSprite() {
		return type.sprite + 5 * 32;
	}

	public void renderIcon(Screen screen, int x, int y) {
		screen.render(x, y, getSprite(), getColor(), 0);
	}

	public void renderInventory(Screen screen, int x, int y) {
		screen.render(x, y, getSprite(), getColor(), 0);
		Font.draw(getName(), screen, x + 8, y, Color.colors.get("ItemText"));
	}

	public String getName() {
		return material.name + " " + type.name;
	}

	public void onTake(ItemEntity itemEntity) {
	}

	public boolean canAttack() {
		return true;
	}

	public int getAttackDamageBonus(Entity e) {
		if (type == ToolType.axe) {
			return material.damageBonus * 2 + random.nextInt(4);
		}
		if (type == ToolType.sword) {
			return material.damageBonus * 3 + random.nextInt(2 + (material.damageBonus - 1) * (material.damageBonus - 1) * 2);
		}
		return 1;
	}

	public boolean matches(Item item) {
		if (item instanceof ToolItem) {
			ToolItem other = (ToolItem) item;
			if (other.type != type) return false;
			if (other.material != material) return false;
			return true;
		}
		return false;
	}
	
	public void save(NBTCompound nbt) {
		super.save(nbt);
		nbt.setString("type", type.name);
		nbt.setString("material", material.name);
	}
	
	public void load(NBTCompound nbt) {
		super.load(nbt);
		material = Material.getMaterialByName(nbt.getString("material"));
		type = ToolType.toolTypes.get(nbt.getString("type"));
	}
}