package com.mojang.ld22;

import java.awt.event.KeyEvent;

public abstract class BaseMod {
	
	public abstract void load();
	
	public abstract String toString();
	
	public void tick() {
		
	}
	
	public void keyPress(KeyEvent ke, boolean pressed) {
		
	}
}
