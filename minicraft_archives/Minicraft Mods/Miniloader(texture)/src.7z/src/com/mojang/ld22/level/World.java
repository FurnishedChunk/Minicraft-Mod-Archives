package com.mojang.ld22.level;

public class World {

}
