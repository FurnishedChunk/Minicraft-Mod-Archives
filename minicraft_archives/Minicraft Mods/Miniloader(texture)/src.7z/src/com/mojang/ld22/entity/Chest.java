package com.mojang.ld22.entity;

import com.mojang.ld22.nbt.NBTCompound;
import com.mojang.ld22.screen.ContainerMenu;

public class Chest extends Furniture {
	public Inventory inventory = new Inventory();

	public Chest() {
		super("Chest");
		sprite = 1;
	}

	public boolean use(Player player, int attackDir) {
		player.game.setMenu(new ContainerMenu(player, "Chest", inventory));
		return true;
	}
	
	public void save(NBTCompound nbt) {
		super.save(nbt);
		nbt.setTag("inv", inventory.save());
	}
	
	public void load(NBTCompound nbt) {
		super.load(nbt);
		inventory.load(nbt.getTagList("inv"));
	}
}