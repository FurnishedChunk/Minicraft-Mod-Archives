package com.mojang.ld22.screen;

import java.util.ArrayList;

import com.mojang.ld22.MiniLoader;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;

public class TitleMenu extends SelectionMenu {
	
	private MenuOption start = new MenuOption("Start game", this) {
		public void selected() {
			game.setMenu(new LevelGenMenu((Menu) o));
		}
	};
	private MenuOption load = new MenuOption("Load game", this) {
		public void selected() {
			if (MiniLoader.online) {
				if (MiniLoader.couldConnect) {
					game.load(MiniLoader.loadFromServer());
					game.setMenu(null);
				} else {
					game.setMenu(new FailedConnectMenu((Menu) o));
				}
			} else {
				game.setMenu(new LoadMenu((Menu) o));
			}
		}
	};
	private MenuOption texture = new MenuOption("Texture Packs", this) {
		public void selected() {
			game.setMenu(new TextureMenu((Menu) o));
		}
	};
	private MenuOption inst = new MenuOption("How to play", this) {
		public void selected() {
			game.setMenu(new InstructionsMenu((Menu) o));
		}
	};
	private MenuOption about = new MenuOption("About", this) {
		public void selected() {
			game.setMenu(new AboutMenu((Menu) o));
		}
	};

	public TitleMenu() {
		super(null, null);
		list = new ArrayList<MenuOption>();
		if (MiniLoader.getTitleOptions(this) != null) {
			list.addAll(MiniLoader.getTitleOptions(this));
		}
		list.add(0, start);
		list.add(1, load);
		list.add(texture);
		list.add(inst);
		list.add(about);
	}
	
	public void tick() {
		if (input.menu.clicked) {
			return;
		}
		super.tick();
	}

	public void render(Screen screen) {
		super.render(screen);
		int h = 2;
		int w = 13;
		int titleColor = Color.colors.get("Title");
		int xo = (screen.w - w * 8) / 2;
		int yo = 24;
		for (int y = 0; y < h; y++) {
			for (int x = 0; x < w; x++) {
				screen.render(xo + x * 8, yo + y * 8, x + (y + 6) * 32, titleColor, 0);
			}
		}
		Font.draw("(Arrow keys,X and C)", screen, 0, screen.h - 8, Color.get(0, 111, 111, 111));
	}
}