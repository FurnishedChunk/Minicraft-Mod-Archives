package com.mojang.ld22.screen;

import com.mojang.ld22.MiniLoader;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;

public class ModMenu extends SelectionMenu {
	
	private MenuOption save = new MenuOption("Save") {
		public void selected() {
			MiniLoader.save();
			game.setMenu(null);
		}
	};
	
	private MenuOption quit = new MenuOption("Quit Game") {
		public void selected() {
			game.setMenu(new TitleMenu());
		}
	};
	
	public ModMenu(Menu parent) {
		super(parent, MiniLoader.modOptions);
		list.add(0, save);
		list.add(quit);
	}
	
	public void render(Screen screen) {
		super.render(screen);
		Font.draw("Menu", screen, 3 * 8, 1 * 8, Color.colors.get("MenuText"));
	}
}
