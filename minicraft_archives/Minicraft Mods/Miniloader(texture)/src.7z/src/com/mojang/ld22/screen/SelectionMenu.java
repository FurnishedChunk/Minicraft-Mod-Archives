package com.mojang.ld22.screen;

import java.util.ArrayList;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;

public class SelectionMenu extends Menu {
	
	protected int selected = 0;
	protected ArrayList<MenuOption> list;

	public SelectionMenu(Menu parent, ArrayList<MenuOption> list) {
		super(parent);
		if (list != null) {
			this.list = new ArrayList<MenuOption>(list);
		}
	}
	
	public void tick() {
		if (input.menu.clicked) kill();
		if (input.up.clicked) selected--;
		if (input.down.clicked) selected++;

		int len = list.size();
		if (selected < 0) selected += len;
		if (selected >= len) selected -= len;

		if (input.attack.clicked) {
			try {
			list.get(selected).selected();
			} catch (IndexOutOfBoundsException e) {}
		}
		if (input.menu.clicked) {
			kill();
		}
	}
	
	public void render(Screen screen) {
		screen.clear(0);
		
		for (int i = 0; i < list.size(); i++) {
			String msg = list.get(i).text;
			int col = Color.colors.get("MenuText");
			if (i == selected) {
				msg = "> " + msg + " <";
				col = Color.colors.get("MenuSelectedText");
			}
			Font.draw(msg, screen, (screen.w - msg.length() * 8) / 2, (8 + i) * 8, col);
		}
	}

}
