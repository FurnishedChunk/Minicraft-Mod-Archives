package com.mojang.ld22.gfx;

public class ColorSet {
	
	public void load() {
		new Color("Title", 0, 010, 131, 551);
		new Color("MenuText", 0, 222, 222, 222);
		new Color("MenuSelectedText", 0, 555, 555, 555);
		new Color("IngameDark", -1, 222, 222, 222);
		new Color("IngameLight", -1, 555, 555, 555);
		new Color("IngameCursor", 5, 555, 555, 555);
		
		new Color("Health1", 000, 200, 500, 533);
		new Color("Health2", 000, 100, 000, 000);
		new Color("Stamina1", 000, 555, 000, 000);
		new Color("Stamina2", 000, 220, 550, 553);
		new Color("Stamina3", 000, 110, 000, 000);
		
		new Color("EntityHealText", -1, 50, 50, 50);
		new Color("EntityHurtText", -1, 500, 500, 500);
		
		new Color("PlayerHurtText", -1, 504, 504, 504);
		new Color("Player", -1, 100, 220, 532);
		
		new Color("Slime1", -1, 10, 252, 555);
		new Color("Slime2", -1, 100, 522, 555);
		new Color("Slime3", -1, 111, 444, 555);
		new Color("Slime4", -1, 000, 111, 224);
		new Color("SlimeHurt", -1, 555, 555, 555);
		
		new Color("Zombie1", -1, 10, 252, 050);
		new Color("Zombie2", -1, 100, 522, 050);
		new Color("Zombie3", -1, 111, 444, 050);
		new Color("Zombie4", -1, 000, 111, 020);
		new Color("ZombieHurt", -1, 555, 555, 555);
		
		new Color("WizardNormal1", -1, 100, 500, 555);
		new Color("WizardNormal2", -1, 100, 500, 532);
		new Color("WizardBlink1", -1, 500, 100, 555);
		new Color("WizardBlink2", -1, 500, 100, 532);
		new Color("WizardHurt1", -1, 555, 555, 555);
		new Color("WizardHurt2", -1, 555, 555, 555);
		
		new Color("Anvil", -1, 000, 111, 222);
		new Color("Chest", -1, 110, 331, 552);
		new Color("Furnace", -1, 000, 222, 333);
		new Color("Lantern", -1, 000, 111, 555);
		new Color("Oven", -1, 000, 332, 442);
		new Color("Workbench", -1, 100, 321, 431);
		
		new Color("Pow glove", -1, 100, 320, 430);
		new Color("ItemText", -1, 555, 555, 555);
		new Color("ItemAmountText", -1, 444, 444, 444);
		
		new Color("Wood", -1, 200, 531, 430);
		new Color("Stone", -1, 111, 333, 555);
		new Color("Flower", -1, 10, 444, 330);
		new Color("Acorn", -1, 100, 531, 320);
		new Color("Dirt", -1, 100, 322, 432);
		new Color("Sand", -1, 110, 440, 550);
		new Color("Cactus", -1, 10, 40, 50);
		new Color("Seeds", -1, 10, 40, 50);
		new Color("Wheat", -1, 110, 330, 550);
		new Color("Bread", -1, 110, 330, 550);
		new Color("Apple", -1, 100, 300, 500);
		new Color("Coal", -1, 000, 111, 111);
		new Color("I.Ore", -1, 100, 322, 544);
		new Color("G.Ore", -1, 110, 440, 553);
		new Color("Iron", -1, 100, 322, 544);
		new Color("Gold", -1, 110, 330, 553);
		new Color("Slime", -1, 10, 30, 50);
		new Color("Glass", -1, 555, 555, 555);
		new Color("Cloth", -1, 25, 252, 141);
		new Color("Cloud", -1, 222, 555, 444);
		new Color("Gem", -1, 101, 404, 545);
		
		new Color("MatWood", -1, 100, 321, 431);
		new Color("MatRock", -1, 100, 321, 111);
		new Color("MatIron", -1, 100, 321, 555);
		new Color("MatGold", -1, 100, 321, 550);
		new Color("MatGem", -1, 100, 321, 055);
		
		new Color("Smash", -1, 555, 555, 555);
	}

}
