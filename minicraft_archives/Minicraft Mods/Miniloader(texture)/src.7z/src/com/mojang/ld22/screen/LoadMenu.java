package com.mojang.ld22.screen;

import java.io.File;
import java.util.ArrayList;

import com.mojang.ld22.MiniLoader;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;

public class LoadMenu extends SelectionMenu {

	public LoadMenu(Menu parent) {
		super(parent, null);
		list = getSaves();
	}
	
	public void render(Screen screen) {
		super.render(screen);
		Font.draw("Saves", screen, 3 * 8, 1 * 8, Color.colors.get("MenuText"));
	}

	private ArrayList<MenuOption> getSaves() {
		ArrayList<MenuOption> list = new ArrayList<MenuOption>();
		File folder = new File("saves");
		File[] saves = folder.listFiles();
		for (int i = 0; i < saves.length; i++) {
			if (saves[i].getName().endsWith(".sav")) {
			list.add(new MenuOption(saves[i].getName().split(".sav")[0], saves[i]) {
				public void selected() {
					game.setMenu(null);
					game.load(MiniLoader.loadFromFile((File) o));
				}
			});
			}
		}
		return list;
	}
}
