package com.mojang.ld22.entity;

import com.mojang.ld22.nbt.NBTCompound;

public abstract class Mob extends Creature {
	
	protected int lvl;
	
	public Mob(int lvl) {
		this.lvl = lvl;
	}
	
	public void save(NBTCompound nbt) {
		super.save(nbt);
		nbt.setInteger("maxHealth", maxHealth);
		nbt.setInteger("lvl", lvl);
	}
	
	public void load(NBTCompound nbt) {
		super.load(nbt);
		maxHealth = nbt.getInteger("maxHealth");
		lvl = nbt.getInteger("lvl");
	}

}
