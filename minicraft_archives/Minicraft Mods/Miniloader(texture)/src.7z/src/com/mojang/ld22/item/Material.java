package com.mojang.ld22.item;

import java.util.ArrayList;

import com.mojang.ld22.gfx.Color;

public class Material {
	
	public static ArrayList<Material> materialList = new ArrayList<Material>();
	public static Material wood = new Material("Wood", 1);
	public static Material rock = new Material("Rock", 2);
	public static Material iron = new Material("Iron", 3);
	public static Material gold = new Material("Gold", 4);
	public static Material gem = new Material("Gem", 5);
	
	public static Material getMaterialByName(String name) {
		for (int i = 0; i < materialList.size(); i++) {
			if (materialList.get(i).name.equals(name)) {
				return materialList.get(i);
			}
		}
		return null;
	}
	
	public final String name;
	public final int color;
	public final int damageBonus;
	
	public Material(String name, int damageBonus) {
		this.name = name;
		this.color = Color.colors.get("Mat" + name);
		this.damageBonus = damageBonus; 
		materialList.add(this);
	}

}
