package com.mojang.ld22.screen;

import java.util.ArrayList;

import com.mojang.ld22.MiniLoader;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.level.levelgen.LevelGen;
import com.mojang.ld22.sound.Sound;

public class LevelGenMenu extends SelectionMenu {
	
	public LevelGenMenu(Menu parent) {
		super(parent, setupOptions(MiniLoader.levelGens));
	}

	public void render(Screen screen) {
		super.render(screen);
		Font.draw("Level Generator", screen, 3 * 8, 1 * 8, Color.colors.get("MenuText"));
	}
	
	private static ArrayList<MenuOption> setupOptions(ArrayList<LevelGen> list) {
		ArrayList<MenuOption> op = new ArrayList<MenuOption>();
		for (int i = 0; i < list.size(); i++) {
			op.add(new MenuOption(list.get(i).getName(), list.get(i)) {

				public void selected() {
					Sound.test.play();
					MiniLoader.game.levelGen = (LevelGen) o;
					MiniLoader.game.resetGame();
					MiniLoader.game.setMenu(null);
				}
			});
		}
		return op;
	}
}
