package com.mojang.ld22.level.levelgen;

import java.util.Random;

public abstract class LevelGen {
	
	protected final Random random = new Random();
	
	public abstract byte[][] createAndValidateSkyMap(int w, int h);
	
	public abstract byte[][] createAndValidateTopMap(int w, int h);
	
	public abstract byte[][] createAndValidateUndergroundMap(int w, int h, int depth);
	
	public abstract String getName();

}
