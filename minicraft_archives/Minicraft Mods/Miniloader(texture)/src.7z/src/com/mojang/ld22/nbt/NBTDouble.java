package com.mojang.ld22.nbt;
import java.io.*;

public class NBTDouble extends NBTBase
{
    /** The double value for the tag. */
    public double data;

    public NBTDouble(String par1Str)
    {
        super(par1Str);
    }

    public NBTDouble(String par1Str, double par2)
    {
        super(par1Str);
        data = par2;
    }

    /**
     * Write the actual data contents of the tag, implemented in NBT extension classes
     */
    void write(DataOutput par1DataOutput) throws IOException
    {
        par1DataOutput.writeDouble(data);
    }

    /**
     * Read the actual data contents of the tag, implemented in NBT extension classes
     */
    void load(DataInput par1DataInput) throws IOException
    {
        data = par1DataInput.readDouble();
    }

    /**
     * Gets the type byte for the tag.
     */
    public byte getId()
    {
        return 6;
    }

    public String toString()
    {
        return (new StringBuilder()).append("").append(data).toString();
    }

    /**
     * Creates a clone of the tag.
     */
    public NBTBase copy()
    {
        return new NBTDouble(getName(), data);
    }

    public boolean equals(Object par1Obj)
    {
        if (super.equals(par1Obj))
        {
            NBTDouble nbttagdouble = (NBTDouble)par1Obj;
            return data == nbttagdouble.data;
        }
        else
        {
            return false;
        }
    }
}
