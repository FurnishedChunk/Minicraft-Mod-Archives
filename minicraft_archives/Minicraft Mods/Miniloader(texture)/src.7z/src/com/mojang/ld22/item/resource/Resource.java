package com.mojang.ld22.item.resource;

import java.util.ArrayList;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.level.tile.Tile;

public class Resource {
	public static ArrayList<Resource> ResourceList = new ArrayList<Resource>();
	
	public static Resource wood = new Resource("Wood", 1 + 4 * 32);
	public static Resource stone = new Resource("Stone", 2 + 4 * 32);
	public static Resource flower = new PlantableResource("Flower", 0 + 4 * 32, Tile.flower, Tile.grass);
	public static Resource acorn = new PlantableResource("Acorn", 3 + 4 * 32, Tile.treeSapling, Tile.grass);
	public static Resource dirt = new PlantableResource("Dirt", 2 + 4 * 32, Tile.dirt, Tile.hole, Tile.water, Tile.lava);
	public static Resource sand = new PlantableResource("Sand", 2 + 4 * 32, Tile.sand, Tile.grass, Tile.dirt);
	public static Resource cactusFlower = new PlantableResource("Cactus", 4 + 4 * 32, Tile.cactusSapling, Tile.sand);
	public static Resource seeds = new PlantableResource("Seeds", 5 + 4 * 32, Tile.wheat, Tile.farmland);
	public static Resource wheat = new Resource("Wheat", 6 + 4 * 32);
	public static Resource bread = new FoodResource("Bread", 8 + 4 * 32, 2, 5);
	public static Resource apple = new FoodResource("Apple", 9 + 4 * 32, 1, 5);

	public static Resource coal = new Resource("Coal", 10 + 4 * 32);
	public static Resource ironOre = new Resource("I.Ore", 10 + 4 * 32);
	public static Resource goldOre = new Resource("G.Ore", 10 + 4 * 32);
	public static Resource ironIngot = new Resource("Iron", 11 + 4 * 32);
	public static Resource goldIngot = new Resource("Gold", 11 + 4 * 32);

	public static Resource slime = new Resource("Slime", 10 + 4 * 32);
	public static Resource glass = new Resource("Glass", 12 + 4 * 32);
	public static Resource cloth = new Resource("Cloth", 1 + 4 * 32);
	public static Resource cloud = new PlantableResource("Cloud", 2 + 4 * 32, Tile.cloud, Tile.infiniteFall);
	public static Resource gem = new Resource("Gem", 13 + 4 * 32);
	
	public static Resource getResourceByName(String name) {
		for (int i = 0; i < ResourceList.size(); i++) {
			if (ResourceList.get(i).name.equals(name)) {
				return ResourceList.get(i);
			}
		}
		return null;
	}

	public final String name;
	public final int sprite;
	public final int color;

	public Resource(String name, int sprite) {
		if (name.length() > 6) throw new RuntimeException("Name cannot be longer than six characters!");
		this.name = name;
		this.sprite = sprite;
		this.color = Color.colors.get(name);
		ResourceList.add(this);
	}

	public boolean interactOn(Tile tile, Level level, int xt, int yt, Player player, int attackDir) {
		return false;
	}
}