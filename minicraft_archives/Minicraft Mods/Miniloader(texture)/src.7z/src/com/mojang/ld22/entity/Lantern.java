package com.mojang.ld22.entity;

public class Lantern extends Furniture {
	public Lantern() {
		super("Lantern");
		sprite = 5;
		xr = 3;
		yr = 2;
	}

	public int getLightRadius() {
		return 8;
	}
}