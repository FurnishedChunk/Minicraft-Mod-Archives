package com.mojang.ld22.screen;

import com.mojang.ld22.Game;
import com.mojang.ld22.InputHandler;
import com.mojang.ld22.gfx.Screen;

public class Menu {
	protected Game game;
	protected InputHandler input;
	protected Menu parent;
	
	public Menu(Menu parent) {
		this.parent = parent;
	}

	public void init(Game game, InputHandler input) {
		this.input = input;
		this.game = game;
	}

	public void tick() {
	}

	public void render(Screen screen) {
	}
	
	public void kill() {
		game.setMenu(parent);
	}
}
