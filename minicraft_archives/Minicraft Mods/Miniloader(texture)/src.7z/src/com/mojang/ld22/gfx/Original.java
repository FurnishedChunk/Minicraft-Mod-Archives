package com.mojang.ld22.gfx;

import java.io.IOException;

import javax.imageio.ImageIO;

import com.mojang.ld22.BaseTex;
import com.mojang.ld22.Game;

public class Original extends BaseTex {

	public Original() {
		super(new ColorSet(), new TileSet());
		try {
			sprites = new SpriteSheet(ImageIO.read(Game.class.getResourceAsStream("/icons.png")));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String Name() {
		return "Original";
	}

}
