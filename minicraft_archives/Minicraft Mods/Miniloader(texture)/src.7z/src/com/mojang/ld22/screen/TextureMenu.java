package com.mojang.ld22.screen;

import com.mojang.ld22.MiniLoader;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Original;
import com.mojang.ld22.gfx.Screen;

public class TextureMenu extends SelectionMenu {
	
	private MenuOption original = new MenuOption("Original") {
		public void selected() {
			new Original().load();
		}
	};
	
	public TextureMenu(Menu parent) {
		super(parent, MiniLoader.texturePacks);
		list.add(original);
	}
	
	public void render(Screen screen) {
		super.render(screen);
		Font.draw("Texture Packs", screen, 3 * 8, 1 * 8, Color.colors.get("MenuText"));
	}
}
