package com.mojang.ld22;

import java.io.IOException;

import javax.imageio.ImageIO;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.ColorSet;
import com.mojang.ld22.gfx.SpriteSheet;
import com.mojang.ld22.gfx.TileSet;

public abstract class BaseTex {
	
	public BaseTex(ColorSet a, TileSet b) {
		colorSet = a;
		tileSet = b;
	}
	
	private ColorSet colorSet;
	private TileSet tileSet;
	protected SpriteSheet sprites = null;

	public abstract String Name();
	
	public void load() {
		colorSet.load();
		Color.tileSet = tileSet;
		if (sprites != null) {
			try {
				MiniLoader.getGame().setSprites(sprites, new SpriteSheet(ImageIO.read(Game.class.getResourceAsStream("/icons2.png"))));
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}
}
