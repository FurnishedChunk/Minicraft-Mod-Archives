

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
 
public class Main implements ActionListener, ItemListener{
	static JFileChooser chooser;
	static JFrame frame;
	static String location;
	boolean toZip = false;
	boolean deleteTemp = true;
	
	public Main(){
        createAndShowGUI();
	}
	
    public void addComponentsToPane(Container pane) {
        pane.setLayout(new BoxLayout(pane, BoxLayout.Y_AXIS));
        addText("Minicraft TexturePack Splitter v1.0", pane, new Color(0,0,200));
        addText("Made by David", pane,new Color(100,0,0));
        addText(" ", pane,new Color(0,0,0));
        addText("Open up icons.png:", pane,new Color(0,0,0));
        addText(" ", pane,new Color(0,0,0));
        addAButton("Browse", pane);
    }
 
    private void addAButton(String text, Container container) {
        JButton button = new JButton(text);
        button.setName(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.addActionListener(this);
        container.add(button);
    }
    
    private void addText(String text, Container container, Color color) {
        JLabel label = new JLabel(text);
        label.setName(text);
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        label.setForeground(color);
        container.add(label);
    }
    
    private void addCheckBox(String text, Container container) {
    JPanel newPanel = new JPanel();
    newPanel.setPreferredSize(new Dimension(10,0));
    JCheckBox box = new JCheckBox(text);
    box.setName(text);
    box.setSelected(false);
    box.addItemListener(this);
    box.addActionListener(this);
    newPanel.add(box);
    container.add(newPanel);
    }
    private void createAndShowGUI() {
        //Create and set up the window.
        frame = new JFrame("Minicraft TP Splitter");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocation(600, 200);
        //Set up the content pane.
        addComponentsToPane(frame.getContentPane());
        //Display the window.
        update(1);
    }
    
    private void update(int y){
        frame.setPreferredSize(new Dimension(300,250 + (y * 10)));
        frame.pack();
        frame.setVisible(true);
    }
    
    
    public void actionPerformed(ActionEvent e) {
    	if(e.getActionCommand().equals("Browse")){
        chooser = new JFileChooser(); 
        //chooser.setCurrentDirectory();
        chooser.setDialogTitle("Browse");
        //
        // disable the "All files" option.
        //

        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        chooser.setAcceptAllFileFilterUsed(false);

        chooser.setFileFilter(new ImageFileFilter("icons.png","Icons.png"));
        chooser.addChoosableFileFilter(new ImageFileFilter("png","PNG"));
        //    
        if (chooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) { 
        	
        	System.out.println(frame.getContentPane().getComponents().length);
        	if(frame.getContentPane().getComponents().length >= 6){
        		for (int i = frame.getContentPane().getComponents().length - 1; i > 6; i--){
        			frame.getContentPane().removeAll();
        			addComponentsToPane(frame.getContentPane());
        		}
        	}
        	
        	//Component doneText = getLabelFromText("done", frame);
        	//if(doneText != null) frame.remove(doneText);
        	
        	
          System.out.println("getCurrentDirectory(): " +  chooser.getCurrentDirectory());
          System.out.println("getSelectedFile() : " +  chooser.getSelectedFile());
          addText(" ", frame.getContentPane(),new Color(0,0,0));
          addText("After that, just press Split!", frame.getContentPane(),new Color(0,0,0));
          addText(" ", frame.getContentPane(),new Color(0,0,0));
          addAButton("Split", frame.getContentPane());
          addCheckBox("Put in a .zip file",frame.getContentPane());
          update(1);
          location = chooser.getSelectedFile().toString();
          System.out.println("Location :" + location);
          }
        else {
          System.out.println("No Selection");
          }
         }
    	if(e.getActionCommand().equals("Put in a .zip file")){
    		if(!toZip){
    		toZip = true;
    		//System.out.println("TO ZIP!");
    		} else {
        	toZip = false;
    		//System.out.println("TO FOLDER!");
    		}
    	}
    	
    	if(e.getActionCommand().equals("Split")){
    		if(location != null){
    		split(location);
    		} else {
    	    addText(" ", frame.getContentPane(),new Color(0,0,0));
    	    addText("Error: No File found! (null)" , frame.getContentPane(),new Color(255,0,0));
    	    update(1);
    		}
    		
    	}
      }
    
    public void split(String url){
        File file = new File(url); // I have bear.jpg in my working directory  
        FileInputStream fis;
		try {
		fis = new FileInputStream(file);
        BufferedImage image = ImageIO.read(fis); //reading the image file  
  
        int rows = image.getWidth()/8; 
        int cols = image.getHeight()/8;  
        int chunks = rows * cols;  
  
        int chunkWidth = 8; // determines the chunk width and height  
        int chunkHeight = 8;  
        int count = 0;  
        BufferedImage imgs[] = new BufferedImage[chunks]; //Image array to hold image chunks  
        for (int x = 0; x < rows; x++) {  
            for (int y = 0; y < cols; y++) {  
                //Initialize the image array with image chunks  
                imgs[count] = new BufferedImage(8, 8, BufferedImage.TYPE_INT_RGB);  
                
                // draws the image chunk  
                Graphics2D gr = imgs[count++].createGraphics();  
                gr.drawImage(image, 0, 0, chunkWidth, chunkHeight, chunkWidth * y, chunkHeight * x, chunkWidth * y + chunkWidth, chunkHeight * x + chunkHeight, null);  
                gr.dispose();  
            }  
        }  
        
        File folder = new File(url.substring(0, url.lastIndexOf("\\")) + "/TempSplitTexturePack/");
        folder.mkdir();
        
        for (int i = 0; i < imgs.length; i++) {  
            try {
                //System.out.println(imgs[i].getRGB(5, 5));
                if(imgs[i].getRGB(5, 5) == -2719745) continue;
				ImageIO.write(imgs[i], "png", new File(folder +"/"+ "img" + i + ".png"));
			} catch (IOException e) {
				e.printStackTrace();
			}  
        }  
		} catch (FileNotFoundException e1) {
    	    addText(" ", frame.getContentPane(),new Color(0,0,0));
    	    addText("Error: No File found!" , frame.getContentPane(),new Color(255,0,0));
    	    update(1);
			e1.printStackTrace();
		} catch (IOException e) {
    	    addText(" ", frame.getContentPane(),new Color(0,0,0));
    	    addText("Error: IOException! " + e.getCause(), frame.getContentPane(),new Color(255,0,0));
    	    update(1);
			e.printStackTrace();
		}  
        stiching(url.substring(0, url.lastIndexOf("\\")) + "/TempSplitTexturePack/");
    }
    
    public void stiching(String url){
    	zipImages.clear();
    	zipImagesURL.clear();
    	String sublocation = location.substring(0,location.lastIndexOf("\\"))+ "/SplitTexturePack/";
        File folder = new File(sublocation);
        folder.mkdir();
        //deleteTemp = false;
        
        /*
         * Each of the numbers in the lists below are ID's in the Temp texturepack folder. Each image has a
         * set of ID's to combine together, uncomment the "deleteTemp = false" line above to look into the folder and
         * find your image.
         */
        
        Integer[] waternum = {0,1,2,3};
        Integer[] rocknum = {4,5,6,36,37,38,68,69,70};
        Integer[] treenum = {9,10,41,42,986,74,986,106};//986 = blank.
        Integer[] groundnum = {11,12,13,43,44,45,75,76,77};
        Integer[] holenum = {14,15,16,46,47,48,78,79,80};
        Integer[] cloudnum = {17,18,19,20};
        Integer[] rocksidenum = {7,8,39,40};
        Integer[] orenum = {49,50,81,82};
        Integer[] stairsdownnum = {64,65,96,97};
        Integer[] stairsupnum = {66,67,98,99};
        Integer[] wheatnum = {100,101,102,103};
        Integer[] cactusnum = {72,73,104,105};
        Integer[] titlenum = {
        192,193,194,195,196,197,198,199,200,201,202,203,204,
        224,225,226,227,228,229,230,231,232,233,234,235,236
        };
        Integer[] anvilnum = {256,257,288,289};
        Integer[] chestnum = {258,259,290,291};
        Integer[] ovennum = {260,261,292,293};
        Integer[] furnacenum = {262,263,294,295};
        Integer[] workbenchnum = {264,265,296,297};
        Integer[] lanternnum = {266,267,298,299};

        /* Player & Zombie (Zombie only using first 2 rows) */
        Integer[] playernum = {
        448,449,450,451,452,453,454,455,
        480,481,482,483,484,485,486,487,
        512,513,514,515,516,517,518,519,
        544,545,546,547,548,549,550,551
        };
        
        Integer[] slimenum = {
        576,577,578,579,
        608,609,610,611
        };
        
        Integer[] airwizardnum = {
        456,457,458,459,460,461,462,463,
        488,489,490,491,492,493,494,495
        };
        
        /*
         * 
         * Parameters:
         * stich(List<String> list, int width, int height,
         * String filename, String filelocation, int type)
         * 
         * (See types in stich method)
         * 
         * */
        
        stich(urls(numbers(waternum),url),32,8,"Detail",sublocation,0);//Detail.png
        stich(urls(numbers(rocknum),url),24,24,"Rock",sublocation,2);//Rock.png
        stich(urls(numbers(treenum),url),16,32,"Tree",sublocation,3);//Tree.png
        stich(urls(numbers(groundnum),url),24,24,"Ground",sublocation,2);//Ground.png
        stich(urls(numbers(holenum),url),24,24,"Hole",sublocation,2);//Hole.png
        stich(urls(numbers(cloudnum),url),32,8,"Cloud",sublocation,0);//Cloud.png
        stich(urls(numbers(rocksidenum),url),16,16,"RockSide",sublocation,1);//RockSide.png
        stich(urls(numbers(orenum),url),16,16,"Ore",sublocation,1);//Ore.png
        stich(urls(numbers(stairsdownnum),url),16,16,"StairsDown",sublocation,1);//StairsDown.png
        stich(urls(numbers(stairsupnum),url),16,16,"StairsUp",sublocation,1);//StairsUp.png
        stich(urls(numbers(wheatnum),url),32,8,"Wheat",sublocation,0);//Wheat.png
        stich(urls(numbers(cactusnum),url),16,16,"Cactus",sublocation,1);//Cactus.png
        stich(urls(numbers(titlenum),url),104,16,"Title",sublocation,3);//Title.png
        stich(urls(numbers(anvilnum),url),16,16,"Anvil",sublocation,1);//Anvil.png
        stich(urls(numbers(chestnum),url),16,16,"Chest",sublocation,1);//Chest.png
        stich(urls(numbers(ovennum),url),16,16,"Oven",sublocation,1);//Oven.png
        stich(urls(numbers(furnacenum),url),16,16,"Furnace",sublocation,1);//Furnace.png
        stich(urls(numbers(workbenchnum),url),16,16,"Workbench",sublocation,1);//Workbench.png
        stich(urls(numbers(lanternnum),url),16,16,"Lantern",sublocation,1);//Lantern.png
        stich(urls(numbers(playernum),url),64,32,"Player",sublocation,3);//Player.png
        stich(urls(numbers(playernum),url),64,16,"Zombie",sublocation,3);//Zombie.png
        stich(urls(numbers(slimenum),url),32,16,"Slime",sublocation,3);//Slime.png
        stich(urls(numbers(airwizardnum),url),64,16,"AirWizard",sublocation,3);//AirWizard.png
        
        stich(urls(numbers(alphabet()),url),256,16,"Alphabet",sublocation,3);//Alphabet.png
        
        stich(urls(numbers(32),url),8,8,"Unused1",sublocation,0);//Unused1.png
        stich(urls(numbers(33),url),8,8,"Flower",sublocation,0);//Flower.png
        stich(urls(numbers(34),url),8,8,"Farm",sublocation,0);//Farm.png
        stich(urls(numbers(35),url),8,8,"Footprint",sublocation,0);//Footprint.png
        stich(urls(numbers(107),url),8,8,"Sapling",sublocation,0);//Sapling.png
        stich(urls(numbers(128),url),8,8,"FlowerItem",sublocation,0);//FlowerItem.png
        stich(urls(numbers(129),url),8,8,"ClothItem",sublocation,0);/*I think you can guess the rest...*/
        stich(urls(numbers(130),url),8,8,"StoneItem",sublocation,0);
        stich(urls(numbers(131),url),8,8,"AcornItem",sublocation,0);
        stich(urls(numbers(132),url),8,8,"CactusItem",sublocation,0);
        stich(urls(numbers(133),url),8,8,"SeedsItem",sublocation,0);
        stich(urls(numbers(134),url),8,8,"WheatItem",sublocation,0);
        stich(urls(numbers(135),url),8,8,"PowGloveItem",sublocation,0);
        stich(urls(numbers(136),url),8,8,"BreadItem",sublocation,0);
        stich(urls(numbers(137),url),8,8,"AppleItem",sublocation,0);
        stich(urls(numbers(138),url),8,8,"OreItem",sublocation,0);
        stich(urls(numbers(139),url),8,8,"IngotItem",sublocation,0);
        stich(urls(numbers(140),url),8,8,"GlassItem",sublocation,0);
        stich(urls(numbers(141),url),8,8,"GemItem",sublocation,0);
        stich(urls(numbers(160),url),8,8,"Shovel",sublocation,0);
        stich(urls(numbers(161),url),8,8,"Hoe",sublocation,0);
        stich(urls(numbers(162),url),8,8,"Sword",sublocation,0);
        stich(urls(numbers(163),url),8,8,"Pickaxe",sublocation,0);
        stich(urls(numbers(164),url),8,8,"Axe",sublocation,0);
        stich(urls(numbers(320),url),8,8,"AnvilIcon",sublocation,0);
        stich(urls(numbers(321),url),8,8,"ChestIcon",sublocation,0);
        stich(urls(numbers(322),url),8,8,"OvenIcon",sublocation,0);
        stich(urls(numbers(323),url),8,8,"FurnaceIcon",sublocation,0);
        stich(urls(numbers(324),url),8,8,"WorkbenchIcon",sublocation,0);
        stich(urls(numbers(325),url),8,8,"LanternIcon",sublocation,0);
        stich(urls(numbers(384),url),8,8,"HeartIcon",sublocation,0);
        stich(urls(numbers(385),url),8,8,"StaminaIcon",sublocation,0);
        stich(urls(numbers(389),url),8,8,"Striked",sublocation,0);
        stich(urls(numbers(416),url),8,8,"FrameCorner",sublocation,0);
        stich(urls(numbers(417),url),8,8,"FrameTop",sublocation,0);
        stich(urls(numbers(418),url),8,8,"FrameSide",sublocation,0);
        stich(urls(numbers(421),url),8,8,"SwimCircle",sublocation,0);
        stich(urls(numbers(422),url),8,8,"AttackTop",sublocation,0);
        stich(urls(numbers(423),url),8,8,"AttackSide",sublocation,0);
        stich(urls(numbers(424),url),8,8,"Magic",sublocation,0);
        
        if(deleteTemp)deleteTempFolder(location.substring(0,location.lastIndexOf("\\"))+ "/TempSplitTexturePack/");
        if(toZip)createZipWithImages(zipImages, zipImagesURL);
        
        addText("Done!", frame.getContentPane(),new Color(0,255,0));
        addText(" ", frame.getContentPane(),new Color(0,0,0));
        update(2);
    }
    
    public List<String> urls(List<Integer> integer, String url){
    	List<String> newurls = new ArrayList<String>();
        for(int i = 0; i < integer.size(); i++){
        	newurls.add(url +"/"+ "img" + integer.get(i) + ".png");
        }
    	return newurls;
    }
    
    public List<Integer> numbers(Integer[] num){
    	List<Integer> newnumbers = new ArrayList<Integer>();
    	for(int i = 0; i < num.length; i++){
    		newnumbers.add(num[i]);
    	}
    	return newnumbers;
    }
    
    public List<Integer> numbers(int num){
    	List<Integer> newnumbers = new ArrayList<Integer>();
    	newnumbers.add(num);
    	return newnumbers;
    }
    
    public Integer[] alphabet(){
    	//Was lazy to put in all the number Id's for this one.
    	List<Integer> newnumbers = new ArrayList<Integer>();
    	
    	for (int i = 0; i < 64; i++){
    		newnumbers.add(960 + i);
    	}
    	Integer[] newi = newnumbers.toArray(new Integer[newnumbers.size()]);
    	return newi;
    }
    
    
    List<BufferedImage> zipImages = new ArrayList<BufferedImage>();
    List<String> zipImagesURL = new ArrayList<String>();
    public void stich(List<String> pics,int width,int height,String name,String url,int type){
    	
    	/* [types] (the 6th paramater)
    	 * 0 = row (or Single)
    	 * 1 = box 2x2
    	 * 2 = box 3x3
    	 * 3 = rectangle (aka: Custom)
    	 */

		try {
		List<BufferedImage> images = new ArrayList<BufferedImage>();
		
		for(int i = 0; i < pics.size(); i++){
			BufferedImage newimg = ImageIO.read(new File(pics.get(i)));
			images.add(newimg);
		}

        final BufferedImage newImage = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);


                Graphics2D g2dColumn = newImage.createGraphics();
                
                if(type == 0){
                for(int i = 0; i < images.size(); i++){ g2dColumn.drawImage(images.get(i),8 * i,0, null);}
                } else if(type == 1){
    			for(int i = 0; i < 2; i++){g2dColumn.drawImage(images.get(i),8 * i,0, null); }
    			for(int i = 2; i < 4; i++){g2dColumn.drawImage(images.get(i),(8 * i) - (2 * 8),8, null);}
				} else if(type == 2){
				for(int i = 0; i < 3; i++){g2dColumn.drawImage(images.get(i),8 * i,0, null);}
				for(int i = 3; i < 6; i++){g2dColumn.drawImage(images.get(i),(8 * i) - (3 * 8),8, null);}
				for(int i = 6; i < 9; i++){g2dColumn.drawImage(images.get(i),(8 * i)- (6 * 8),16, null);}
				} else if(type == 3){
				int x = 0;
				int y = 0;
				for (int i = 0; i < images.size(); i++){
					if(x == width / 8){
						y = y + 8;
						x = 0;
					}
					g2dColumn.drawImage(images.get(i),8 * x,y, null);
					x++;
				}
				}
        
        
        if(!toZip) ImageIO.write(newImage, "png", new File(url + name + ".png"));
        else { 
        zipImages.add(newImage);
        zipImagesURL.add(name + ".png");
        }
        
        
		} catch (MalformedURLException e) {
    	    addText(" ", frame.getContentPane(),new Color(0,0,0));
    	    addText("Error: Bad output to " + name + "!", frame.getContentPane(),new Color(255,0,0));
    	    update(2);
			e.printStackTrace();
		} catch (IOException e) {
    	    addText(" ", frame.getContentPane(),new Color(0,0,0));
    	    addText("Error: IOException for " + name + "!", frame.getContentPane(),new Color(255,0,0));
    	    update(2);
			e.printStackTrace();
		}
    }
    
    public void createZipWithImages(List<BufferedImage> list, List<String> URLlist){
    	System.out.println(list);
    	System.out.println(URLlist);
        try {
  		    // Create the ZIP file
        	String sublocation = location.substring(0, location.lastIndexOf("\\"))+ "\\";
  		    String outFilename = sublocation + "SplitTexturePack.zip";
  		    ZipOutputStream out = new ZipOutputStream(new FileOutputStream(outFilename));
  		    
  		    // Compress two files
  		    for (int i=0; i< list.size(); i++) {
  		        out.putNextEntry(new ZipEntry(URLlist.get(i)));
  		        ImageIO.write(list.get(i), "png", out);
  		        // Close the file
  		        out.closeEntry();
  		    }
  		    // Close the ZIP file
  		    out.close();
  		} catch (IOException e) {
  			System.out.println("Problem writing ZIP file: " + e);
  		}

  
    }
    
    public void deleteTempFolder(String url){
		File folder = new File(url);
		File[] list = folder.listFiles();
		for(int i = 0; i < list.length;i++){
			list[i].delete();
		}
		folder.delete();
    }
 
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	new Main();
            }
        });
    }

	public void itemStateChanged(ItemEvent arg0) {}
}