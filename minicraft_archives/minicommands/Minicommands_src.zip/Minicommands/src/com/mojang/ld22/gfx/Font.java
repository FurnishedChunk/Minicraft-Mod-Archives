package com.mojang.ld22.gfx;

public class Font {
	public static String chars = "" + //
			"ABCDEFGHIJKLMNOPQRSTUVWXYZ      " + //
			"0123456789.,!?'\"-+=/\\%()<>:;     " + //
			"";

	public static int lastColorUsed = 0;
	public static void draw(String msg, Screen screen, int x, int y, int col) {
		msg = msg.toUpperCase();
		for (int i = 0; i < Color.noColor(msg).length(); i++) {
			int ix = chars.indexOf(msg.charAt(i));
			if (msg.charAt(i) == '@'){
				char n = msg.charAt(i+1);
				switch (n){
				case 'A':
					col = Color.lightgreen;
					break;
				case 'B':
					col = Color.cyan;
					break;
				case 'C':
					col = Color.verylightred;
					break;
				case 'D':
					col = Color.pink;
					break;
				case 'E':
					col = Color.verylightyellow;
					break;
				case 'F':
					col = Color.white;
					break;
				case '0':
					col = Color.black;
					break;
				case '1':
					col = Color.darkblue;
					break;
				case '2':
					col = Color.darkgreen;
					break;
				case '3':
					col = Color.darkcyan;
					break;
				case '4':
					col = Color.darkred;
					break;
				case '5':
					col = Color.purple;
					break;
				case '6':
					col = Color.orange;
					break;
				case '7':
					col = Color.lightgrey;
					break;
				case '8':
					col = Color.darkgrey;
					break;
				case '9':
					col = Color.navyblue;
					break;
				}
				msg = msg.substring(0,i+2).replace("@"+n, "")+msg.substring(i+2);
				ix = chars.indexOf(Color.noColor(msg).charAt(i));
				lastColorUsed = col;
			}
			if (ix >= 0) {
				screen.render(x + i * 8, y, ix + 30 * 32, col, 0);
			}
		}
	}

	public static void renderFrame(Screen screen, String title, int x0, int y0, int x1, int y1) {
		for (int y = y0; y <= y1; y++) {
			for (int x = x0; x <= x1; x++) {
				if (x == x0 && y == y0)
					screen.render(x * 8, y * 8, 0 + 13 * 32, Color.get(-1, 1, 5, 445), 0);
				else if (x == x1 && y == y0)
					screen.render(x * 8, y * 8, 0 + 13 * 32, Color.get(-1, 1, 5, 445), 1);
				else if (x == x0 && y == y1)
					screen.render(x * 8, y * 8, 0 + 13 * 32, Color.get(-1, 1, 5, 445), 2);
				else if (x == x1 && y == y1)
					screen.render(x * 8, y * 8, 0 + 13 * 32, Color.get(-1, 1, 5, 445), 3);
				else if (y == y0)
					screen.render(x * 8, y * 8, 1 + 13 * 32, Color.get(-1, 1, 5, 445), 0);
				else if (y == y1)
					screen.render(x * 8, y * 8, 1 + 13 * 32, Color.get(-1, 1, 5, 445), 2);
				else if (x == x0)
					screen.render(x * 8, y * 8, 2 + 13 * 32, Color.get(-1, 1, 5, 445), 0);
				else if (x == x1)
					screen.render(x * 8, y * 8, 2 + 13 * 32, Color.get(-1, 1, 5, 445), 1);
				else
					screen.render(x * 8, y * 8, 2 + 13 * 32, Color.get(5, 5, 5, 5), 1);
			}
		}

		draw(title, screen, x0 * 8 + 8, y0 * 8, Color.get(5, 5, 5, 550));

	}
}