package com.mojang.ld22.screen;

import java.util.ArrayList;
import java.util.List;

import com.mojang.ld22.CommandHandler;
import com.mojang.ld22.Game;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.gfx.TextBox;

public class CommandMenu extends Menu {
	private Player p;
	public TextBox text;
	int y = 0;
	public CommandMenu(Player p){
		this.p = p;
		text = new TextBox(p.game,5,(8*19));
	}

	public void tick(){
		if (input.exit.clicked){
			game.setMenu(null);
			text.kill();
		}
		if (input.enter.clicked){
			String cmd = text.text;
			if (!CommandHandler.sendCommand(p, cmd)){
				p.sendMessage("@cUnkown command.");
			}
			text.clear();
		}
	}

	public void render(Screen s){
		Font.renderFrame(s, "", 0, 0, 8 * 4 + 3, 16);
		Font.renderFrame(s, "", 0, 18, 8*4+3, 20);
		text.render(s);
		List<String> msgs = new ArrayList<String>();
		for (int i = 0; i < p.messages.size(); i++){
			if (i > p.messages.size() - 1) break;
			String msg = p.messages.get(i);
			String chopped = "";
			if (msg.length()*8 > Game.WIDTH-10) {
				int il = 0;
				for (int j = 0; j < msg.length(); j++){
					if (j * 8 > ((Game.WIDTH-10)*(il+1))){
						chopped +="&"+msg.charAt(j);
						il++;
					} else {
						chopped += msg.charAt(j);
					}
				}

			}
			if (chopped.split("&").length > 1){
				for (int j = 0; j < chopped.split("&").length; j++) {
					msgs.add(chopped.split("&")[j]);
				}
			}
			else {
				msgs.add(msg);
			}

		}
		int line = 0;
		for (int i = ( msgs.size() > 15 ? msgs.size() - 15 : 0); i < msgs.size(); i++){
			
			if (i > msgs.size()) break;
			
			Font.draw(msgs.get(i), s, 8, ((line)*8)+9, Font.lastColorUsed);
			line++;
		}
	}

}
