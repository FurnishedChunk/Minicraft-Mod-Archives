package com.mojang.ld22;

import java.util.*;

import com.mojang.ld22.entity.Player;

public class CommandHandler {

	public static List<Command> cmds = new ArrayList<Command>();
	public static Map<String,Command> commands = new HashMap<String,Command>();
	//This is where you can init commands, or just simply make a method for it. 
	static {
		addCommand(new CommandMinicommands("minicommands"));
		addCommand(new CommandHelp("help"));
	}
	
	public static void addCommand(Command c){
		commands.put(c.name, c);
		cmds.add(c);
	}
	
	public static boolean sendCommand(Player p, String command){
		String[] split = command.replace("/","").toLowerCase().split(" ");
		if (!commands.containsKey(split[0])) {
			return false;
		}
		String[] args = null;
		if (split.length > 1) args = new String[split.length-1];
		else args = new String[0];
		for (int i = 1; i < split.length; i++) args[i-1]=split[i];
		commands.get(split[0]).onCommand(p, args);
		return true;
	}
	
}
