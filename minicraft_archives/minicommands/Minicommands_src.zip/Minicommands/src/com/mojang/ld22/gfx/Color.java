package com.mojang.ld22.gfx;

public class Color {

	public static int get(int a, int b, int c, int d) {
		return (get(d) << 24) + (get(c) << 16) + (get(b) << 8) + (get(a));
	}

	public static int get(int d) {
		if (d < 0) return 255;
		int r = d / 100 % 10;
		int g = d / 10 % 10;
		int b = d % 10;
		return r * 36 + g * 6 + b;
	}
	
	public static int all(int color){
		return Color.get(-1,color,color,color);
	}
	
	public static String noColor(String s){
		return s.replace("@0", "").
				replace("@1","").
				replace("@2","").
				replace("@3","").
				replace("@4","").
				replace("@5","").
				replace("@6","").
				replace("@7","").
				replace("@8","").
				replace("@9","").
				replace("@A","").
				replace("@B","").
				replace("@C","").
				replace("@D","").
				replace("@E","").
				replace("@F","");
				
				
	}
	
	
	 /* Color Shortcuts v1.0*/
	   
	   /*Invisible is a color too, don't be hating*/
	   public static int invisible = -1;
	   
	   /* Greys, white, and black*/
	   public static int black = all(000);
	   public static int darkgrey = all(111);
	   public static int mediumgrey = all(222);
	   public static int grey = all(333);
	   public static int lightgrey = all(444);
	   public static int white = all(555);
	   
	   /* Blues */
	   public static int blue = all(5);
	   public static int lightblue = all(25);
	   public static int mediumblue = 4;
	   public static int darkblue = all(3);
	   public static int navyblue = 2;
	   public static int verydarkblue = 1;
	   public static int babyblue = 35;
	   
	   /* Greens */
	   public static int verylightgreen = 50;
	   public static int lightgreen = all(40);
	   public static int green = all(30);
	   public static int mediumgreen = 20;
	   public static int darkgreen = all(10);
	   
	   /* Purples */
	   public static int royalpurple = all(265);
	   public static int purple = all(364);
	   public static int plum = 102;
	   public static int darkpurple = 101;
	   public static int mediumpurple = 263;
	   
	   /* Reds */
	   public static int darkred = all(100);
	   public static int mediumred = 200;
	   public static int red = 300;
	   public static int lightred = all(400);
	   public static int verylightred = all(500);
	   
	   /* Oranges */
	   public static int orange = all(520);
	   public static int darkorange = 510;
	   public static int lightorange = 530;
	   
	   /* Yellows */
	   public static int verylightyellow = all(550);
	   public static int lightyellow = all(440);
	   public static int yellow = all(330);
	   public static int mediumyellow = 220;
	   public static int darkyellow = 110;
	   
	   /* Cyans */
	   public static int cyan = all(12);
	   public static int lightcyan = 22;
	   public static int darkcyan = all(8);
	   
	   /* Browns */
	   public static int darkbrown = 120;
	   public static int mediumbrown = 230;
	   public static int brown = 340;
	   public static int lightbrown = 430;
	   public static int verylightbrown = 540;
	   
	   /* Pinks */
	   public static int darkerpink = 462;
	   public static int pink = all(464);
	   public static int hotpink = 465;


}