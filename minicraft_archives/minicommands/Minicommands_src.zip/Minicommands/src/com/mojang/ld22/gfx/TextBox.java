package com.mojang.ld22.gfx;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import com.mojang.ld22.Game;

public class TextBox implements KeyListener {

	private Game g;
	private int x, y;
	public String text;
	public TextBox(Game g, int x, int y){
		this.g = g;
		this.x = x;
		this.y = y;
		text = "";
		g.addKeyListener(this);
	}
	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_BACK_SPACE){
			if (text.length() >= 1){
				text = text.substring(0,text.length()-1);
			}
		}
		if (!Font.chars.contains((""+e.getKeyChar()).toUpperCase())) return;
		this.text += e.getKeyChar();
	}
	
	public void clear(){
		this.text = "";
	}
	
	public void render(Screen s){
		Font.draw(text+"<", s, x, y, Color.white);
	}
	
	public void kill(){
		g.removeKeyListener(this);
	}
	
	@Override
	public void keyReleased(KeyEvent arg0) {
		
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		
	}
	
}
