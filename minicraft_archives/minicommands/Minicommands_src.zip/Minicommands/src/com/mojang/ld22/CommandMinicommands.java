package com.mojang.ld22;

import com.mojang.ld22.entity.Player;

public class CommandMinicommands extends Command {

	public CommandMinicommands(String name) {
		super(name);
	}

	@Override
	public void onCommand(Player p, String[] args) {
		p.sendMessage("@fMinicommands v 1.0");
	}
	
	

}
