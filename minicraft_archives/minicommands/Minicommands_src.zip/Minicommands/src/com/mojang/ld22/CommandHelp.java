package com.mojang.ld22;


import com.mojang.ld22.entity.Player;

public class CommandHelp extends Command {

	public CommandHelp(String name) {
		super(name);
	}

	@Override
	public void onCommand(Player p, String[] args) {
		int page = 1;
		if (args.length > 0){
			try {
				page = Integer.parseInt(args[0]);
			} 
			catch (NumberFormatException e){
				p.sendMessage("@cError: Arg1 must be a number");
				return;
			}
		}
		
		p.sendMessage("@6===@eHelp@6===");
		p.sendMessage("@7Page @e"+page+"@7/@e"+((CommandHandler.cmds.size()/3)+1));
		for (int i = (page*10)-10; i < CommandHandler.cmds.size(); i++){
			if (i < CommandHandler.cmds.size()){
				p.sendMessage("@e/"+CommandHandler.cmds.get(i).name);
			}
		}
	}


}
