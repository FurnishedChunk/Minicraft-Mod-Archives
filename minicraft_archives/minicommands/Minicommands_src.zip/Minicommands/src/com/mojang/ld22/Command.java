package com.mojang.ld22;

import com.mojang.ld22.entity.Player;

public abstract class Command {

	public String name;
	
	public Command(String name){
		this.name = name;
	}
	
	public abstract void onCommand(Player p, String[] args);
}
