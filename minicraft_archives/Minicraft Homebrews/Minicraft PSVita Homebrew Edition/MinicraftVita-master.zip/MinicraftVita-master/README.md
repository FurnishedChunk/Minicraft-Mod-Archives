# MinicraftVita
Vita Homebrew port of Notch's ludum dare game "Minicraft"

You can do anything with the source code (besides sell it) as long as you give proper credit to the right people. 
If you are going to make a mod of this version, be sure to give credit to Markus "Notch" Perrson because he did create the original game after all.

This source code is subject to a lot of change for better optimization/cleanliness.

Based on 3DS Port by DavidSM64
