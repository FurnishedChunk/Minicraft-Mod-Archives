#pragma once

#include "MenuTutorial.h"
#include "texturepack.h"

void renderMenu(int menu,int xscr,int yscr);
void tickMenu(int menu);
