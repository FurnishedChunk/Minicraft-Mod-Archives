package com.mojang.ld22;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.List;

import de.thejackimonster.ld22.modloader.KeyBinding;
import de.thejackimonster.ld22.modloader.ModLoader;
import de.thejackimonster.ld22.options.OptionFile;


public class InputHandler implements KeyListener {
	public class Key {
		public int presses, absorbs;
		public boolean down, clicked;

		public Key() {
			keys.add(this);
		}

		public void toggle(boolean pressed) {
			if (pressed != down) {
				down = pressed;
			}
			if (pressed) {
				presses++;
			}
		}

		public void tick() {
			if (absorbs < presses) {
				absorbs++;
				clicked = true;
			} else {
				clicked = false;
			}
		}
	}

	public List<Key> keys = new ArrayList<Key>();

	public Key up = new Key();
	public Key down = new Key();
	public Key left = new Key();
	public Key right = new Key();
	public Key attack = new Key();
	public Key menu = new Key();
	public Key cheatmenu = new Key();
	public Key run = new Key();
	public Key slot1 = new Key();
	public Key slot2 = new Key();
	public Key slot3 = new Key();
	public Key slot4 = new Key();
	public Key slot5 = new Key();
	public Key slot6 = new Key();
	public Key slot7 = new Key();
	public Key slot8 = new Key();
	public Key slot9 = new Key();
;
	
	public void releaseAll() {
		for (int i = 0; i < keys.size(); i++) {
			keys.get(i).down = false;
		}
		for(int i = 0; i < KeyBinding.keybindings.size(); i++) {
			KeyBinding.keybindings.get(i).down = false;
		}
	}

	public void tick() {
		for (int i = 0; i < keys.size(); i++) {
			keys.get(i).tick();
		}
		for(int i = 0; i < KeyBinding.keybindings.size(); i++) {
			KeyBinding.keybindings.get(i).tick();
		}
	}

	public InputHandler(Game game) {
		game.addKeyListener(this);
	}

	public void keyPressed(KeyEvent ke) {
		toggle(ke, true);
	}

	public void keyReleased(KeyEvent ke) {
		toggle(ke, false);
	}

	private void toggle(KeyEvent ke, boolean pressed) {
		if (ke.getKeyCode() == OptionFile.keys[0]) up.toggle(pressed);
		if (ke.getKeyCode() == OptionFile.keys[2]) down.toggle(pressed);
		if (ke.getKeyCode() == OptionFile.keys[1]) left.toggle(pressed);
		if (ke.getKeyCode() == OptionFile.keys[3]) right.toggle(pressed);
		
		if (ke.getKeyCode() == OptionFile.keys[9]) cheatmenu.toggle(pressed);
		if (ke.getKeyCode() == OptionFile.keys[5]) run.toggle(pressed);
		
		if (ke.getKeyCode() == KeyEvent.VK_1) slot1.toggle(pressed);
		if (ke.getKeyCode() == KeyEvent.VK_2) slot2.toggle(pressed);
		if (ke.getKeyCode() == KeyEvent.VK_3) slot3.toggle(pressed);
		if (ke.getKeyCode() == KeyEvent.VK_4) slot4.toggle(pressed);
		if (ke.getKeyCode() == KeyEvent.VK_5) slot5.toggle(pressed);
		if (ke.getKeyCode() == KeyEvent.VK_6) slot6.toggle(pressed);
		if (ke.getKeyCode() == KeyEvent.VK_7) slot7.toggle(pressed);
		if (ke.getKeyCode() == KeyEvent.VK_8) slot8.toggle(pressed);
		if (ke.getKeyCode() == KeyEvent.VK_9) slot9.toggle(pressed);

		if (ke.getKeyCode() == OptionFile.keys[8]) menu.toggle(pressed);
		if (ke.getKeyCode() == OptionFile.keys[7]) attack.toggle(pressed);
		ModLoader.toggleKey(ke, pressed);
	}

	public void keyTyped(KeyEvent ke) {
	}
}
