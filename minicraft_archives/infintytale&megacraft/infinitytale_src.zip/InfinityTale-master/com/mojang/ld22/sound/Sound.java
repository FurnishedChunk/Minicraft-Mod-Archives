package com.mojang.ld22.sound;

import java.applet.Applet;
import java.applet.AudioClip;

public class Sound {
	public static final Sound playerHurt = new Sound("/xD/playerhurt.wav");
	public static final Sound playerDeath = new Sound("/xD/death.wav");
	public static final Sound monsterHurt = new Sound("/xD/monsterhurt.wav");
	public static final Sound test = new Sound("/xD/test.wav");
	public static final Sound pickup = new Sound("/xD/pickup.wav");
	public static final Sound bossdeath = new Sound("/xD/bossdeath.wav");
	public static final Sound craft = new Sound("/xD/craft.wav");
	public static final Sound powerup = new Sound("/xD/powerup.wav");
	public static final Sound select = new Sound("/xD/select.wav");
	public static final Sound toogle = new Sound("/xD/toogle.wav");
	public static final Sound arrowshoot = new Sound("/xD/arrow.wav");
	public static final Sound special = new Sound("/xD/special.wav");
	public static final Sound tntzisch = new Sound("/xD/zisch.wav");
    public static final Sound lvlup = new Sound("/xD/lvlup.wav");
    public static final Sound smallexplosion = new Sound("/xD/smlexp.wav");
    public static final Sound jump = new Sound("/xD/jump.wav");
    
	private AudioClip clip;

	private Sound(String name) {
		try {
			clip = Applet.newAudioClip(Sound.class.getResource(name));
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	public void play() {
		try {
			new Thread() {
				public void run() {
					clip.play();
				}
			}.start();
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}
}