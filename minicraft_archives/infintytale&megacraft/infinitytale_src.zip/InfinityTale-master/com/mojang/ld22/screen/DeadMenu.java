package com.mojang.ld22.screen;

import java.awt.event.KeyEvent;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;

import de.thejackimonster.ld22.loadandsave.LoadLevel;
import de.thejackimonster.ld22.loadandsave.WorldSaveLoadMenu;
import de.thejackimonster.ld22.options.OptionFile;

public class DeadMenu extends Menu {
	private int inputDelay = 60;

	public DeadMenu() {
	}

	public void tick() {
		if (inputDelay > 0)
			inputDelay--;
		else if (input.attack.clicked) {
			game.player.removed = false;
			game.playerDeadTime = 0;
			game.player.health = game.player.maxHealth;
			game.player.stamina = game.player.maxStamina;
			game.setMenu(new TitleMenu());
		} else if (input.menu.clicked) {
			if (!game.isApplet) {
				LoadLevel lvl = new LoadLevel("world", game);
				lvl.start();
			//	game.setMenu(null);
			}
		} else if (input.cheatmenu.clicked) {
			game.player.removed = false;
			game.playerDeadTime = 0;
			game.player.x = game.respawnx;
			game.player.y = game.respawny;
			game.player.health = game.player.maxHealth;
			game.player.stamina = game.player.maxStamina;
			game.changeLevel(-game.player.level.depth);
			
			if (game.mpstate == 1) {
				game.multiplayerrespawned = true;
			}
			
			if(!game.isApplet) {
				new WorldSaveLoadMenu().saveMap(game);
			}
			game.setMenu(null);
		}
	}

	public void render(Screen screen) {
		Font.renderFrame(screen, "", 1, 4, 27, 11);
		Font.draw("You died! Aww!", screen, 2 * 8, 5 * 8, Color.get(-1, 555, 555, 555));

		int seconds = game.gameTime / 60;
		int minutes = seconds / 60;
		int hours = minutes / 60;
		minutes %= 60;
		seconds %= 60;

		String timeString = "";
		if (hours > 0) {
			timeString = hours + "h" + (minutes < 10 ? "0" : "") + minutes + "m";
		} else {
			timeString = minutes + "m " + (seconds < 10 ? "0" : "") + seconds + "s";
		}
		Font.draw("Time:", screen, 2 * 8, 6 * 8, Color.get(-1, 555, 555, 555));
		Font.draw(timeString, screen, (2 + 5) * 8, 6 * 8, Color.get(-1, 550, 550, 550));
		Font.draw("Score:", screen, 2 * 8, 7 * 8, Color.get(-1, 555, 555, 555));
		Font.draw("" + game.player.score, screen, (2 + 6) * 8, 7 * 8, Color.get(-1, 550, 550, 550));		
		Font.draw("Press " + KeyEvent.getKeyText(OptionFile.keys[9]) + " to respawn", screen, 2 * 8, 9 * 8, Color.get(-1, 333, 333, 333));
        Font.draw("Press " + KeyEvent.getKeyText(OptionFile.keys[8]) + " to load last save", screen, 2 * 8, 8 * 8, Color.get(-1, 333, 333, 333));
        Font.draw("Press " + KeyEvent.getKeyText(OptionFile.keys[7]) + " to lose", screen, 2 * 8, 10 * 8, Color.get(-1, 333, 333, 333));
	}
}
