package com.mojang.ld22.screen;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.sound.Sound;

import de.thejackimonster.ld22.loadandsave.WorldSaveLoadMenu;

public class WorldMenu extends Menu {
	private Menu parent;
	private int selectedx = 1;
	private int selectedy = 1;
	int lenx = 4;
	int leny = 7;
	private static final String[] optionsy = { "MapSize","Water", "Grass", "Rock", "Trees", "Sand", "Generate Map" };
	private static final String[] optionsx = { "Less","Normal", "Much"};
    public int[] options; 
	
	public WorldMenu(Menu parent) {
		this.parent = parent;
		this.options = new int[leny];
		
		for (int i = 0; i < leny;i++) {
			options[i] = 2;
		}
	//	this.options.length = leny;
	}


	public void render(Screen screen) {
	     	 
		screen.clear(0);
	

		String msg = "";
		int col = Color.get(0, 500, 500,500);
		
		Font.draw("More options and a bigger map", screen,0, 80, col);						   
		Font.draw("increase Load time significantly", screen,0, 80+8*1, col);						   
		

			
		for (int i = 0; i < leny; i++) {
			for (int i2 = 0; i2<lenx;i2++) {
				
				
				if (options[i] == i2) {
				 col = Color.get(0, 500, 2, 255);		
				} else {
				col = Color.get(0, 500, 52, 52);	
				}
				
				if (i2 == 0) {
				  col = Color.get(0, 70, 52, 222);		
				}
			 	
			    if (i == selectedy && i == leny-1) {
			    	col = Color.get(0, 60, 60, 60);
			    }
				
			    if (i2 == 0){
			    	msg = optionsy[i];
			  	} else {
			  		 if (i != leny-1) {
			    	  msg = optionsx[i2-1];
			  		 } else
			  		 {
			  		  msg = "";
			  		 }
				    if (i2 == selectedx && i == selectedy) {
					     col = Color.get(0, 60, 60, 60);		
					}

				    
		     	}
			    

			   
		        Font.draw(msg, screen,70*i2, (1 + i) * 8, col);						   
			  
			    }
			
		}
		}
	
	public void tick() {
		if (input.up.clicked) selectedy--;
		if (input.down.clicked) selectedy++;
		if (input.left.clicked) selectedx--;
		if (input.right.clicked) selectedx++;
		
		if (input.up.clicked || input.down.clicked || input.left.clicked || input.right.clicked){
			Sound.select.play();
		}
		
		

		
		if (selectedy < 1) selectedy += leny;
		if (selectedy >= leny) selectedy -= leny;
		if (selectedx < 1) selectedx += leny;
		if (selectedx >= lenx) selectedx -= lenx;

		if (input.attack.clicked || input.menu.clicked) {
		 if (selectedy == leny-1) {
			generateMap();
		 } else {
          options[selectedy] = selectedx;
		 }
		}
	}

	public void generateMap() {
		Sound.test.play();
		game.mapoptions = this.options;
		game.resetGame();
		game.setMenu(null);
		if(!game.isApplet) {
			new WorldSaveLoadMenu().saveMap(game);
		}
	}
}
