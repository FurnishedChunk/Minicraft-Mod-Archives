package com.mojang.ld22.screen;

import java.util.ArrayList;
import java.util.List;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.sound.Sound;

public class CheatMenu extends Menu{

	private Player player;
	private int selected = 0;

	private static final String[] stringList = {
		"Unl. Stamina", "Unl. Health", "0 Nockback", "1 Shot Res.",
		"Full Bright", "1 Shot Mobs", "Walk O. Water",
		"Walk T. Walls", "Day", "Night"//, "Hell"
	};

	public CheatMenu(Player player) {
		this.player = player;

		if (player.activeItem != null) {
			player.inventory.items.add(0, player.activeItem);
			player.activeItem = null;
		}
	}

	public void tick() {
		if (input.cheatmenu.clicked) game.setMenu(null);

		if (input.up.clicked) selected--;
		if (input.down.clicked) selected++;
		
		
		if (input.up.clicked || input.down.clicked){
			Sound.select.play();
		}

		int len = stringList.length;
		if (len == 0) selected = 0;
		if (selected < 0) selected += len;
		if (selected >= len) selected -= len;

		if (input.attack.clicked && len > 0) {
			
			Sound.toogle.play();
			//Item item = player.inventory.items.remove(selected);
			//player.activeItem = item;
			if (selected == 0) {	
		     if (player.energy == false) {
			   player.energy = true;	 
			   player.stamina = player.maxStamina;
		     }else {
		       player.energy = false; 
		     }
			}

			if (selected == 1) {	
			     if (player.unlimitedhealth == false) {
				   player.unlimitedhealth = true;
				   player.health = player.maxHealth;
			     }else {
			       player.unlimitedhealth = false; 
			     }
			}		
			
			if (selected == 2) {	
			     if (player.nonockback == false) {
				   player.nonockback = true;	 
			     }else {
			       player.nonockback = false; 
			     }
			}	
			if (selected == 3) {	
			     if (player.oneshotresources == false) {
				   player.oneshotresources = true;	 
			     }else {
			       player.oneshotresources = false; 
			     }
			}
			if (selected == 4) {	
			     if (player.nodarkness == false) {
				   player.nodarkness  = true;	 
			     }else {
			       player.nodarkness  = false; 
			     }
			}
			if (selected == 5) {	
			     if (player.oneshotmobs == false) {
				   player.oneshotmobs = true;	 
			     }else {
			       player.oneshotmobs  = false; 
			     }
			}
			if (selected == 6) {	
			     if (player.walkoverwater == false) {
				   player.walkoverwater = true;	 
			     }else {
			       player.walkoverwater  = false; 
			     }
			}
			if (selected == 7) {	
			     if (player.walkthroughwalls == false) {
				   player.walkthroughwalls  = true;	 
			     }else {
			       player.walkthroughwalls  = false; 
			     }
			}
			if (selected == 8) {	
               Sound.select.play();
               game.lightlvl = 8;
               game.rising = false;
			}
			if (selected == 9) {	
	           Sound.select.play();
	           game.lightlvl = 0;
	           game.rising = false;
			}
			if (selected == 10) {	
				if(player.level.depth == -4) {
					player.game.changeLevel(3,true);
				} else {
					player.game.changeLevel(5,true);
				}
				
			}
		//	game.setMenu(null);
		}
	}

	public void render(Screen screen) {
	    int xoff = 4;
	    int yoff = 4;
		
	    Font.renderFrame(screen, "Addon-Menu", 1+xoff, 1+yoff, 23, 18);
	    
		int aktivcol = Color.get(-1, 555, 555, 555);
		int unaktivcol = Color.get(-1, 200, 12, 12);
		int selfaktivcol = Color.get(-1,500,500,500);
		
		for(int i = 0; i < stringList.length; i++) {
			int c = unaktivcol;
			String msg = stringList[i];
			if(i == selected) msg = "> " + msg;
			if((player.energy && i == 0) ||
			   (player.unlimitedhealth && i == 1) ||
			   (player.nonockback && i == 2) ||
			   (player.oneshotresources && i == 3) ||
			   (player.nodarkness && i == 4) ||
			   (player.oneshotmobs && i == 5) ||
			   (player.walkoverwater && i == 6) ||
			   (player.walkthroughwalls && i == 7)) {
				c = aktivcol;
			} else if(i == 8 || i == 9 || i == 10) {
				c = selfaktivcol;
			}
			Font.draw(msg, screen, 3*8+xoff*8, (2+i)*8+yoff*8, c);
		}
	}
	
	public void renderItemList(Screen screen, int xo, int yo, int x1, int y1, List<? extends ListItem> listItems, int selected) {
		boolean renderCursor = true;
		if (selected < 0) {
			selected = -selected - 1;
			renderCursor = false;
		}
		int h = y1 - yo - 1;
		int i0 = 0;
		int i1 = listItems.size();
		if (i1 > h) i1 = h;
		int io = selected - h / 2;
		if (io > listItems.size() - h) io = listItems.size() - h;
		if (io < 0) io = 0;

		for (int i = i0; i < i1; i++) {
			listItems.get(i + io).renderInventory(screen, (1 + xo) * 8, (i + 1 + yo) * 8);
		}

		if (renderCursor) {
			int yy = selected + 1 - io + yo;
			Font.draw(">", screen, (xo + 0) * 8+40, yy * 8+32, Color.get(-1, -1, -1, 555));
		//	Font.draw("<", screen, (xo + w) * 8, yy * 8, Color.get(5, 555, 555, 555));
		}
	}
}
	

