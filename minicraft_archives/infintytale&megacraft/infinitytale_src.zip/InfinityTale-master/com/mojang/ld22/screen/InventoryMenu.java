package com.mojang.ld22.screen;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.item.FurnitureItem;
import com.mojang.ld22.item.Item;

import de.thejackimonster.ld22.leveltree.Achievement;

public class InventoryMenu extends Menu {
	private Player player;
	private int selected = 0;

	public InventoryMenu(Player player) {
		this.player = player;

		if (player.activeItem != null) {
			player.inventory.items.add(0, player.activeItem);
			player.activeItem = null;
		}
	}

	public void tick() {
		if (input.menu.clicked) {
			game.setMenu(null);
			Achievement.openInventory.Done(game);
		}

		if (input.up.clicked) selected--;
		if (input.down.clicked) selected++;


		int len = player.inventory.items.size();
		if (len == 0) selected = 0;
		if (selected < 0) selected += len;
		if (selected >= len) selected -= len;

		if (input.slot1.clicked && len > 0) {
		//	Item item = player.inventory.items.get(selected);
		//	player.Slots[0] = item;			
		}
		if (input.slot2.clicked && len > 0) {
			Item item = player.inventory.items.get(selected);
			player.Slots[1] = item;			
		}				
		if (input.slot3.clicked && len > 0) {
			Item item = player.inventory.items.get(selected);
			player.Slots[2] = item;			
		}
		if (input.slot4.clicked && len > 0) {
			Item item = player.inventory.items.get(selected);
			player.Slots[3] = item;			
		}				
		if (input.slot5.clicked && len > 0) {
			Item item = player.inventory.items.get(selected);
			player.Slots[4] = item;			
		}
		if (input.slot6.clicked && len > 0) {
			Item item = player.inventory.items.get(selected);
			player.Slots[5] = item;			
		}				
		if (input.slot7.clicked && len > 0) {
			Item item = player.inventory.items.get(selected);
			player.Slots[6] = item;			
		}
		if (input.slot8.clicked && len > 0) {
			Item item = player.inventory.items.get(selected);
			player.Slots[7] = item;			
		}				
		if (input.slot9.clicked && len > 0) {
			Item item = player.inventory.items.get(selected);
			player.Slots[8] = item;			
		}			
		if (input.attack.clicked && len > 0) {
			Item item = player.inventory.items.get(selected);
			if(item != null) {
				item = player.inventory.items.remove(selected);
			}
			player.activeItem = item;
			game.setMenu(null);
		}
		
	}

	public void render(Screen screen) {
		Font.renderFrame(screen, "inventory", 5, 5, 26, 16);
		renderItemList(screen, 5, 5, 16, 16, player.inventory.items, selected);
	}
}