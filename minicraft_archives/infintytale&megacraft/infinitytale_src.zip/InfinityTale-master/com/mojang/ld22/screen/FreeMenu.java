package com.mojang.ld22.screen;

public class FreeMenu extends Menu {
}