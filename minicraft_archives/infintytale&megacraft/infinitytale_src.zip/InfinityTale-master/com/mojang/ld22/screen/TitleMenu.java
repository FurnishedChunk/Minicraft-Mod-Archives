package com.mojang.ld22.screen;


import java.util.Random;

import com.mojang.ld22.entity.MultiPlayer;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.sound.Sound;

import de.thejackimonster.ld22.leveltree.Achievement;
import de.thejackimonster.ld22.loadandsave.WorldSaveLoadMenu;
import de.thejackimonster.ld22.options.OptionsMenu;
import de.thejackimonster.ld22.story.character.NewCharacterMenu;
import de.zelosfan.ld22.server.Client;
import de.zelosfan.ld22.server.Server;

public class TitleMenu extends Menu {
	private int selected = 0;
	private int tickc = 0;
	private int tickcount = 0;
	private boolean cnt = false;
	private int rdm;
	
	private Random rndm = new Random();
	
	private int modx;
	private int mody;

	int titleColor; 
	private static final String[] options = { "Load Game","New Game", "Create Character", "World Menu","Join Server","Host Server", "Options", "How to play", "About" };

	public TitleMenu() {
		modx = rndm.nextInt(3)-1;
		mody = rndm.nextInt(3)-1;
	}

	public void tick() throws Exception {
	
		tickcount++;
		
		if (input.up.clicked) selected--;
		if (input.down.clicked) selected++;

		if (input.up.clicked || input.down.clicked){
			Sound.select.play();
		}
		
		
		int len = options.length;
		if (selected < 0) selected += len;
		if (selected >= len) selected -= len;

		if (cnt) tickc++;
		
		if (tickc == 20) {
			Sound.test.play();
	//		game.resetGame();
			game.setMenu(null);
		}
		
		
		if (tickcount % 2 == 0) {
		   // game.player.x++;
		    
		    game.player.x += modx ;
		    game.player.y += mody;
		}
		
		if (tickcount % 1000 == 0  && (!(game.isloadingmap))) {
			modx = rndm.nextInt(3)-1;
			mody = rndm.nextInt(3)-1;		
		}
		
		if (input.attack.clicked || input.menu.clicked) {
			if (selected == 0 && game.isloadingmap == false) {
				modx = 0;
				mody = 0;
				game.mpstate = 0;
				if(!game.isApplet && game.isloadingmap == false) {
				 	new WorldSaveLoadMenu().loadMap(game);
				}
				if(game.isApplet) game.setMenu(null);
			}
			
			if (selected == 1 && game.isloadingmap == false) {
			 game.mpstate = 0;
		     game.level.remove(game.player);
			 game.player.findStartPos(game.level);
			 cnt = true;             
			 game.level.add(game.player);
			 Achievement.newWorld.Done(game);
			}
			if(selected == 2 && game.player != null) game.setMenu(new NewCharacterMenu(game.isApplet));
			if (selected == 3 && game.isloadingmap == false) game.setMenu(new WorldMenu(this));
            if (selected == 5){
				if (game.isloadingmap == false) {
					game.player2 = new MultiPlayer(game);
					game.level.add(game.player2);
					game.mpstate = 2;
					new WorldSaveLoadMenu().loadMap(game);
					game.server = new Server(game);
					game.player2.x = game.player.y;
					game.player2.y = game.player.y;
				}	
            }
           /* if (selected == 4 && game.isloadingmap == false){
            	game.setMenu(new ConnectipMenu());
            }*/
            if (selected == 4 && game.isloadingmap == false){
				game.mpstate = 1;
			    game.client = new Client(game,true);	
				game.player2 = new MultiPlayer(game);
				game.level.add(game.player2);
            }
            if(selected == 6) game.setMenu(new OptionsMenu(false));
			if (selected == 7) game.setMenu(new InstructionsMenu(this));
			if (selected == 8) game.setMenu(new AboutMenu(this));
		}
  
	}

	public void render(Screen screen) {
		//screen.clear(0);
        
		int h = 25;
		int w = 35;

        rdm++;
        
    
        
		for (int y = 0; y < h; y++) {
			for (int x = 0; x < w; x++) {
				
			   titleColor = Color.get(0, 0, rdm+x*5+y*2, 551);
			//	screen.render(x*8, y*8,11*32 , titleColor, 0);
			}
		}
		int frX = 6;
		int frY = 5;
		int frW = 20;
		int frH = 12;
		if (!cnt) {
			Font.renderFrame(screen, "", frX, frY, frX+frW, frY+frH);
		} else {
			if(!game.isApplet) {
				new WorldSaveLoadMenu().saveMap(game);
			}
		}

		int h2 = 2;
		int w2 = 16;
		int titleColor = Color.get(-1, 107, 8, 255);
		int xo = (screen.w - w2 * 8) / 2;
		int yo = 24;
		for (int y = 0; y < h2; y++) {
			for (int x = 0; x < w2; x++) {
				screen.render(xo + x * 8, yo + y * 8, x+14 + (y + 6) * 32, titleColor, 0);
			}
		}
		
		
		for (int i = 0; i < options.length; i++) {
			String msg = options[i];
			int col = Color.get(-1, 222, 222, 222);
			if (i == selected) {
				msg = "> " + msg + " <";
				col = Color.get(-1, 555, 555, 555);
			}
			Font.draw(msg, screen, (screen.w - msg.length() * 8) / 2, (8 + i) * 8-16, col);
		}
		
		String msg = "["+game.VERSION+"]";
		Font.draw(msg, screen, (frX + frW - msg.length())*8, (frY + frH - 1)*8, Color.get(-1, 500, 500, 500));

		//Font.draw("Ver:"+game.VERSION, screen, screen.w-72, screen.h -8, Color.get(-1, 111, 111, 111));

		//Font.draw("(Arrow keys,X and C)", screen, 0, screen.h - 8, Color.get(-1, 111, 111, 111));
	     
	}
}