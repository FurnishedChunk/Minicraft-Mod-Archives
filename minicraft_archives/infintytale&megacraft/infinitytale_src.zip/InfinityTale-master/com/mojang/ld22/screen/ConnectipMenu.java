package com.mojang.ld22.screen;

import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.screen.Menu;
import com.mojang.ld22.screen.TitleMenu;

import de.thejackimonster.ld22.story.character.TextBox;

public class ConnectipMenu extends Menu {

	
	private int[] c1 = new int[3];
	private int[] c2 = new int[3];
	private int[] c3 = new int[3];
	private int selected, selectC;
	private TextBox[] tb = new TextBox[5];
	private boolean ok;

	public ConnectipMenu() {
		ok = false;
		selectC = 0;
		selected = 0;
		String s = "";
		for(int i = 0; i < 3; i++) {
			if(i == 0) {
				c1[i] = 1;
				c2[i] = 2;
				c3[i] = 5;
			}
			if(i == 1) {
				c1[i] = 0;
				c2[i] = 2;
				c3[i] = 3;
			}
			if(i == 2) {
				c1[i] = 0;
				c2[i] = 0;
				c3[i] = 2;
			}
		}
		for(int i = 0; i < 5; i++) {
			if(i == 0) s = "NAME";
			if(i == 1) s = "COLOR: " + String.valueOf(selectC);
			if(i == 2) s = "RED: " + c1[0];
			if(i == 3) s = "GREEN: " + c1[1];
			if(i == 4) s = "BLUE: " + c1[2];
			
			tb[i] = new TextBox(s, 64, 8 + i*32, 160);
			tb[i].setEnabled(false);
		}
	}

	private int ticks;

	public void onKeyClicked(int key) {
		ticks++;
		if(selected == 0 && tb[0].getEnabled() && tb.length > 0) {
			if(ticks % 2 == 0) {
				if(key == KeyEvent.VK_ENTER) {
					tb[0].setEnabled(false);
				} else {
					tb[0].Write(key);
				}
			}
		} else
		if(selected == 0 && (!tb[0].getEnabled()) && tb.length > 0) {
			if(ticks % 2 == 0) {
				if(key == KeyEvent.VK_ENTER) tb[0].setEnabled(true);
			}
		}
	}

	public void tick() {
		if(!tb[selected].getEnabled() && !ok) {
			if(input.up.clicked) selected--;
			if(input.down.clicked) selected++;
			if(selected < 0) selected = tb.length-1;
			if(selected >= tb.length) selected = 0;
		}
		
		if(ok && input.attack.clicked && this.game != null) {
			if(this.game.player != null) {
				this.game.player.color = Color.get(-1, getC(c1), getC(c2), getC(c3));
				this.game.player.username = tb[0].getText();
			}
			this.game.setMenu(new TitleMenu());
		}
		
		if(selected == 0) {
			if(input.attack.clicked && (!tb[selected].getEnabled()) && !ok) {
				tb[selected].setEnabled(true);
			}
			if(input.right.clicked && !ok) ok = true;
			if(input.left.clicked && ok) ok = false;
		}
		if(selected == 1) {
			if(input.left.clicked) selectC--;
			if(input.right.clicked) selectC++;
			if(selectC < 0) selectC = 2;
			if(selectC > 2) selectC = 0;
		}
		if(selected == 2 || selected == 3 || selected == 4) {
			if(input.left.clicked) {
				if(selectC == 0) c1[selected - 2]--;
				if(selectC == 1) c2[selected - 2]--;
				if(selectC == 2) c3[selected - 2]--;
			}
			if(input.right.clicked) {
				if(selectC == 0) c1[selected - 2]++;
				if(selectC == 1) c2[selected - 2]++;
				if(selectC == 2) c3[selected - 2]++;
			}
			if(c1[selected - 2] > 9) c1[selected - 2] = 9;
			if(c1[selected - 2] < 0) c1[selected - 2] = 0;
			if(c2[selected - 2] > 9) c2[selected - 2] = 9;
			if(c2[selected - 2] < 0) c2[selected - 2] = 0;
			if(c3[selected - 2] > 9) c3[selected - 2] = 9;
			if(c3[selected - 2] < 0) c3[selected - 2] = 0;
		}
		tb[1].setText("COLOR: " + String.valueOf(selectC));
		if(selectC == 0) {
			tb[2].setText("RED: " + String.valueOf(c1[0]));
			tb[3].setText("GREEN: " + String.valueOf(c1[1]));
			tb[4].setText("BLUE: " + String.valueOf(c1[2]));
		}
		if(selectC == 1) {
			tb[2].setText("RED: " + String.valueOf(c2[0]));
			tb[3].setText("GREEN: " + String.valueOf(c2[1]));
			tb[4].setText("BLUE: " + String.valueOf(c2[2]));
		}
		if(selectC == 2) {
			tb[2].setText("RED: " + String.valueOf(c3[0]));
			tb[3].setText("GREEN: " + String.valueOf(c3[1]));
			tb[4].setText("BLUE: " + String.valueOf(c3[2]));
		}
	}

	public void render(Screen screen) {
		screen.clear(0);
		int xo = 24;
		int yo = 40;
		int col = Color.get(-1, getC(c1), getC(c2), getC(c3));
		
		if(ok) {
			Font.draw(">OK", screen, tb[0].x0 + tb[0].x1 + 8, tb[0].y0 + 4, Color.get(-1, -1, -1, 555));
		} else {
			Font.draw("OK", screen, tb[0].x0 + tb[0].x1 + 16, tb[0].y0 + 4, Color.get(-1, -1, -1, 555));
		}
		
		for(int i = 0; i < tb.length; i++) {
			tb[i].render(screen);
			if(selected == i && !ok) {
				if(tb[selected].getEnabled()) {
					Font.draw(">", screen, tb[i].x0 - 8, tb[i].y0 + 4, Color.get(-1, -1, -1, 550));
				} else {
					Font.draw(">", screen, tb[i].x0 - 8, tb[i].y0 + 4, Color.get(-1, -1, -1, 555));
				}
			}
		}
		
		xo -= 16;
		screen.render(xo, yo + 0, 6 + 14 * 32, col, 0);
		screen.render(xo + 8, yo + 0, 7 + 14 * 32, col, 0);
		screen.render(xo, yo + 8, 6 + 15 * 32, col, 0);
		screen.render(xo + 8, yo + 8, 7 + 15 * 32, col, 0);
		
		xo += 16;
		screen.render(xo, yo + 0, 14 * 32, col, 0);
		screen.render(xo + 8, yo + 0, 1 + 14 * 32, col, 0);
		screen.render(xo, yo + 8, 15 * 32, col, 0);
		screen.render(xo + 8, yo + 8, 1 + 15 * 32, col, 0);
		
		xo += 16;
		screen.render(xo + 8, yo + 0, 6 + 14 * 32, col, 1);
		screen.render(xo, yo + 0, 7 + 14 * 32, col, 1);
		screen.render(xo + 8, yo + 8, 6 + 15 * 32, col, 1);
		screen.render(xo, yo + 8, 7 + 15 * 32, col, 1);
	}

	public int getC(int[] ix) {
		if(ix.length == 3) {
			return ix[0]*100 + ix[1]*10 + ix[2]*1;
		}
		return 0;
	}

	public void add(int[] ix, int i, int x) {
		if(ix.length == 3 && i < 3 && i > -1) {
			ix[i] += x;
		}
	}

}
