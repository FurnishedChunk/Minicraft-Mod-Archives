package com.mojang.ld22.screen;

import java.util.ArrayList;
import java.util.List;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.sound.Sound;

public class LineMessage extends Menu{

	private Player player;
	private String message;
	private int tickc;
	private int sec;

	public LineMessage(Player player,String message,int sec) {
		this.player = player;
        this.message = message;
	    this.sec = (sec+1)*5;
	}

	public void tick() {
		tickc++;
		if ((tickc / 60 == sec && tickc % 60 == 0) || input.attack.clicked || input.menu.clicked) {
        	game.setMenu(null);
        }
	}


	public void render(Screen screen) {
	    int xoff = 1;
	    int yoff = 18;
	    Font.renderFrame(screen, "", 1+xoff, 1+yoff, 28+xoff, 2+yoff);
        Font.draw(message, screen, xoff*8+18, yoff*8+12, Color.get(-1, 111, 222, 333));
	}
	
}
	

