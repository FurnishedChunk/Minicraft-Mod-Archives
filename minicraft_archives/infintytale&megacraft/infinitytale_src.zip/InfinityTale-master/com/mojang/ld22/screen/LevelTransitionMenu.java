package com.mojang.ld22.screen;

import java.util.Random;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Screen;

public class LevelTransitionMenu extends Menu {
	private int dir;
	private int time = 0;
	int rnd = 0;
	int rnd2 = 0;
	Random random = new Random();
	
	public LevelTransitionMenu(int dir) {
		this.dir = dir;
		
	}

	public void tick() {
		time += 2;
		if (time == 2) rnd2 = random.nextInt(3);
		if (time == 4 && rnd2 == 2) rnd = random.nextInt(255);
		if (time == 90) game.changeLevel(dir);
		if (time == 160) game.setMenu(null);
	}

	public void render(Screen screen) {
	int clr = Color.get(0,1,50,55);
	
	/*	for (int x = 0; x < 40; x++) {
			for (int y = 0; y < 34; y++) {
				int dd = (y + x % 2 * 2 + x / 3) - time;
				if (dd < 0 && dd > -30) {
					if (dir > 0)
						screen.render(x * 8, y * 8, 0, clr, 0);
					else
						screen.render(x * 8, screen.h - y * 8 - 8,0, clr, 0);
				}
			}
		}*/

	if(rnd2 == 0) rnd = random.nextInt(255);
		for (int x = 0; x < 40; x++) {
	for (int y = 0; y < 34; y++) {
		if(rnd2 == 1) rnd = random.nextInt(255);
		clr = Color.get(0,1,rnd,rnd+5);
		int dd = (x+ y % 2 * 2 + y / 3) - time;
		if (
				(dd < 0 && dd > -1) || 
				(dd < -4 && dd > -6)|| 
				(dd < -8 && dd > -11)|| 
				(dd < -13 && dd > -90)
				) {
		//	if (dir > 0)
		//		screen.render(x * 16,  screen.w -y * 16+8 ,1*32+1*17, clr, 32);
		//		screen.render(x * 16+8,screen.w - y * 16+8 ,1*32+1*18, clr, 32);
		//		screen.render(x * 16,screen.w -  y * 16 ,2*32+1*17, clr, 32);
		//		screen.render(x * 16+8,screen.w -  y * 16 ,2*32+1*18, clr, 32);

		//	else {
				screen.render(screen.w -x * 16,  y * 16+8 ,1*32+1*17, clr, 32);
				screen.render(screen.w -x * 16+8,  y * 16+8 ,1*32+1*18, clr, 32);
				screen.render(screen.w -x * 16,  y * 16 ,2*32+1*17, clr, 32);
				screen.render(screen.w -x * 16+8,  y * 16 ,2*32+1*18, clr, 32);

		//	}
		}
	}
    }	
	
	   /* for (int x = 0; x < 40; x++) {
    	    for (int y = 0; y < 34; y++) {
    	    	
    	      if (time % 30 == 0) {	
    			screen.render(x * 8, y * 8, 0, clr, 0);
    	      }
        	}	
     	}*/
	}
}
