package com.mojang.ld22.screen;

import java.awt.Frame;
import java.util.List;

import com.mojang.ld22.Game;
import com.mojang.ld22.InputHandler;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;

import de.thejackimonster.ld22.modloader.ModLoader;

public class SplashMenu extends Menu{
	protected Game game;
	protected InputHandler input;
	private int rdm;
	private int tickc = 0;

	public void init(Game game, InputHandler input) {
		this.input = input;
		this.game = game;
	}

	public void tick() {
		tickc++;
		if (tickc >= 200) {
			game.setMenu(new TitleMenu());
		}
	}
	

	public void render(Screen screen) {
        int titleColor;
		int h = 5;
		int w = 46;
        rdm++;
        
        screen.clear(0);  

        
		for (int y = 3; y < h; y++) {
			for (int x = 17; x < w; x++) {
				
			   ///titleColor = Color.get(0, 0, rdm+x*5+y*2, 551);
				titleColor = Color.get(rdm+x*8, rdm+x*8, rdm+x*8, rdm+x*8);
				screen.render(x*4, y*8,11*32 , titleColor, 0);
			}
		}
		
		
		
		h = 25;
		w = 35;

        rdm++;
        
    
        
		for (int y = 0; y < h; y++) {
			for (int x = 0; x < w; x++) {
				
			   titleColor = Color.get(0, 0, rdm+x*5+y*2, 551);
		//		titleColor = Color.get(0, 0,1, 551);
				screen.render(x*8, y*8,11*32+3 , titleColor, 0);
			}
		}
		
		Font.renderFrame(screen, "", 2, 2, 28, 20);
		h = 20;
		w = 28;	
		for (int y = 3; y < h; y++) {
			for (int x = 3; x < w; x++) {
				
		//	   titleColor = Color.get(0, 0, rdm+x*5+y*2, 551);
				titleColor = Color.get(0, 0,1, 551);
				screen.render(x*8, y*8,11*32+3 , titleColor, 0);
			}
		}	
		
		int h2 = 2;
		int w2 = 16;
	//	titleColor = Color.get(-1, 107, 8, -1);
		titleColor = Color.get(-1, 107, 8, 999);
		int xo = (screen.w - w2 * 8) / 2;
		int yo = 24;
		for (int y = 0; y < h2; y++) {
			for (int x = 0; x < w2; x++) {
				screen.render(xo + x * 8, yo + y * 8, x+14 + (y + 6) * 32, titleColor, 0);
			}
		}
		
		
		
	    Font.draw("TheJackiMonster", screen,66, 60, Color.get(-1, 500, 500, 500));
	    
	    Font.draw("Zelosfan", screen,90, 76, Color.get(-1, 500, 500, 500));
	    
	    Font.draw("Minicraft: Notch", screen,60, 140, Color.get(-1, 3, 3, 3));
	}


}
