package com.mojang.ld22.item;

import java.util.ArrayList;
import java.util.List;

import com.mojang.ld22.entity.Anvil;
import com.mojang.ld22.entity.Chest;
import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.Furnace;
import com.mojang.ld22.entity.ItemEntity;
import com.mojang.ld22.entity.Lantern;
import com.mojang.ld22.entity.Oven;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.entity.TNT;
import com.mojang.ld22.entity.Torch;
import com.mojang.ld22.entity.Workbench;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.item.resource.Resource;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.level.tile.Tile;
import com.mojang.ld22.screen.ListItem;

public class Item implements ListItem {

	public static List<Item> items = new ArrayList<Item>();

	public static int id;

	public Item(String name) {
		if(this instanceof ResourceItem) {
			((ResourceItem)this).count = 1;
		}
		this.addItem(this, name);
	}

	public static void addItem(Item item, String s) {
		boolean flag = true;
		for(int i = 0; i < items.size(); i++) {
			if(items.get(i).getName().equalsIgnoreCase(s)) {
				flag = false;
				id = i;
			}
		}
		if(flag) {
			id = items.size();
			items.add(item);
		}
	}

	public static int getIDOfName(String name) {
		int i1 = 0;
		for(int i = 0; i < items.size(); i++) {
			if(items.get(i).getName().equalsIgnoreCase(name)) {
				i1 = i;
			}
		}
		return i1;
	}

	public int getColor() {
		return 0;
	}

	public int getSprite() {
		return 0;
	}

	public void onTake(ItemEntity itemEntity) {
	}

	public void renderInventory(Screen screen, int x, int y) {
	}

	public boolean interact(Player player, Entity entity, int attackDir) {
		return false;
	}

	public void renderIcon(Screen screen, int x, int y) {
	}

	public boolean interactOn(Tile tile, Level level, int xt, int yt, Player player, int attackDir) {
		return false;
	}
	
	public boolean isDepleted() {
		return false;
	}

	public boolean canAttack() {
		return false;
	}

	public int getAttackDamageBonus(Entity e) {
		return 0;
	}

	public String getName() {
		return "";
	}

	public boolean matches(Item item) {
		return item.getClass() == getClass();
	}

	public static Item woodenSword = new ToolItem(ToolType.sword, 0);
	public static Item woodenPickaxe = new ToolItem(ToolType.pickaxe, 0);
	public static Item woodenAxe = new ToolItem(ToolType.axe, 0);
	public static Item woodenShovel = new ToolItem(ToolType.shovel, 0);
	public static Item woodenHoe = new ToolItem(ToolType.hoe, 0);
	public static Item woodenHammer = new ToolItem(ToolType.hammer, 0);
	public static Item woodenBow = new ToolItem(ToolType.bow, 0);
	public static Item stoneSword = new ToolItem(ToolType.sword, 1);
	public static Item stonePickaxe = new ToolItem(ToolType.pickaxe, 1);
	public static Item stoneAxe = new ToolItem(ToolType.axe, 1);
	public static Item stoneShovel = new ToolItem(ToolType.shovel, 1);
	public static Item stoneHoe = new ToolItem(ToolType.hoe, 1);
	public static Item stoneHammer = new ToolItem(ToolType.hammer, 1);
	public static Item ironSword = new ToolItem(ToolType.sword, 2);
	public static Item ironPickaxe = new ToolItem(ToolType.pickaxe, 2);
	public static Item ironAxe = new ToolItem(ToolType.axe, 2);
	public static Item ironShovel = new ToolItem(ToolType.shovel, 2);
	public static Item ironHoe = new ToolItem(ToolType.hoe, 2);
	public static Item ironHammer = new ToolItem(ToolType.hammer, 2);
	public static Item goldSword = new ToolItem(ToolType.sword, 3);
	public static Item goldPickaxe = new ToolItem(ToolType.pickaxe, 3);
	public static Item goldAxe = new ToolItem(ToolType.axe, 3);
	public static Item goldShovel = new ToolItem(ToolType.shovel, 3);
	public static Item goldHoe = new ToolItem(ToolType.hoe, 3);
	public static Item goldHammer = new ToolItem(ToolType.hammer, 3);
	public static Item gemSword = new ToolItem(ToolType.sword, 4);
	public static Item gemPickaxe = new ToolItem(ToolType.pickaxe, 4);
	public static Item gemAxe = new ToolItem(ToolType.axe, 4);
	public static Item gemShovel = new ToolItem(ToolType.shovel, 4);
	public static Item gemHoe = new ToolItem(ToolType.hoe, 4);
	public static Item gemHammer = new ToolItem(ToolType.hammer, 4);

	public static Item ironbukket = new ToolItem(ToolType.bucket, 2);
	public static Item powerglove = new PowerGloveItem();
	public static Item heartcontainer = new HeartContainer();
	public static Item flintandsteel = new ToolItem(ToolType.flintnsteel, 2);
	public static Item stonebow = new ToolItem(ToolType.bow, 1);
	public static Item gembow = new ToolItem(ToolType.bow, 4);

	public static Item anvil = new FurnitureItem(new Anvil());
	public static Item chest = new FurnitureItem(new Chest());
	public static Item furnace = new FurnitureItem(new Furnace());
	public static Item lantern = new FurnitureItem(new Lantern());
	public static Item oven = new FurnitureItem(new Oven());
	public static Item tnt = new FurnitureItem(new TNT());
	public static Item torch = new FurnitureItem(new Torch());
	public static Item workbench = new FurnitureItem(new Workbench());

	public static Item wood = new ResourceItem(Resource.wood);
	public static Item stone = new ResourceItem(Resource.stone);
	public static Item flower = new ResourceItem(Resource.flower);
	public static Item acorn = new ResourceItem(Resource.acorn);
	public static Item dirt = new ResourceItem(Resource.dirt);
	public static Item sand = new ResourceItem(Resource.sand);
	public static Item cactusFlower = new ResourceItem(Resource.cactusFlower);
	public static Item seeds = new ResourceItem(Resource.seeds);
	public static Item wheat = new ResourceItem(Resource.wheat);
	public static Item bread = new ResourceItem(Resource.bread);
	public static Item apple = new ResourceItem(Resource.apple);

	public static Item rock = new ResourceItem(Resource.rock);
	public static Item tree = new ResourceItem(Resource.tree);
	public static Item water = new ResourceItem(Resource.water);
	public static Item ironoreblock = new ResourceItem(Resource.ironoreblock);
	public static Item wooddoor = new ResourceItem(Resource.wooddoor);
	public static Item woodfloor = new ResourceItem(Resource.woodfloor);
	public static Item woodplank = new ResourceItem(Resource.woodplank);
	public static Item glowstone = new ResourceItem(Resource.glowstone);
	public static Item glowOre = new ResourceItem(Resource.glowstoneOre);

	public static Item carpet = new ResourceItem(Resource.carpet);
	public static Item stoneplank = new ResourceItem(Resource.stoneplank);
	
	public static Item coal = new ResourceItem(Resource.coal);
	public static Item ironOre = new ResourceItem(Resource.ironOre);
	public static Item goldOre = new ResourceItem(Resource.goldOre);

	public static Item ironIngot = new ResourceItem(Resource.ironIngot);
	public static Item goldIngot = new ResourceItem(Resource.goldIngot);

	public static Item slime = new ResourceItem(Resource.slime);
	public static Item glass = new ResourceItem(Resource.glass);
	public static Item cloth = new ResourceItem(Resource.cloth);
	public static Item gem = new ResourceItem(Resource.gem);
	
	public static Item grHook = new Enterhaken();
	public static Item crHook = new Greifhaken();
}