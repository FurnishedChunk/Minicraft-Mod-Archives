package com.mojang.ld22.item;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.Furniture;
import com.mojang.ld22.entity.ItemEntity;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.level.tile.Tile;
import com.mojang.ld22.item.resource.Resource;

public class Experience extends Item {
	Player player;
	int exp;
	
	public Experience(Player player,int exp) {
	   super("Experience");
	   this.player = player;
	   this.exp = exp;
	}

	public int getColor() {
		return Color.get(-1, 50, 90, 70);
	}

	public int getSprite() {
		return 0 + 4 * 32;
	}
	
	public void onTake(ItemEntity itemEntity) {
	  player.exp += exp;
	}
	

}