package com.mojang.ld22.item;

public class ToolType {
	public static ToolType hammer = new ToolType("Hammer", 0);
	public static ToolType shovel = new ToolType("Shvl", 1);
	public static ToolType hoe = new ToolType("Hoe", 2);
	public static ToolType sword = new ToolType("Swrd", 3);
	public static ToolType pickaxe = new ToolType("Pick", 4);
	public static ToolType axe = new ToolType("Axe", 5);
	public static ToolType bucket = new ToolType("Bucket", 6);
	public static ToolType flintnsteel = new ToolType("FlintNSteel", 7);
	public static ToolType bow = new ToolType("Bow", 8);
	
	public final String name;
	public final int sprite;

	private ToolType(String name, int sprite) {
		this.name = name;
		this.sprite = sprite;
	}
}
