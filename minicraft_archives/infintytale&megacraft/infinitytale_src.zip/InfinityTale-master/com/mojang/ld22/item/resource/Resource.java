package com.mojang.ld22.item.resource;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.level.tile.OreTile;
import com.mojang.ld22.level.tile.Tile;

public class Resource {
	public static Resource wood = new Resource("Wood", 1 + 4 * 32, Color.get(-1, 200, 531, 430));
	public static Resource stone = new Resource("Stone", 2 + 4 * 32, Color.get(-1, 111, 333, 555));
	public static Resource flower = new PlantableResource("Flower", 0 + 4 * 32, Tile.flower, Color.get(-1, 10, 444, 330), Tile.grass);
	public static Resource acorn = new PlantableResource("Acorn", 3 + 4 * 32,  Tile.treeSapling,Color.get(-1, 100, 531, 320), Tile.grass);
	public static Resource dirt = new PlantableResource("Dirt", 2 + 4 * 32,  Tile.dirt,Color.get(-1, 100, 322, 432), Tile.hole, Tile.water, Tile.lava);
	public static Resource sand = new PlantableResource("Sand", 2 + 4 * 32,  Tile.sand,Color.get(-1, 110, 440, 550), Tile.grass, Tile.dirt);
	public static Resource cactusFlower = new PlantableResource("Cactus", 4 + 4 * 32, Tile.cactusSapling, Color.get(-1, 10, 40, 50), Tile.sand);
	public static Resource seeds = new PlantableResource("Seeds", 5 + 4 * 32,  Tile.wheat,Color.get(-1, 10, 40, 50), Tile.farmland);
	public static Resource wheat = new Resource("Wheat", 6 + 4 * 32, Color.get(-1, 110, 330, 550));
	public static Resource bread = new FoodResource("Bread", 8 + 4 * 32, Color.get(-1, 110, 330, 550), 2, 5);
	public static Resource apple = new FoodResource("Apple", 9 + 4 * 32, Color.get(-1, 100, 300, 500), 1, 5);

	public static Resource rock = new PlantableResource("Rock", 10*32+1 ,  Tile.rock,Color.get(-1, 444,333, 333), Tile.grass, Tile.dirt, Tile.farmland,Tile.sand);
	public static Resource tree = new PlantableResource("Tree", 10*32+1 ,  Tile.tree, Color.get(-1, 420, 430, 430),Tile.grass, Tile.dirt, Tile.farmland);
	public static Resource water = new PlantableResource("Water Bucket", 5*32+6 ,  Tile.water,Color.get(-1, 1, 444, 333), Tile.hole);
	public static Resource ironoreblock = new PlantableResource("Iron Ore", 10*32+1 ,  Tile.tree,Color.get(-1, 220, 430, 430), Tile.grass, Tile.dirt, Tile.farmland,Tile.sand);
	public static Resource woodplank = new PlantableResource("Wooden Plank", 10*32+1 ,  Tile.woodplanktile,Color.get(-1, 220, 430, 430), Tile.grass, Tile.dirt, Tile.farmland,Tile.sand);
	public static Resource woodfloor = new PlantableResource("Wooden Floor", 10*32+1 ,  Tile.woodfloor,Color.get(-1, 220, 430, 430), Tile.grass, Tile.dirt, Tile.farmland,Tile.sand);
	public static Resource wooddoor = new PlantableResource("Wooden Door", 10*32+1 ,  Tile.woodendoor,Color.get(-1, 220, 430, 430), Tile.grass, Tile.dirt, Tile.farmland,Tile.sand);

	public static Resource stoneplank = new PlantableResource("Stone Plank", 10*32+1 ,  Tile.stoneplank,Color.get(-1,111, 444, 555), Tile.grass, Tile.dirt, Tile.farmland,Tile.sand);
	public static Resource carpet = new PlantableResource("Red Carpet", 10*32+1 ,  Tile.carpet,Color.get(-1, 220, 500, 510), Tile.woodfloor);
	
	public static Resource glowstone = new PlantableResource("Glowstone", 10*32+1 , Tile.glowstone, Color.get(-1, 220, 540, 560), Tile.grass, Tile.dirt, Tile.farmland,Tile.sand);
	

	public static Resource glowstoneOre = new Resource("Glowstone Ore", 10 + 4 * 32, Color.get(-1, 100, 540, 544));
    public static Resource coal = new Resource("COAL", 10 + 4 * 32, Color.get(-1, 000, 111, 111));
	public static Resource ironOre = new Resource("I.ORE", 10 + 4 * 32, Color.get(-1, 100, 322, 544));
	public static Resource goldOre = new Resource("G.ORE", 10 + 4 * 32, Color.get(-1, 110, 440, 553));
	public static Resource ironIngot = new Resource("IRON", 11 + 4 * 32, Color.get(-1, 100, 322, 544));
	public static Resource goldIngot = new Resource("GOLD", 11 + 4 * 32, Color.get(-1, 110, 330, 553));

	public static Resource slime = new Resource("SLIME", 10 + 4 * 32, Color.get(-1, 10, 30, 50));
	public static Resource glass = new Resource("glass", 12 + 4 * 32, Color.get(-1, 555, 555, 555));
	public static Resource cloth = new Resource("cloth", 1 + 4 * 32, Color.get(-1, 25, 252, 141));
	public static Resource cloud = new PlantableResource("cloud", 2 + 4 * 32,  Tile.cloud,Color.get(-1, 222, 555, 444), Tile.infiniteFall);
	public static Resource gem = new Resource("gem", 13 + 4 * 32, Color.get(-1, 101, 404, 545));

	public final String name;
	public final int sprite;
	public final int color;

	public Resource(String name, int sprite, int color) {
		//if (name.length() > 6) throw new RuntimeException("Name cannot be longer than six characters!");
		this.name = name;
		this.sprite = sprite;
		this.color = color;
	}

	public boolean interactOn(Tile tile, Level level, int xt, int yt, Player player, int attackDir) {
		return false;
	}
}