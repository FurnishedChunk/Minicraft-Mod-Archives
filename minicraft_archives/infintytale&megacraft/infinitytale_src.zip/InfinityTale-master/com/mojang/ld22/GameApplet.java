package com.mojang.ld22;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Dimension;

import de.thejackimonster.ld22.modloader.ModLoader;
import de.thejackimonster.ld22.modloader.UseMods;


public class GameApplet extends Applet {
	private static final long serialVersionUID = 1L;

	private Game game = new Game();

	public void init() {
		setName(game.NAME);
		setSize(new Dimension(game.WIDTH * game.SCALE, game.HEIGHT * game.SCALE));
		setLayout(new BorderLayout());
		add(game, BorderLayout.CENTER);

		game.isApplet = true;
		ModLoader.addGame(game);

		UseMods.addMods();
		ModLoader.loadAllMods();
	}

	public void start() {
		game.start(true);
	}

	public void stop() {
		game.stop();
	}
}