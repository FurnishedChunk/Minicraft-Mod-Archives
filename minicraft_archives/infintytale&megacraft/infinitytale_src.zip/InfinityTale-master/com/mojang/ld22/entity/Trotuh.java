package com.mojang.ld22.entity;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.item.Experience;
import com.mojang.ld22.item.ResourceItem;
import com.mojang.ld22.item.resource.Resource;
import com.mojang.ld22.level.tile.Tile;

public class Trotuh extends Mob {
	private int xa, ya;
	public int lvl;
	private int randomWalkTime = 0;
    static boolean atkplayer = false;
	public Trotuh(int lvl) {
		super("Trutuh");
		this.lvl = lvl;
		x = random.nextInt(64 * 16);
		y = random.nextInt(64 * 16);
		health = maxHealth = lvl * lvl * 10;

	}

	
	
	public void tick() {
		if (level.game.mpstate != 1) {
		super.tick();
	level.setTile(this.x, this.y, Tile.dirt, 0);
		level.setTile(this.x/16, this.y/16, Tile.dirt, 0);
		if (level.player != null  && atkplayer) {
			int xd = level.player.x - x;
			int yd = level.player.y - y;
			//if (xd * xd + yd * yd < 500 * 500) {
				xa = 0;
				ya = 0;
				if (xd < 0) xa = -1;
				if (xd > 0) xa = +1;
				if (yd < 0) ya = -1;
				if (yd > 0) ya = +1;
			//}
		}
		int speed = tickTime & 1;
		if (!move(xa * speed, ya * speed) || random.nextInt(200) == 0) {

			xa = (random.nextInt(3) - 1) * random.nextInt(2);
			ya = (random.nextInt(3) - 1) * random.nextInt(2);
		}

		}
	}
	
		public boolean move(int xa, int ya) {
	/*	if (player.level.game.mpstate == 2) {	
		 player.level.game.server.updatezombiepos();
		}*/
		level.setTile(x, y, Tile.dirt, 0);
		return super.move(xa,ya);
	}

	public void render(Screen screen) {
		int xt = 16;
		int yt = 16;

		int flip1 = (walkDist >> 3) & 1;
		int flip2 = (walkDist >> 3) & 1;

		if (dir == 1) {
			xt += 2;
		}
		if (dir > 1) {

			flip1 = 0;
			flip2 = ((walkDist >> 4) & 1);
			if (dir == 2) {
				flip1 = 1;
			}
			xt += 4 + ((walkDist >> 3) & 1) * 2;
		}

		int xo = x - 8;
		int yo = y - 11;

		int col = Color.get(-1, 0, 502, 401);
	//	if (lvl == 2) col = Color.get(-1, 100, 522, 050);
	//	if (lvl == 3) col = Color.get(-1, 111, 444, 050);
	//	if (lvl == 4) col = Color.get(-1, 000, 111, 020);
		if (hurtTime > 0) {
			col = Color.get(-1, 555, 555, 555);
		}

		screen.render(xo + 8 * flip1, yo + 0, xt + yt * 32, col, flip1);
		screen.render(xo + 8 - 8 * flip1, yo + 0, xt + 1 + yt * 32, col, flip1);
		
		if (!this.isSwimming()) {
		 screen.render(xo + 8 * flip2, yo + 8, xt + (yt + 1) * 32, col, flip2);
		 screen.render(xo + 8 - 8 * flip2, yo + 8, xt + 1 + (yt + 1) * 32, col, flip2);
		}
	}

	protected void touchedBy(Entity entity) {
		if (entity instanceof Player && this.atkplayer) {
			entity.hurt(this, lvl + 1, dir);
		}
	}

	public boolean canSwim() {
		return false;
	}	
	
	protected void die() {
		super.die();
        atkplayer = true;
		int count = random.nextInt(2) + 1;
		for (int i = 0; i < count; i++) {
			
			if (!this.isSwimming()) {
			 level.add(new ItemEntity(new ResourceItem(Resource.cloth), x + random.nextInt(11) - 5, y + random.nextInt(11) - 5));
				}
		}

		if (level.player != null && !this.isSwimming()) {
			level.player.score += 50 * lvl;
			level.add(new ItemEntity(new Experience(level.player, 10*lvl), x + random.nextInt(11) - 5, y + random.nextInt(11) - 5 ));
		}

	}

}