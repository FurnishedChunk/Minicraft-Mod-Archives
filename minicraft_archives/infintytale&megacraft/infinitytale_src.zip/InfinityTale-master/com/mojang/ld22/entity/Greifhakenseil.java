package com.mojang.ld22.entity;

import java.util.List;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.level.tile.Tile;


public class Greifhakenseil extends Entity {
 private int lifeTime;
 private int xdir;
 private int ydir;
 private final int speed=2;
 private int time;
 private int damage;
 private Mob owner;
 private Greifhakending ent;

 public Greifhakenseil(int dirx,int diry,Greifhakending ent) {
  super("Greifhakenseil");

  this.ent = ent;
  xdir = dirx;
  ydir = diry;
        
  
  x=ent.x;
  y=ent.y;
  
 }

 public void tick() {

	  List<Entity> entitylist = level.getEntities(x, y, x, y);
	  for(int i = 0; i < entitylist.size(); i++) {
	   Entity hit = entitylist.get(i);
	   if(hit != null) {
		   if (hit instanceof Player) {
			   this.remove();			   
		   }
	   }
	  }
 // if (level.getTile(x/16, y/16).mayPass(level, x/16, y/16, this) || level.getTile(x/16, y/16) instanceof Tile.water )) {
  if(ent.removed) {
	  this.remove();
  }
  
 }

 public boolean isBlockableBy(Mob mob) {
  return false;
 }

 public void render(Screen screen) {
  int xt;
  int yt;

  if (xdir != 0){
    xt = 5;
    yt = 11;

      screen.render(x - 4, y - 4 - 2, xt + yt * 32, Color.get(-1, 555, 555, 555), random.nextInt(4));
         screen.render(x - 4, y - 4 + 2, xt + yt * 32, Color.get(-1, 000, 000, 000), random.nextInt(4));
     
  }else{
    xt = 6;
    yt = 11;
     screen.render(x - 4, y - 4 - 2, xt + yt * 32, Color.get(-1, 555, 555, 555), random.nextInt(4));
        screen.render(x - 4, y - 4 + 2, xt + yt * 32, Color.get(-1, 000, 000, 000), random.nextInt(4));
  }
 }
}