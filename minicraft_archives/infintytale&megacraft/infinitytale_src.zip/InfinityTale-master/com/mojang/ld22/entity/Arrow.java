package com.mojang.ld22.entity;

import java.util.List;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.level.tile.Tile;

import de.thejackimonster.ld22.leveltree.Skill;
import de.thejackimonster.ld22.leveltree.mod_leveltree;
import de.thejackimonster.ld22.options.OptionFile;

public class Arrow extends Entity {
 private int lifeTime;
    private int xdir;
    private int ydir;
    private final int speed=2;
 private int time;
 private int damage;
 private Mob owner;
 private int color;



 public Arrow(Mob owner, int dirx,int diry,int dmg, boolean flag) {
  super("Arrow");
  this.owner = owner;
  xdir = dirx;
  ydir = diry;
        
  damage = dmg;
  color = Color.get(-1, 555, 555, 555);
  if(flag) {
	  damage *= 2;
	  color = Color.get(-1, 540, 540, 540);
  }
  
  x=owner.x;
  y=owner.y;

  lifeTime = 60 * 3 + random.nextInt(30);
  
  if (owner instanceof Player) {
	  if ( ((Player) owner).oneshotmobs ) {
		  damage = 9999;
	  }
  }
  
 }

 public void tick() {
  time++;
  if (time >= lifeTime) {
   remove();
   return;
  }

  x += xdir*speed;
  y += ydir*speed;
  List<Entity> entitylist = level.getEntities(x, y, x, y);
  for(int i = 0; i < entitylist.size(); i++) {
   Entity hit = entitylist.get(i);
   if(hit != null) {
    if (hit instanceof Mob && hit != owner) {
     hit.hurt(owner, damage, ((Mob) hit).dir ^ OptionFile.difficulty);
    }
   }
  }
  
 // if (level.getTile(x/16, y/16).mayPass(level, x/16, y/16, this) || level.getTile(x/16, y/16) instanceof Tile.water )) {
  if (level.getTile(x/16, y/16).mayPass(level, x/16, y/16, this )) {
     
   
  } else {
   this.remove(); 
  }
  
 }

 public boolean isBlockableBy(Mob mob) {
  return false;
 }

 public void render(Screen screen) {
  if (time >= lifeTime - 6 * 20) {
   if (time / 6 % 2 == 0) return;
  }
  int xt;
  int yt;

  if (xdir != 0){
    xt = 2;
    yt = 11;

      screen.render(x - 4, y - 4 - 2, xt + yt * 32, color, random.nextInt(4));
         screen.render(x - 4, y - 4 + 2, xt + yt * 32, Color.get(-1, 000, 000, 000), random.nextInt(4));
     
  }else{
    xt = 1;
    yt = 11;
     screen.render(x - 4, y - 4 - 2, xt + yt * 32, color, random.nextInt(4));
        screen.render(x - 4, y - 4 + 2, xt + yt * 32, Color.get(-1, 000, 000, 000), random.nextInt(4));
  }
 }
}