package com.mojang.ld22.entity;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Screen;

public class Skeleton extends Zombie {

	private int xa, ya;
	private int randomWalkTime = 0;
	private int stamina;

	public Skeleton(int lvl) {
		super(lvl);
	}

	public void tick() {
		super.tick();
		if(tickTime % 30 == 0 && stamina < 3) {
			stamina++;
		}
		if(stamina > 3) stamina = 3;
		if(stamina < 0) stamina = 0;
		if (level.player != null && randomWalkTime == 0) {
			int xd = level.player.x - x;
			int yd = level.player.y - y;
			if (xd * xd + yd * yd < 60 * 60) {
				xa = 0;
				ya = 0;
				if (xd < 0) xa = -1;
				if (xd > 0) xa = +1;
				if (yd < 0) ya = -1;
				if (yd > 0) ya = +1;
			}
			if(xd * xd + yd * yd < 50 * 50 && stamina == 3) {
				xa = 0;
				ya = 0;
				stamina -= 3;
				switch (dir) {
                case 0:
                	level.add(new Arrow(this,0,1,1, walkoverwater));
                	break;
                case 1:
                	level.add(new Arrow(this,0,-1,1, walkoverwater));
                	break;
                case 2:
                	level.add(new Arrow(this,-1,0,1, walkoverwater));
                	break;
                case 3:
                	level.add(new Arrow(this,1,0,1, walkoverwater));
                	break;
                default:
                	break;
				}
			}
		}

		int speed = tickTime & 1;
		if (!move(xa * speed, ya * speed) || random.nextInt(200) == 0 || stamina == 0) {
			randomWalkTime = 60;
			xa = (random.nextInt(3) - 1) * random.nextInt(2);
			ya = (random.nextInt(3) - 1) * random.nextInt(2);
		}
		if (randomWalkTime > 0) randomWalkTime--;
	}

	public void render(Screen screen) {
		int xt = 16;
		int yt = 14;

		int flip1 = (walkDist >> 3) & 1;
		int flip2 = (walkDist >> 3) & 1;

		if (dir == 1) {
			xt += 2;
		}
		if (dir > 1) {

			flip1 = 0;
			flip2 = ((walkDist >> 4) & 1);
			if (dir == 2) {
				flip1 = 1;
			}
			xt += 4 + ((walkDist >> 3) & 1) * 2;
		}

		int xo = x - 8;
		int yo = y - 11;

		int col = Color.get(-1, 111, 444, 555);
		
		if (level.depth == -4) {
			col = Color.get(-1, 500, 444,555);
		}
		
		if (hurtTime > 0) {
			col = Color.get(-1, 555, 555, 555);
		}

		screen.render(xo + 8 * flip1, yo + 0, xt + yt * 32, col, flip1);
		screen.render(xo + 8 - 8 * flip1, yo + 0, xt + 1 + yt * 32, col, flip1);
		screen.render(xo + 8 * flip2, yo + 8, xt + (yt + 1) * 32, col, flip2);
		screen.render(xo + 8 - 8 * flip2, yo + 8, xt + 1 + (yt + 1) * 32, col, flip2);
	}

	public boolean canSwim() {
		return false;
	}

}
