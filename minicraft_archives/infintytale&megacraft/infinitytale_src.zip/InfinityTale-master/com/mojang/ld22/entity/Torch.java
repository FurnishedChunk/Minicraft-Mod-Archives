package com.mojang.ld22.entity;

import java.util.Random;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.item.ToolItem;
import com.mojang.ld22.item.ToolType;
import com.mojang.ld22.screen.ContainerMenu;

public class Torch extends Furniture {
	public Inventory inventory = new Inventory();
	public boolean on = false;
	public boolean poweredup = false;
	Random random = new Random();

	public Torch() {
		super("Torch");
		
		
		col = Color.get(-1, 110, 0, 111);
		sprite = 6;
	}

	public boolean use(Player player, int attackDir) {
	 //	player.game.setMenu(new ContainerMenu(player, "Torch", inventory));
		
		if (on) {
			on = false;
			poweredup = false;
			col = Color.get(-1, 110, 0, 111);
		} else {
			on = true;
			col = Color.get(-1, 110, 550, 480);
			if (player.activeItem instanceof ToolItem) {
			 
			  ToolItem tool = (ToolItem) player.activeItem;
              if(tool.type == ToolType.flintnsteel) {			
			   
			   poweredup = true;
			   col = Color.get(-1, 110, 550, 1);
              } else {
            	  poweredup = false;
              }
			}
		}
		return true;
	}
	public int getLightRadius() {
		
		if (on) {
		  if (poweredup) return 7;	
		  return 5;
		}
		return 0;
	}
}