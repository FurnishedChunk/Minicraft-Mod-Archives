package com.mojang.ld22.entity;

import java.util.List;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.level.tile.Tile;


public class Enterhakending extends Entity {
 private int lifeTime;
 private int xdir;
 private int ydir;
 private final int speed=4;
 private int time;
 private int damage;
 private Mob owner;
 private boolean stuck = false;

 public Enterhakending(Mob owner, int dirx,int diry,int dmg) {
  super("Enterhakending");
  this.owner = owner;
  xdir = dirx;
  ydir = diry;
        
  damage = dmg;
  
  x=owner.x;
  y=owner.y;

  lifeTime = 20 * 3;
  

  
  if (owner instanceof Player) {
	  if ( ((Player) owner).oneshotmobs ) {
		  damage = 9999;
	  }
  }
  
 }

 public void tick() {
  time++;
  if (time >= lifeTime && !stuck) {
   level.player.ishooking = false;
   remove();
   return;
  }
  if (!stuck) {
  level.add(new Enterhakenseil(xdir, ydir, this));
  x += xdir*speed;
  y += ydir*speed;
  }
  List<Entity> entitylist = level.getEntities(x-10, y-10, x+10, y+10);
  for(int i = 0; i < entitylist.size(); i++) {
   Entity hit = entitylist.get(i);
   if(hit != null) {
	   if (hit instanceof Player && stuck) {
		   ((Player) hit).ishooking = false;
		   this.remove();
		   
	   }
	   if (hit instanceof Mob && (!(hit instanceof Player))) {
		   stuck = true;
		   ((Mob) hit).hurt(level.player, 1, 0);
	   }
	   if (hit instanceof ItemEntity) {
		   ((ItemEntity) hit).touchedBy(level.player);
//		   ((ItemEntity) hit).take(level.player);
	   }

   }
  
  }
 // if (level.getTile(x/16, y/16).mayPass(level, x/16, y/16, this) || level.getTile(x/16, y/16) instanceof Tile.water )) {
  if (level.getTile(x/16, y/16).mayPass(level, x/16, y/16, this ) || level.getTile(x/16, y/16).id == Tile.water.id  || level.getTile(x/16, y/16).id == Tile.lava.id ) {
     
   
  } else {
 //  this.remove(); 

      stuck = true;

  }
  
  if (stuck == true) {
	  level.remove(level.player);
	  if (level.player.x < this.x) {
		  level.player.x += 4;
	  } else if (level.player.x> this.x) {
		  level.player.x -= 4;
	  }
	  if (level.player.y < this.y) {
		  level.player.y += 4;
	  } else if (level.player.y> this.y) {
		  level.player.y -= 4;
	  }

	  level.add(level.player);  
  }
  
 }

 public boolean isBlockableBy(Mob mob) {
  return false;
 }

 public void render(Screen screen) {
  if (time >= lifeTime - 6 * 20) {
   if (time / 6 % 2 == 0) return;
  }
  int xt;
  int yt;

  if (xdir != 0){
    xt = 2;
    yt = 11;

      screen.render(x - 4, y - 4 - 2, xt + yt * 32, Color.get(-1, 555, 555, 555), random.nextInt(4));
         screen.render(x - 4, y - 4 + 2, xt + yt * 32, Color.get(-1, 000, 000, 000), random.nextInt(4));
     
  }else{
    xt = 1;
    yt = 11;
     screen.render(x - 4, y - 4 - 2, xt + yt * 32, Color.get(-1, 555, 555, 555), random.nextInt(4));
        screen.render(x - 4, y - 4 + 2, xt + yt * 32, Color.get(-1, 000, 000, 000), random.nextInt(4));
  }
 }
}