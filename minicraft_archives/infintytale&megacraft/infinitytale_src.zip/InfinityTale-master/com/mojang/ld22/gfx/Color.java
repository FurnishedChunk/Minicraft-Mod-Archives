package com.mojang.ld22.gfx;

public class Color {

	public static int get(int a, int b, int c, int d) {
		return (get(d) << 24) + (get(c) << 16) + (get(b) << 8) + (get(a));
	}

	public static int get(int d) {
		if (d < 0) return 255;
		int r = d / 100 % 10;
		int g = d / 10 % 10;
		int b = d % 10;
		return r * 36 + g * 6 + b;
	}

	public static int getR(int d) {
		return d / 100 % 10;
	}

	public static int getG(int d) {
		return d / 10 % 10;
	}

	public static int getB(int d) {
		return d % 10;
	}

	public static int getRGB(int r, int g, int b) {
		int r1 = 0; int g1 = 0; int b1 = 0;
		if(r > 0 && r < 256) r1 = (Math.round((float)(((double)r)/255*9)))*100;
		if(g > 0 && g < 256) g1 = (Math.round((float)(((double)g)/255*9)))*10;
		if(b > 0 && b < 256) b1 = (Math.round((float)(((double)b)/255*9)))*1;
		return r1 + g1 + b1;
	}

}