package com.mojang.ld22.level;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

import java.io.*;
import java.util.*;

import com.mojang.ld22.Game;
import com.mojang.ld22.entity.AirWizard;
import com.mojang.ld22.entity.Creeper;
import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.Mob;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.entity.Skeleton;
import com.mojang.ld22.entity.Slime;
import com.mojang.ld22.entity.Trotuh;
import com.mojang.ld22.entity.Zombie;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.item.resource.Resource;
import com.mojang.ld22.level.levelgen.LevelGen;
import com.mojang.ld22.level.tile.OreTile;
import com.mojang.ld22.level.tile.Tile;
import com.mojang.ld22.screen.TitleMenu;

import de.thejackimonster.ld22.modloader.ModLoader;
import de.thejackimonster.ld22.options.OptionFile;
import de.thejackimonster.ld22.story.dialog.DialogManager;
import de.thejackimonster.ld22.story.dialog.NPC;
import de.thejackimonster.ld22.story.dialog.NPCManager;

 public class Level implements java.io.Serializable{
	public Random random = new Random();

	public int w, h;
	
	public Game game;

	public byte[] tiles;
	public byte[] data;
	public byte[] biomes;
	
	public int[][] fireTicks;
	
	public List<Entity>[] entitiesInTiles;

	public int grassSet;
	public int dirtSet;
	public int sandSet;

	public int grassColor;
	public int dirtColor;
	public int sandColor;
	public int depth;
	public int monsterDensity = 8;
	
	public int tickcount = 0;

	public List<Entity> entities = new ArrayList<Entity>();
	public Comparator<Entity> spriteSorter = new Comparator<Entity>() {
		public int compare(Entity e0, Entity e1) {
			if ((e0 == null) || (e1 == null)) return 0;
			if (e1.y < e0.y) return +1;
			if (e1.y > e0.y) return -1;
			return 0;
		}

	};

	@SuppressWarnings("unchecked")
	public Level(Game game,int w, int h, int level, Level parentLevel,int mapsize,int waterc,int grassc,int rockc,int treec) {
		this.game = game;
		if (level < 0) {
			dirtSet = 222;
		} else
		if (level == 1) {
			dirtSet = 444;
		} else {
			grassSet = 141;
			dirtSet = 322;
			sandSet = 550;
		}
		if (level == -4) {
			dirtSet = 500;
		}
		this.depth = level;
		this.w = w;
		this.h = h;
		byte[][] maps;
		byte[][] biomeMap1;
		fireTicks = new int[w][h];
		
		grassColor = grassSet;
		dirtColor = dirtSet;
		sandColor = sandSet;
		if (level == 0) {
			biomeMap1 = LevelGen.createAndValidateTopMap(w, h,mapsize,waterc,grassc,rockc,treec);
			byte[][] biomeMap2 = {biomeMap1[0], biomeMap1[1]};
			maps = biomeMap2;
			biomes = biomeMap1[2];
		} else if (level < 0) {
			maps = LevelGen.createAndValidateUndergroundMap(w, h, -level);
			monsterDensity = 4;
		} else {
			maps = LevelGen.createAndValidateSkyMap(w, h); // Sky level
			monsterDensity = 4;
		}

		if(biomes != null) {
			for(int i = 0; i < biomes.length; i++) {
				System.out.println(biomes[i]);
			}
		}

		tiles = maps[0];
		data = maps[1];
		int x=random.nextInt(w);
		int y=random.nextInt(w);
		
		
		for (int i=0;i<=1;i++) {
	    x = random.nextInt(w);
	    y = random.nextInt(w);
	    setTile(x,y,Tile.heartcontainerOre,0);
		}
		
		if (level == -3) {
		 x=w/2;
		 y=w/2;

		    setTile(x,y,Tile.bowOre,0);
			setTile(x - 1, y, Tile.lava, 0);
			setTile(x + 1, y, Tile.lava, 0);
			setTile(x, y - 1, Tile.lava, 0);
			setTile(x, y + 1, Tile.lava, 0);
			setTile(x - 1, y - 1, Tile.lava, 0);
			setTile(x - 1, y + 1, Tile.lava, 0);
			setTile(x + 1, y - 1, Tile.lava, 0);
			setTile(x + 1, y + 1, Tile.lava, 0);
							
		
		}
		
		
		
		if (parentLevel != null) {
			for ( y = 0; y < h; y++)
				for ( x = 0; x < w; x++) {
					if (parentLevel.getTile(x, y) == Tile.stairsDown) {

						setTile(x, y, Tile.stairsUp, 0);
						if (level == 0) {
							setTile(x - 1, y, Tile.hardRock, 0);
							setTile(x + 1, y, Tile.hardRock, 0);
							setTile(x, y - 1, Tile.hardRock, 0);
							setTile(x, y + 1, Tile.hardRock, 0);
							setTile(x - 1, y - 1, Tile.hardRock, 0);
							setTile(x - 1, y + 1, Tile.hardRock, 0);
							setTile(x + 1, y - 1, Tile.hardRock, 0);
							setTile(x + 1, y + 1, Tile.hardRock, 0);
						} else {
							setTile(x - 1, y, Tile.antimobfield, 0);
							setTile(x + 1, y, Tile.antimobfield, 0);
							setTile(x, y - 1, Tile.antimobfield, 0);
							setTile(x, y + 1, Tile.antimobfield, 0);
							setTile(x - 1, y - 1, Tile.antimobfield, 0);
							setTile(x - 1, y + 1, Tile.antimobfield, 0);
							setTile(x + 1, y - 1, Tile.antimobfield, 0);
							setTile(x + 1, y + 1, Tile.antimobfield, 0);
						}
					}

				}
		}

		entitiesInTiles = new ArrayList[w * h];
		for (int i = 0; i < w * h; i++) {
			entitiesInTiles[i] = new ArrayList<Entity>();
		}
		
		if (level==1) {
			AirWizard aw = new AirWizard();
			aw.x = w*8;
			aw.y = h*8;
			add(aw);
		}
		
		for ( y = 0; y < h; y++) {
			for ( x = 0; x < w; x++) {
				ModLoader.LevelGenerate(this, random, x, y);
			}
		}
	}

	public void renderBackground(Screen screen, int xScroll, int yScroll) {
		int xo = xScroll >> 4;
		int yo = yScroll >> 4;
		int w = (screen.w + 15) >> 4;
		int h = (screen.h + 15) >> 4;
		screen.setOffset(xScroll, yScroll);
		for (int y = yo; y <= h + yo; y++) {
			for (int x = xo; x <= w + xo; x++) {
				getTile(x, y).render(screen, this, x, y);
			}
		}
		screen.setOffset(0, 0);
	}

	public List<Entity> rowSprites = new ArrayList<Entity>();

	public Player player;

	public void renderSprites(Screen screen, int xScroll, int yScroll) {
		int xo = xScroll >> 4;
		int yo = yScroll >> 4;
		int w = (screen.w + 15) >> 4;
		int h = (screen.h + 15) >> 4;

		screen.setOffset(xScroll, yScroll);
		for (int y = yo; y <= h + yo; y++) {
			for (int x = xo; x <= w + xo; x++) {
				if (x < 0 || y < 0 || x >= this.w || y >= this.h) continue;
				rowSprites.addAll(entitiesInTiles[x + y * this.w]);
			}
			if (rowSprites.size() > 0) {
				sortAndRender(screen, rowSprites);
			}
			rowSprites.clear();
		}
		screen.setOffset(0, 0);
	}

	public void renderLight(Screen screen, int xScroll, int yScroll,int bonussight) {
		int xo = xScroll >> 4;
		int yo = yScroll >> 4;
		int w = (screen.w + 15) >> 4;
		int h = (screen.h + 15) >> 4;

		screen.setOffset(xScroll, yScroll);
		int r = 4;
		for (int y = yo - r; y <= h + yo + r; y++) {
			for (int x = xo - r; x <= w + xo + r; x++) {
				if (x < 0 || y < 0 || x >= this.w || y >= this.h) continue;
				List<Entity> entities = entitiesInTiles[x + y * this.w];
				for (int i = 0; i < entities.size(); i++) {
					Entity e = entities.get(i);
					// e.render(screen);
					int lr = e.getLightRadius();
					
					if (e instanceof Player && bonussight > 0) {
						lr += bonussight;
					}


					
					if (lr > 0) screen.renderLight(e.x - 1, e.y - 4, lr * 8);
				}
				int lr = getTile(x, y).getLightRadius(this, x, y);
				if (lr > 0) screen.renderLight(x * 16 + 8, y * 16 + 8, lr * 8);
			}
		}
		screen.setOffset(0, 0);
	}

	// private void renderLight(Screen screen, int x, int y, int r) {
	// screen.renderLight(x, y, r);
	// }

	public void sortAndRender(Screen screen, List<Entity> list) {
		
		if (! (game.menu instanceof TitleMenu)) {
		 Collections.sort(list, spriteSorter);
		 for (int i = 0; i < list.size(); i++) {
	 		list.get(i).render(screen);
		 }
		}
	}

	public Tile getTile(int x, int y) {
		if (x < 0 || y < 0 || x >= w || y >= h) return Tile.rock;
		return Tile.tiles[tiles[x + y * w]];
	}

	public void setTile(int x, int y, Tile t, int dataVal) {
		if (x < 0 || y < 0 || x >= w || y >= h || t == null) return;
	    if (game != null) {
	    	if (game.mpstate == 2 && game.server != null) {
	           game.server.updatetile(x, y);
	        }
	    	if (game.mpstate == 1 && game.client != null) {
		          game.mapupdated = true;
		    }
	    }
		tiles[x + y * w] = t.id;
		data[x + y * w] = (byte) dataVal;
	}

	public int getData(int x, int y) {
		if (x < 0 || y < 0 || x >= w || y >= h) return 0;
		return data[x + y * w] & 0xff;
	}

	public void setData(int x, int y, int val) {
		if (x < 0 || y < 0 || x >= w || y >= h) return;
		data[x + y * w] = (byte) val;
	}

	public void add(Entity entity) {
		if (entity instanceof Player) {
			player = (Player) entity;
		}
		entity.removed = false;
		entities.add(entity);
		entity.init(this);

		insertEntity(entity.x >> 4, entity.y >> 4, entity);
	}

	public void remove(Entity e) {
		entities.remove(e);
		int xto = e.x >> 4;
		int yto = e.y >> 4;
		removeEntity(xto, yto, e);
	}

	public void insertEntity(int x, int y, Entity e) {
		if (x < 0 || y < 0 || x >= w || y >= h) return;
		entitiesInTiles[x + y * w].add(e);
	}

	public void removeEntity(int x, int y, Entity e) {
		if (x < 0 || y < 0 || x >= w || y >= h) return;
		entitiesInTiles[x + y * w].remove(e);
	}

	public void trySpawn(int count) {
		count /= 2;
		count += count*OptionFile.difficulty;
		
		for (int i = 0; i < count; i++) {
			Mob mob = null;
			int minLevel = 1;
			int maxLevel = 1;
			if (depth < 0) {
				maxLevel = (-depth) + 1;
			}
			if (depth > 0) {
				minLevel = maxLevel = 4;
			}

			int lvl = random.nextInt(maxLevel - minLevel + 1) + minLevel;
	
	
			int c = (random.nextInt(7));

			if(c == 0 || c == 1) {
				mob = new Slime(lvl);
			} else if(c == 2 || c == 3) {
				mob = new Zombie(lvl);
			} else if(c == 4) {
				mob = new Creeper(lvl);
			} else if(c == 5) {
				mob = new Skeleton(lvl);
			} else if(c == 6 && !game.firsttime) {
				int j = 0;
				while(j < NPCManager.npcList.size()) {
					if(NPCManager.npcList.get(j).removed && mob == null) {
						mob = NPCManager.npcList.get(j);
						j = NPCManager.npcList.size();
					}
					j++;
				}
			} else {
				mob = new Slime(lvl);
			}
			
			if (depth == -4) {
			 int ra = random.nextInt(2);
			 if (ra == 1) {			 
			  mob = new Trotuh(lvl);
			 } else if (ra == 0) {
		      mob = new Skeleton(lvl);
			 }
			}
			
			if(mob != null) {
				if (mob.findStartPos(this)) {
					this.add(mob);
				}
				//}
			}
		}
	}

	public boolean getRightBiome(int x, int y, Mob mob) {
		if(x <= 0 || y <= 0) return false;
		
		int xx = (int) (x / (Math.sqrt(biomes.length)));
		int yy = (int) (y / (Math.sqrt(biomes.length)));
		int xr = (int) (x % (Math.sqrt(biomes.length)));
		int yr = (int) (y % (Math.sqrt(biomes.length)));
		
		if(xr >= 0 && yr >= 0 && xx < (Math.sqrt(biomes.length)) && yy < (Math.sqrt(biomes.length))) {
			byte bio = biomes[(int) (xx + (yy)*((int)Math.sqrt(biomes.length)))];
			
			if(bio == 0) return false;
			if(bio == 1) {
				if(mob instanceof Slime) return true;
				if(mob instanceof NPC) return true;
			}
			if(bio == 2) {
				if(mob instanceof Slime) return true;
				if(mob instanceof NPC) return true;
			}
			if(bio == 3) {
				if(mob instanceof Skeleton) return true;
				if(mob instanceof Creeper) return true;
			}
			if(bio == 4) return false;
			if(bio == 5) return false;
			if(bio == 6) {
				if(mob instanceof Creeper) return true;
				if(mob instanceof Zombie) return true;
			}
			if(bio == 7) {
				if(mob instanceof Skeleton) return true;
				if(mob instanceof Zombie) return true;
			}
		}
		
		return false;
	}

	public void tick() {
		tickcount++;
		if (tickcount % monsterDensity == 0 && this.game.lightlvl <4) {	
		  trySpawn(1);
		}
		for (int i = 0; i < w * h / 50; i++) {
			int xt = random.nextInt(w);
			int yt = random.nextInt(w);
			getTile(xt, yt).tick(this, xt, yt);
		}
		for (int i = 0; i < entities.size(); i++) {
		 if (entities.get(i) != null) {
			Entity e = entities.get(i);
			int xto = e.x >> 4;
			int yto = e.y >> 4;

			e.tick();

			if (e.removed) {
				entities.remove(i--);
				removeEntity(xto, yto, e);
			} else {
				int xt = e.x >> 4;
				int yt = e.y >> 4;

				if (xto != xt || yto != yt) {
					removeEntity(xto, yto, e);
					insertEntity(xt, yt, e);
				}
			}
		 }
		}
	}

	public List<Entity> getEntities(int x0, int y0, int x1, int y1) {
		List<Entity> result = new ArrayList<Entity>();
		int xt0 = (x0 >> 4) - 1;
		int yt0 = (y0 >> 4) - 1;
		int xt1 = (x1 >> 4) + 1;
		int yt1 = (y1 >> 4) + 1;
    	for (int y = yt0; y <= yt1; y++) {
			for (int x = xt0; x <= xt1; x++) {
				if (x < 0 || y < 0 || x >= w || y >= h) continue;
				List<Entity> entities = entitiesInTiles[x + y * this.w];

				for (int i = 0; i < entities.size(); i++) {
					if (entities.get(i) != null) {
					 Entity e = entities.get(i);
					 if (e.intersects(x0, y0, x1, y1)) result.add(e);
					}
				}
			}
		}
		return result;
	}
}