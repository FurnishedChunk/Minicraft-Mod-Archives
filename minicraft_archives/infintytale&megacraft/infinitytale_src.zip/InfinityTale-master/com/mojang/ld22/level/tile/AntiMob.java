package com.mojang.ld22.level.tile;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.ItemEntity;
import com.mojang.ld22.entity.Mob;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.entity.particle.SmashParticle;
import com.mojang.ld22.entity.particle.TextParticle;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.item.ResourceItem;
import com.mojang.ld22.item.ToolItem;
import com.mojang.ld22.item.ToolType;
import com.mojang.ld22.item.resource.Resource;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.sound.Sound;

public class AntiMob extends Tile {

	public AntiMob(int id) {
		super(id);
	}

	public void render(Screen screen, Level level, int x, int y) {
		int color;
		 color = Color.get(level.dirtColor,111, 110, 320);	
		
		int xt = 27;
		screen.render(x * 16 + 0, y * 16 + 0, xt + 1 * 32, color, 0);
		screen.render(x * 16 + 8, y * 16 + 0, xt + 1 + 1 * 32, color, 0);
		screen.render(x * 16 + 0, y * 16 + 8, xt + 2 * 32, color, 0);
		screen.render(x * 16 + 8, y * 16 + 8, xt + 1 + 2 * 32, color, 0);
		super.render(screen, level, xt, y);
	}

	public boolean mayPass(Level level, int x, int y, Entity e) {		
		if (e instanceof Player) {
		 return true;
		} else {
		 return false;
		}
	}

	public void hurt(Level level, int x, int y, Mob source, int dmg, int attackDir) {
		Sound.monsterHurt.play();
	}

	public boolean interact(Level level, int xt, int yt, Player player, Item item, int attackDir) {
		return false;
	}
	
	private void hurt(Level level, int x, int y, int dmg) {
		

	}
}
