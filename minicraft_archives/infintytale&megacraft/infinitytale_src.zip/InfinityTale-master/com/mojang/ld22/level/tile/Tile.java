package com.mojang.ld22.level.tile;

import java.util.Random;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.Mob;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.item.HeartContainer;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.item.ToolItem;
import com.mojang.ld22.item.ToolType;
import com.mojang.ld22.item.resource.Resource;
import com.mojang.ld22.level.Level;

import de.thejackimonster.ld22.story.dialog.NPC;

public class Tile {
	public static int tickCount = 0;
	protected Random random = new Random();

	public static Tile[] tiles = new Tile[256];
	public static Tile grass = new GrassTile(0);
	public static Tile rock = new RockTile(1);
	public static Tile woodplanktile = new WoodplankTile(2);
	public static Tile water = new WaterTile(3);
	public static Tile flower = new FlowerTile(4);
	public static Tile tree = new TreeTile(5);
	public static Tile dirt = new DirtTile(6);
	public static Tile sand = new SandTile(7);
	public static Tile woodfloor = new Woodfloor(8);
	public static Tile hole = new HoleTile(9);
	public static Tile cactus = new CactusTile(10);
	public static Tile cactusSapling = new SaplingTile(25, sand, cactus);
	public static Tile woodendoor = new Woodendoor(11);
	public static Tile farmland = new FarmTile(12);
	public static Tile wheat = new WheatTile(13);
	public static Tile lava = new LavaTile(14);
    public static Tile stoneplank =new BrickwallTile(15);
    public static Tile carpet =new CarpetTile(16);
	public static Tile glowstone = new GlowStoneTile(17);
	public static Tile cloud = new CloudTile(18);
	public static Tile treeSapling = new SaplingTile(19, grass, tree);
	public static Tile ironOre = new OreTile(20, Resource.ironOre,0);
	public static Tile goldOre = new OreTile(21, Resource.goldOre,0);
	public static Tile gemOre = new OreTile(22, Resource.gem,0);
	public static Tile cloudCactus = new CloudCactusTile(23);
	public static Tile hardRock = new HardRockTile(24);
    public static Tile presentOre =new OreTile(26, Resource.apple, 10);
    public static Tile bowOre =new ItemgiftTile(27, ToolType.bow, 4);
    public static Tile heartcontainerOre =new FreeitemgiftTile(28,new HeartContainer(), 1);
    public static Tile antimobfield =new AntiMob(29);
	public static Tile stairsDown = new StairsTile(30, false);
	public static Tile stairsUp = new StairsTile(31, true);
	public static Tile infiniteFall = new InfiniteFallTile(32);
	public static Tile glowstoneOre = new OreTile(33, Resource.glowstoneOre,1);
	
    public final byte id;
    public int breakDown = 0;

	public boolean connectsToGrass = false;
	public boolean connectsToSand = false;
	public boolean connectsToLava = false;
	public boolean connectsToWater = false;

	public Tile(int id) {
		this.id = (byte) id;
		if (tiles[id] != null) throw new RuntimeException("Duplicate tile ids!");
		tiles[id] = this;
	}

	public void render(Screen screen, Level level, int x, int y) {
		if(level.fireTicks[x][y] > 0 && canBurn()) {
			int xp = 0;
			int yp = 26*32;
			if(level.game.menu == null) xp = random.nextInt(5)*2;
			screen.render(x*16 , y*16, xp + yp, Color.get(-1, 500, 520, 550), 0);
			screen.render(x*16 + 8, y*16, xp + yp + 1, Color.get(-1, 500, 520, 550), 0);
			screen.render(x*16, y*16 + 8, xp + yp + 32, Color.get(-1, 500, 520, 550), 0);
			screen.render(x*16 + 8, y*16 + 8, xp + yp + 32 + 1, Color.get(-1, 500, 520, 550), 0);
		}
	}

	public void renderDmg(Screen screen, Level level, int x, int y,int dmg1,int dmg2,int dmg3) {
		int h = 0;
		int col = Color.get(-1, 111, 111, 111);
		breakDown = dmg3;
		if (level.getData(x, y) > dmg3) {
			h = 4;
			 screen.render(x*16, y*16, 20*32+h, col, 0);
			 screen.render(x*16+8, y*16, 1+20*32+h, col, 0);
			 screen.render(x*16, y*16+8, 21*32+h, col, 0);
			 screen.render(x*16+8, y*16+8, 1+21*32+h, col, 0);
		} else if (level.getData(x, y) > dmg2) {
			h = 2;
			 screen.render(x*16, y*16, 20*32+h, col, 0);
			 screen.render(x*16+8, y*16, 1+20*32+h, col, 0);
			 screen.render(x*16, y*16+8, 21*32+h, col, 0);
			 screen.render(x*16+8, y*16+8, 1+21*32+h, col, 0);
		} else if (level.getData(x, y) > dmg1) {
		    h = 0;
		     screen.render(x*16, y*16, 20*32+h, col, 0);
		     screen.render(x*16+8, y*16, 1+20*32+h, col, 0);
		     screen.render(x*16, y*16+8, 21*32+h, col, 0);
		     screen.render(x*16+8, y*16+8, 1+21*32+h, col, 0);
		}
	}	
	
	public boolean mayPass(Level level, int x, int y, Entity e) {
		return true;
	}

	public int getLightRadius(Level level, int x, int y) {
		if(level.fireTicks[x][y] > 0 && canBurn()) return random.nextInt(3)+2;
		return 0;
	}

	public void hurt(Level level, int x, int y, Mob source, int dmg, int attackDir) {
	}

	public void bumpedInto(Level level, int xt, int yt, Entity entity) {
		if(xt >= 0 && xt < level.fireTicks.length) {
			if(yt >= 0 && yt < level.fireTicks[xt].length) {
				if(level.fireTicks[xt][yt] > 0 && canBurn() && (entity instanceof Mob) && (!(entity instanceof NPC))) ((Mob)entity).hurt(this, xt, yt, 1);
			}
		}
	}

	public void tick(Level level, int xt, int yt) {
		if(level.fireTicks[xt][yt] > 0) {
			level.fireTicks[xt][yt]--;
			int val = level.getData(xt, yt);
			if(val > (breakDown+breakDown/4)) {
				level.setTile(xt, yt, Tile.dirt, 0);
				level.fireTicks[xt][yt] = 0;
			} else {
				level.setData(xt, yt, val + 4);
			}
			
			if(level.fireTicks[xt][yt] % 5 == 0) {
				switch(random.nextInt(4)) {
				case 0:
					if(xt - 1 >= 0) level.fireTicks[xt-1][yt] = level.fireTicks[xt][yt];
					break;
				case 1:
					if(xt + 1 < level.w) level.fireTicks[xt+1][yt] = level.fireTicks[xt][yt];
					break;
				case 2:
					if(yt - 1 >= 0) level.fireTicks[xt][yt-1] = level.fireTicks[xt][yt];
					break;
				case 3:
					if(yt + 1 < level.h) level.fireTicks[xt][yt+1] = level.fireTicks[xt][yt];
					break;
				default:
					break;
				}
			}
		} else if(level.fireTicks[xt][yt] < 0 || (!canBurn())) level.fireTicks[xt][yt] = 0;
	}

	public boolean canBurn() {
		return false;
	}

	public void steppedOn(Level level, int xt, int yt, Entity entity) {
	}

	public boolean interact(Level level, int xt, int yt, Player player, Item item, int attackDir) {
		return false;
	}

	public boolean use(Level level, int xt, int yt, Player player, int attackDir) {
		return false;
	}

	public boolean connectsToLiquid() {
		return connectsToWater || connectsToLava;
	}
}