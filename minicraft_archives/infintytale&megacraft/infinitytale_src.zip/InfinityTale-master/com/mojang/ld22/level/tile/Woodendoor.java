package com.mojang.ld22.level.tile;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.ItemEntity;
import com.mojang.ld22.entity.Mob;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.entity.particle.SmashParticle;
import com.mojang.ld22.entity.particle.TextParticle;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.item.ResourceItem;
import com.mojang.ld22.item.ToolItem;
import com.mojang.ld22.item.ToolType;
import com.mojang.ld22.item.resource.Resource;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.sound.Sound;

public class Woodendoor extends Tile {
    private boolean open = false;

	public Woodendoor(int id) {
		super(id);
	}

	public void render(Screen screen, Level level, int x, int y) {
		int color;
		if (level.getData(x, y) == 0) {
		 color = Color.get(level.dirtColor,430, 420, 320);
		} else {
		 color = Color.get(level.dirtColor,level.dirtColor, level.dirtColor, 320);	
		}
		int xt = 25;
		screen.render(x * 16 + 0, y * 16 + 0, xt + 1 * 32, color, 0);
		screen.render(x * 16 + 8, y * 16 + 0, xt + 1 + 1 * 32, color, 0);
		screen.render(x * 16 + 0, y * 16 + 8, xt + 2 * 32, color, 0);
		screen.render(x * 16 + 8, y * 16 + 8, xt + 1 + 2 * 32, color, 0);
		super.render(screen, level, x, y);
	}

	public boolean mayPass(Level level, int x, int y, Entity e) {
		return open;
	}

	public void hurt(Level level, int x, int y, Mob source, int dmg, int attackDir) {
		if (level.getData(x, y) == 0){
			level.setData(x, y, 1);
		} else if (level.getData(x, y) == 1) {
			level.setData(x, y, 0);
		}
		Sound.monsterHurt.play();
	}

	public boolean interact(Level level, int xt, int yt, Player player, Item item, int attackDir) {
		if (level.getData(xt, yt) == 0){
			level.setData(xt, yt, 1);
		} else if (level.getData(xt, yt) == 1) {
			level.setData(xt, yt, 0);
		}
		if (item instanceof ToolItem) {
			ToolItem tool = (ToolItem) item;
			if (tool.type == ToolType.axe) {
				if (player.payStamina(4 - tool.level)) {
					hurt(level, xt, yt, random.nextInt(10) + (tool.level) * 5 + 10);
					return true;
				}
			}
			if (tool.type == ToolType.hammer && tool.level >= 0){
				player.payStamina(6-tool.level);
				level.add(new ItemEntity(new ResourceItem(Resource.wooddoor), xt*16, yt*16));
				level.setTile(xt, yt, Tile.dirt, 0);
			}
		}
		return false;
	}
	private void hurt(Level level, int x, int y, int dmg) {
	}

	public boolean canBurn() {
		return true;
	}
}
