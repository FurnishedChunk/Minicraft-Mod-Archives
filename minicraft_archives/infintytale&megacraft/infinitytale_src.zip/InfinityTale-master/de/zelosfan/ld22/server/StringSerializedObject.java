package de.zelosfan.ld22.server;

import java.io.*;
import java.util.*;

public class StringSerializedObject implements Serializable {
   private String array[] = null;

   public StringSerializedObject() {
   }

   public void setArray(String array[]) {
     this.array = array;
   }

   public String[] getArray() {
     return array;
   }
}