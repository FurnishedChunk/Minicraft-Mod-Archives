package de.zelosfan.ld22.server;

import java.io.*;
import java.net.*;

import com.mojang.ld22.entity.Creeper;
import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.Furniture;
import com.mojang.ld22.entity.ItemEntity;
import com.mojang.ld22.entity.Mob;
import com.mojang.ld22.entity.MultiPlayer;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.entity.Slime;
import com.mojang.ld22.entity.Zombie;
import com.mojang.ld22.entity.particle.TextParticle;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.item.ResourceItem;
import com.mojang.ld22.level.Level;
import de.thejackimonster.ld22.story.dialog.NPC;
import de.thejackimonster.ld22.story.dialog.NPCManager;

import com.mojang.ld22.Game;

public class Server extends Thread {

   private ServerSocket server;
   private Game game;
   public boolean mapupdated = true;
   public boolean positionupdated = true;
   public boolean furnatureupdated = true;
   public boolean zombieposupdated = true;
   public boolean slimeposupdated = true;
   public boolean creeperposupdated = true;
   public boolean newtxp = false;
   public boolean multiplayerhpupdated = true;
   public boolean dropsupdated = true;
   public int tilerefreshcount = 0;
   public int[] xkoord = new int[999];
   public int[] ykoord = new int[999];
   public int txpx;
   public int txpy;
   public int txpcol;
   public int txpmsg;

   public Server(Game game) throws Exception {
     server = new ServerSocket(game.SERVERSOCKET);
     this.game = game;
     System.out.println("[SERVER]Server listening on port "+game.SERVERSOCKET+".");
     this.start();
   } 

   public void sendTextParticle(int x,int y,int col,int msg) {
	   txpx = x;
	   txpy = y;
	   txpcol = col;
	   txpmsg = msg;
	   newtxp = true;
   }
      
   
   public void updatemap() {
	   this.mapupdated = true;
   }
   
   public void updatetile(int x,int y) {
	   if (!(game.isloadingmap)) {
	    xkoord[tilerefreshcount] = x;
	    ykoord[tilerefreshcount] = y;
	    tilerefreshcount++;
	   }
   }
   
   public void updateplayerpositions() {
	   this.positionupdated = true;
   }   
  
   public void updatefurnature() {
	   this.furnatureupdated = true;
   }      

   public void updatezombiepos() {
	   this.zombieposupdated = true;
   }      

   public void updateslimepos() {
	   this.slimeposupdated = true;
   }      
   
   public void updatecreeperpos() {
	   this.creeperposupdated = true;
   }           
   
   public void run() {
     System.out.println("[SERVER]Started CONNECTION THREAD"+Thread.currentThread().getId());
     while(true) {
       try {
        System.out.println("[CONNECTION]Waiting for client connection.");
        Socket client = server.accept();
        System.out.println("[CONNECTION]Accepted a connection from: "+client.getInetAddress());
       
        if (this.positionupdated) {
          Connect d = new Connect(client,game,2);    
          this.positionupdated = false;  
        } else if (this.multiplayerhpupdated) {
          Connect g = new Connect(client,game,8);
          this.multiplayerhpupdated = false;
        } else if (this.mapupdated) {
          Connect c = new Connect(client,game,1);
          this.mapupdated = false;
        } else if (tilerefreshcount > 0) {
           Connect i = new Connect(client,game,10);
        } else if (newtxp){
           Connect f = new Connect(client,game,7);
           newtxp = false;
        } else if (this.dropsupdated){
           Connect h = new Connect(client,game,9);
           this.dropsupdated = false; 
        } else if (this.furnatureupdated){
          Connect e = new Connect(client,game,3);
          this.furnatureupdated = false; 
        } else if (this.zombieposupdated){
          Connect b = new Connect(client,game,5);
          this.zombieposupdated = false;
        } else if (this.slimeposupdated){
          Connect a = new Connect(client,game,4);
          this.slimeposupdated = false;     
        } else if (this.creeperposupdated){
          Connect a = new Connect(client,game,6);
          this.creeperposupdated = false; 
        } else {
          Connect a = new Connect(client,game,2);	
          updateslimepos();
          updatezombiepos();
          updatecreeperpos();
    //      this.dropsupdated = true;
        }

       } catch(Exception e) {}
     }
   }
}

class Connect extends Thread {
   private Socket client = null;
   private ObjectInputStream ois = null;
   private ObjectOutputStream oos = null;
   private Game game = null;
   private int updatetype;
    
   public Connect() {}

   public Connect(Socket clientSocket,Game game,int updatetype) {
     client = clientSocket;
     this.game = game;
     this.updatetype = updatetype;
     try {
      ois = new ObjectInputStream(client.getInputStream());
      oos = new ObjectOutputStream(client.getOutputStream());
     } catch(Exception e1) {
         try {
            client.close();
         }catch(Exception e) {
           System.out.println(e.getMessage());
         }
         return;
     }
     this.start();
   }

   public void run() {
      Level lvl = null;
      int updatestat = 0;
      int playerid = 0;
 
      try {     
    	 DataInputStream dis = new DataInputStream(ois);
    	 playerid = dis.readInt();
    	 updatestat = dis.readInt();
    	 System.out.println("[CONNECTION]Starting Client to Server update with ID:"+updatestat);
    	 switch (updatestat) {
    	 case 0:
    		 break;

           	case 1:
            //server System.out.println("Downloading level");
             int len = dis.readInt();
             byte[] data = new byte[len];
             if (len > 0) {
                 dis.readFully(data);
             }

           //server System.out.println("The Level is downloaded");
             game.level.tiles = data;
             break;
            
    	    case 2:
            	game.level.remove(game.player2);
                game.player2.x = dis.readInt();
                game.player2.y = dis.readInt();
                game.player2.dir = dis.readInt();
                game.player2.walkDist = dis.readInt();
                ((MultiPlayer) game.player2).invuln = false;
                int newhp = dis.readInt();
                
                if (newhp != -1) {
                	game.player2.health = newhp;
                	game.server.multiplayerhpupdated = true;
                }
                
                game.level.add(game.player2);
                break;
             
    	    case 3:
 		        for (int i=0;i<game.level.entities.size();i++) {
 			 	   if (game.level.entities.get(i) instanceof Mob && (!(game.level.entities.get(i) instanceof Player))&& (!(game.level.entities.get(i) instanceof MultiPlayer))) {
   		             Mob mob = (Mob) game.level.entities.get(i);
   		             mob.remove();
   		           }
   		        }
 		     //server System.out.println("Downloading new entities:all mobs");
        		int togo2 = dis.readInt();
        		int ex2;
        		int ey2;
        		int etyp2;
        		int elvl2;
        		int ehp;

        		for (int i=0;i<togo2;i++) {
                    ex2 = dis.readInt();
                    ey2 = dis.readInt();
                    etyp2 = dis.readInt();
                    elvl2 = dis.readInt();
                    ehp = dis.readInt();
                  
                    Mob mon = (Mob) Entity.entities.get(etyp2).getClass().newInstance(); 	
                  //  Mob mon = new Mob(name);
 				      
				    mon.x = ex2;
					mon.y = ey2;
					mon.health = ehp;
			
					game.level.add(mon);                    
                    mon.render(game.screen);
                    
        		}
        		
        		//server System.out.println("finished new entities:slime");
        		break;	
        		
    	    case 4:
           		
   		        for (int i=0;i<game.level.entities.size();i++) {
   		           if (game.level.entities.get(i) instanceof ItemEntity) {
   		             ItemEntity furniture = (ItemEntity) game.level.entities.get(i);
   		             furniture.remove();
   		           }
   		        }
   		   //server System.out.println("Downloading new entities:drops");
        		int togo5 = dis.readInt();
        		int ex5;
        		int ey5;
        		int etyp5;
        		for (int i=0;i<togo5;i++) {
                    ex5 = dis.readInt();
                    ey5 = dis.readInt();
                    etyp5 = dis.readInt();
                   
                    Item item =  Item.items.get(etyp5); 
        			if (item instanceof ResourceItem) {
        				ResourceItem resItem = new ResourceItem(((ResourceItem) item).resource);
                  		game.level.add(new ItemEntity(resItem, ex5, ey5));   
        			}   
                    
        		}
        		
        		//server System.out.println("finished new entities:drops");        		  	    	
    	    	
    	    	break;
    	    case 5:
    	    	updatetype = dis.readInt();
    	    	System.out.println("[CONNECTION]Skipping "+updatetype+" because of CLIENTREQUEST("+updatestat+") with ID:"+updatetype);
    	    	break;
    	    	
    	    
    	    case 6:
    	    	int togo3 = dis.readInt();
    	    	int ex3;
    	    	int ey3;
    	    	int e2x3;
    	    	int e2y3;
    	    	int damage3;
        		for (int i=0;i<togo3;i++) {
                    ex3 = dis.readInt();
                    ey3 = dis.readInt();
                    e2x3 = dis.readInt();
                    e2y3 = dis.readInt();
                    damage3 = dis.readInt();
                    game.player2.hurt(ex3, ey3, e2x3, e2y3,damage3);   
        		}
        		    	    	
    	    	
    	 }
    	  
    	  
    	  
    	 System.out.println("[CONNECTION]Initiating update from SERVER to CLIENT with ID:"+String.valueOf(this.updatetype));

    	 DataOutputStream dos;
    	 switch (updatetype){
    	   case 0:
    		 break;
    	 
    	   case 1:
    	     dos = new DataOutputStream(oos);
    	    	 
    	     dos.writeInt(updatetype);
    	     int len = game.level.tiles.length; 
    	     dos.writeInt(game.lightlvl);
        	 dos.writeInt(len);
        	 if (len > 0) {
        	        dos.write(game.level.tiles, 0, len);
        	 }    	 
        	 break;
        	
    	   case 2:
    	     dos = new DataOutputStream(oos);
    	    	 
    	     dos.writeInt(updatetype);
    	     dos.writeInt(game.player.x);
    	     dos.writeInt(game.player.y);  
    	     dos.writeInt(game.player.dir);
    	     dos.writeInt(game.player.walkDist);
    	 //    dos.writeInt(game.player.username.length());
    	//     dos.writeChars(game.player.username);
    	     dos.writeInt(game.player.color);
 			if(game.player.activeItem != null) {
		//		if(game.player.activeItem instanceof ResourceItem) {
 				int actitemid = Item.getIDOfName(game.player.activeItem.getName());
				dos.writeInt(actitemid);
			} else {
				dos.writeInt(-1);
			}

    	     
    	  //   dos.writeInt(game.player.activeItem.id);
    	     break;
    	    
    	   case 3:
    	   	 dos = new DataOutputStream(oos);
    	    	 
        	 dos.writeInt(updatetype);
    		 
        	 
        	int z = 0;
		    for (int i=0;i<game.level.entities.size();i++) {
	   		   if (game.level.entities.get(i) instanceof Furniture) {
	   		     z++;
	   		   }
	   		 }
		     dos.writeInt(z); 
        	 
     		int ex;
     		int ey;
     		int etyp; 
		     for (int i=0;i<game.level.entities.size();i++) {
		       if (game.level.entities.get(i) instanceof Furniture) {
		    	 ex = game.level.entities.get(i).x;
		    	 ey = game.level.entities.get(i).y;
		    	 etyp = Entity.getIDOfName(game.level.entities.get(i).name);
    		     dos.writeInt(ex);
    		     dos.writeInt(ey);
    		     dos.writeInt(etyp);
		       }
    		 }
    		 
    		 break;
    	   case 4:
      	   	 dos = new DataOutputStream(oos);
      	    	 
          	 dos.writeInt(updatetype);
      		 
          	 
          	int z2 = 0;
  		    for (int i=0;i<game.level.entities.size();i++) {
  	   		   if (game.level.entities.get(i) instanceof Slime) {
  	   		     z2++;
  	   		   }
  	   		 }
  		     dos.writeInt(z2); 
          	 
       		int ex2;
       		int ey2;
       		int etyp2;
       		int elvl2;
       		int ejumptime2;
  		     for (int i=0;i<game.level.entities.size();i++) {
  		       if (game.level.entities.get(i) instanceof Slime) {
  		    	  Slime slime = (Slime) game.level.entities.get(i);
  		    	 ex2 = game.level.entities.get(i).x;
  		    	 ey2 = game.level.entities.get(i).y;
  		    	 etyp2 = Entity.getIDOfName(game.level.entities.get(i).name);
  		    	 elvl2 = slime.lvl;
  		    	 ejumptime2 = slime.jumpTime;
      		     dos.writeInt(ex2);
      		     dos.writeInt(ey2);
      		     dos.writeInt(etyp2);
      		     dos.writeInt(elvl2);
      		     dos.writeInt(ejumptime2);
  		       }
      		 }
      		 
      		 break;
 
    	   case 5:
        	   	 dos = new DataOutputStream(oos);
        	    	 
            	 dos.writeInt(updatetype);
        		 
            	 
            	int z3 = 0;
    		    for (int i=0;i<game.level.entities.size();i++) {
    	   		   if (game.level.entities.get(i) instanceof Zombie) {
    	   		     z3++;
    	   		   }
    	   		 }
    		     dos.writeInt(z3); 
            	 
         		int ex3;
         		int ey3;
         		int ewalkdist3;
         		int elvl3;
         		int edir3;
    		     for (int i=0;i<game.level.entities.size();i++) {
    		       if (game.level.entities.get(i) instanceof Zombie) {
    		    	 Zombie zomb = (Zombie) game.level.entities.get(i);
    		    	 ex3 = game.level.entities.get(i).x;
    		    	 ey3 = game.level.entities.get(i).y;
    		    	 ewalkdist3 = zomb.walkDist;
    		    	 elvl3 = zomb.lvl;
    		    	 edir3 = zomb.dir;
    		    	
        		     dos.writeInt(ex3);
        		     dos.writeInt(ey3);
        		     dos.writeInt(ewalkdist3);
        		     dos.writeInt(elvl3);
        		     dos.writeInt(edir3);
    		       }
        		 }
        		 
        		 break;
        		 
    	   case 6:
      	   	 dos = new DataOutputStream(oos);
      	    	 
          	 dos.writeInt(updatetype);
      		 
          	 
          	int z4 = 0;
  		    for (int i=0;i<game.level.entities.size();i++) {
  	   		   if (game.level.entities.get(i) instanceof Creeper) {
  	   		     z4++;
  	   		   }
  	   		 }
  		     dos.writeInt(z4); 
          	 
       		int ex4;
       		int ey4;
       		int ewalkdist4;
       		int elvl4;
       		int edir4;
  		     for (int i=0;i<game.level.entities.size();i++) {
  		       if (game.level.entities.get(i) instanceof Creeper) {
  		    	 Creeper zomb = (Creeper) game.level.entities.get(i);
  		    	 ex4 = game.level.entities.get(i).x;
  		    	 ey4 = game.level.entities.get(i).y;
  		    	 ewalkdist4 = zomb.walkDist;
  		    	 elvl4 = zomb.lvl;
  		    	 edir4 = zomb.dir;
  		    	
      		     dos.writeInt(ex4);
      		     dos.writeInt(ey4);
      		     dos.writeInt(ewalkdist4);
      		     dos.writeInt(elvl4);
      		     dos.writeInt(edir4);
  		       }
      		 }
      		 
      		 break;
 
    	   case 7:
        	   	 dos = new DataOutputStream(oos);
        	    	 
            	 dos.writeInt(updatetype);
                 
            	 dos.writeInt(game.server.txpx);
            	 dos.writeInt(game.server.txpy);
            	 dos.writeInt(game.server.txpmsg);
            	 dos.writeInt(game.server.txpcol);
        		 break;
        		 
    	   case 8:
      	   	 dos = new DataOutputStream(oos);
	    	 
          	 dos.writeInt(updatetype);
          	  dos.writeInt(game.player2.health);
          	 
          	
          	 
    		   
    		 break;
    		 
    	   case 9:
        	   	 dos = new DataOutputStream(oos);
      	    	 
              	 dos.writeInt(updatetype);
          		 
              	 
              	int z5 = 0;
      		    for (int i=0;i<game.level.entities.size();i++) {
      	   		   if (game.level.entities.get(i) instanceof ItemEntity) {
      	   		     z5++;
      	   		   }
      	   		 }
      		     dos.writeInt(z5); 
              	 
           		int ex5;
           		int ey5;
           	    int etyp5;
      		     for (int i=0;i<game.level.entities.size();i++) {
      		       if (game.level.entities.get(i) instanceof ItemEntity) {
      		    	 game.newdrophelper = false;
      		    	 ItemEntity item = (ItemEntity) game.level.entities.get(i);
      		    	 ex5 = item.x;
      		    	 ey5 = item.y;
      		    	 etyp5 = Item.getIDOfName(item.name);

      		    	
          		     dos.writeInt(ex5);
          		     dos.writeInt(ey5);
          		     dos.writeInt(etyp5);

      		       }
          		 }
      		   game.newdrophelper = false;     	
      		   break;
      		   
    	   case 10:
    		   
      	   	 dos = new DataOutputStream(oos);
  	    	 
          	 dos.writeInt(updatetype);     	
  	      	 dos.writeInt(game.server.tilerefreshcount);
  	      	 
  	       	 for (int i=0;i<game.server.tilerefreshcount;i++) {
  	       		dos.writeInt(game.server.xkoord[i]); 
  	       		dos.writeInt(game.server.ykoord[i]); 
  	       		dos.writeInt(game.level.getTile(game.server.xkoord[i], game.server.ykoord[i]).id);   	       		  	       		
  	         }
  	    	 game.server.tilerefreshcount -= 1;
  	    	
  	    	
  	         break;
    		   
 
    	   case 11:
        	   	 dos = new DataOutputStream(oos);
        	    	 
            	 dos.writeInt(updatetype);
        		 
            	 
            	int z11 = 0;
    		    for (int i=0;i<game.level.entities.size();i++) {
    	   		   if (game.level.entities.get(i) instanceof NPC) {
    	   		     z11++;
    	   		   }
    	   		 }
    		     dos.writeInt(z11); 
            	 
         		int ex11;
         		int ey11;
         		int ewalkdist11;
         		int elvl11;
         		int edir11;
    		     for (int i=0;i<game.level.entities.size();i++) {
    		       if (game.level.entities.get(i) instanceof NPC) {
    		    	 NPC zomb = (NPC) game.level.entities.get(i);
    		    	 ex4 = game.level.entities.get(i).x;
    		    	 ey4 = game.level.entities.get(i).y;
    		    	 ewalkdist4 = zomb.walkDist;
    	//	    	 elvl4 = zomb.lvl;
    		    	 edir4 = zomb.dir;

        		     dos.writeInt(ex4);
        		     dos.writeInt(ey4);
        		     dos.writeInt(ewalkdist4);
       // 		     dos.writeInt(elvl4);
        		     dos.writeInt(edir4);
    		       }
        		 }
        		 
        		 break;
    		
    		   
    	 }
    	 

    	 
    	 System.out.println("[CONNECTION]Finished SERVER to CLIENT update"); 
         System.out.println("[<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<-<]"); 

         oos.flush();

         // close connections
         ois.close();
         oos.close();
         client.close(); 
      } catch(Exception e) {}       
   }
}