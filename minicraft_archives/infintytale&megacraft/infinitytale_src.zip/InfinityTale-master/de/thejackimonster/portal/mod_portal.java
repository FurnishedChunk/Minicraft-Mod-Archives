package de.thejackimonster.portal;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.level.tile.Tile;

import de.thejackimonster.ld22.modloader.BaseMod;
import de.thejackimonster.ld22.modloader.ModLoader;
import de.thejackimonster.ld22.options.ControlsMenu;
import de.thejackimonster.ld22.options.OptionFile;

public class mod_portal extends BaseMod {

	private int count = 0;

	public static Tile portal = new PortalTile(88);
	public static Item portal_gun = new PortalItem();

	@Override
	public void load() {
	}

	public void onItemPickup(Player player, Item item) {
		if(count == 0) player.inventory.add(new PortalItem());
		count++;
	}

	@Override
	public String getVersion() {
		return "Alpha";
	}

}
