package de.thejackimonster.portal;

import java.awt.Point;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.level.tile.Tile;

public class PortalTile extends Tile {

	public static int color = 0;
	public static Point[] portal_ = new Point[2];

	public PortalTile(int id) {
		super(id);
	}

	public static void useCanon() {
		if(color == 1) color = 0;
		else color = 1;
	}

	public void render(Screen screen, Level level, int x, int y) {
		super.render(screen, level, x, y);

		int data = level.getData(x, y);
		int shape = (data / 16) % 2;
		int col = Color.get(level.dirtColor, 004, 003, 005);
		if(data == 0) {
			col = Color.get(level.dirtColor, 420, 310, 530);
		}

		screen.render(x * 16 + 0, y * 16 + 0, 4 * 32 - 3, col, 0);
		screen.render(x * 16 + 8, y * 16 + 0, 4 * 32 - 2, col, 0);
		screen.render(x * 16 + 0, y * 16 + 8, 5 * 32 - 3, col, 0);
		screen.render(x * 16 + 8, y * 16 + 8, 5 * 32 - 2, col, 0);
		super.render(screen, level, x, y);
	}

	public void bumpedInto(Level level, int xt, int yt, Entity entity) {
		for(int i = 0; i < 2; i++) {
			if(portal_[0] == null) return;
			if(portal_[1] == null) return;
			if(portal_[i] != null) {
				if(xt == portal_[i].x && yt == portal_[i].y) {
					if(i == 0) {
						entity.x = (portal_[1].x * 16) + (entity.x % 16);
						entity.y = (portal_[1].y * 16) + (entity.y % 16);
					} else {
						entity.x = (portal_[0].x * 16) + (entity.x % 16);
						entity.y = (portal_[0].y * 16) + (entity.y % 16);
					}
				}
			}
		}
	}

	public int getLightRadius(Level level, int x, int y) {
		return 1;
	}

}
