package de.thejackimonster.portal;

import java.awt.Point;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.level.tile.Tile;
import com.mojang.ld22.sound.Sound;

public class Portal extends Entity {

	private final int color;
	private int dir;
	private final int speed = 2;

	public Portal(int xt, int yt, int i, int DIR) {
		super("Portal");
		color = i;
		x = xt*16 + 8;
		y = yt*16 + 8;
		dir = DIR;
	}

	public void render(Screen screen) {
		int col = Color.get(-1, 004, 003, 005);
		if(color == 0) {
			col = Color.get(-1, 420, 310, 530);
		}
		screen.render(x + 0*8 - 4, y + 0*8 - 8, 29 + 0*32, col, 0);
		super.render(screen);
	}

	public void tick() {
		switch(dir) {
		case 0:
			y += speed;
			break;
		case 1:
			y += -speed;
			break;
		case 2:
			x += -speed;
			break;
		case 3:
			x += speed;
			break;
		default:
			break;
		}
		
		if(level != null) {
			int xt = x / 16;
			int yt = y / 16;
			Tile tile = level.getTile(xt, yt);
			if(tile == null) remove();
			if(tile == Tile.rock) {
				level.setTile(xt, yt, mod_portal.portal, PortalTile.color);
				if(PortalTile.portal_[PortalTile.color] != null) {
					level.setTile(PortalTile.portal_[PortalTile.color].x, PortalTile.portal_[PortalTile.color].y, Tile.rock, 0);
				}
				PortalTile.portal_[PortalTile.color] = new Point(xt, yt);
				Sound.powerup.play();
				remove();
			}
			if(!tile.mayPass(level, xt, yt, this)) {
				Sound.craft.play();
				remove();
			}
		}
	}

	public boolean canSwim() {
		return true;
	}

	public int getLightRadius() {
		return mod_portal.portal.getLightRadius(level, 0, 0);
	}

}
