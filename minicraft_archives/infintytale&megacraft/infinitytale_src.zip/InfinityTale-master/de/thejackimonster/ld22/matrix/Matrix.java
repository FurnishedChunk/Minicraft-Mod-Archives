package de.thejackimonster.ld22.matrix;

import java.util.Collections;
import java.util.List;

import com.mojang.ld22.Game;
import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.Furniture;
import com.mojang.ld22.entity.Mob;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.level.tile.Tile;
import com.mojang.ld22.screen.TitleMenu;

import de.thejackimonster.ld22.story.dialog.NPC;

public class Matrix extends Level {

	public boolean matrixMode;

	public Matrix(boolean flag, Game game, int w, int h, int level, Level parentLevel,
			int mapsize, int waterc, int grassc, int rockc, int treec) {
		super(game, w, h, level, parentLevel, mapsize, waterc, grassc, rockc, treec);
		matrixMode = flag;
	}

	public void setTo(boolean flag) {
		matrixMode = flag;
	}

	public void renderBackground(Screen screen, int xScroll, int yScroll) {
		if(!matrixMode) {
			super.renderBackground(screen, xScroll, yScroll);
			return;
		}
		
		screen.clear(0);
		
		int xo = xScroll >> 4;
		int yo = yScroll >> 4;
		int w = (screen.w + 15) >> 4;
		int h = (screen.h + 15) >> 4;
		screen.setOffset(xScroll, yScroll);
		for (int y = yo; y <= h + yo; y++) {
			for (int x = xo; x <= w + xo; x++) {
				int[] r = new int[4];
				
				if(getTile(x, y).mayPass(this, x, y, this.player)) {
					r[0] = 0;
				} else {
					r[0] = 1;
				}
				
				r[1] = random.nextInt(6);
				
				if(getTile(x, y).id > 0) {
					r[2] = 1;
					int id = getTile(x, y).id;
					if(id == Tile.water.id) r[2] = 2;
					if(id == Tile.lava.id) r[2] = 3;
				} else {
					r[2] = 0;
				}
				
				if((r[2] == 1 || r[2] == 0) && fireTicks[x][y] > 0) r[2] = 4;
				
				r[3] = random.nextInt(6);
				
				for(int i = 0; i < 4; i++) {
					if(r[i] > 5) r[i] = 5;
				}
				
				Font.draw(String.valueOf(r[0]), screen, x*16, y*16, Color.get(-1, -1, -1, r[0]*10));
				Font.draw(String.valueOf(r[1]), screen, x*16 + 8, y*16, Color.get(-1, -1, -1, r[1]*10));
				Font.draw(String.valueOf(r[2]), screen, x*16, y*16 + 8, Color.get(-1, -1, -1, r[2]*10));
				Font.draw(String.valueOf(r[3]), screen, x*16 + 8, y*16 + 8, Color.get(-1, -1, -1, r[3]*10));
			}
		}
		screen.setOffset(0, 0);
	}

	public void renderSprites(Screen screen, int xScroll, int yScroll) {
		if(!matrixMode) {
			super.renderSprites(screen, xScroll, yScroll);
			return;
		}
		
		int xo = xScroll >> 4;
		int yo = yScroll >> 4;
		int w = (screen.w + 15) >> 4;
		int h = (screen.h + 15) >> 4;

		screen.setOffset(xScroll, yScroll);
		for (int y = yo; y <= h + yo; y++) {
			for (int x = xo; x <= w + xo; x++) {
				if (x < 0 || y < 0 || x >= this.w || y >= this.h) continue;
				rowSprites.addAll(entitiesInTiles[x + y * this.w]);
			}
			if (rowSprites.size() > 0) {
				sortAndRender(screen, rowSprites);
			}
			rowSprites.clear();
		}
		screen.setOffset(0, 0);
	}

	public void sortAndRender(Screen screen, List<Entity> list) {
		if(!matrixMode) {
			super.sortAndRender(screen, list);
			return;
		}
		
		if (! (game.menu instanceof TitleMenu)) {
			Collections.sort(list, spriteSorter);
			for (int i = 0; i < list.size(); i++) {
				int[] r = new int[4];
				if(list.get(i) instanceof Player) {
					r[0] = 4; r[1] = 4;
				} else
				if(list.get(i) instanceof NPC) {
					r[0] = 3; r[1] = 3;
				} else
				if(list.get(i) instanceof Mob) {
					r[0] = 1; r[1] = 1;
				} else
				if(list.get(i) instanceof Furniture) {
					r[0] = 2; r[1] = 2;
				} else {
					r[0] = 0; r[1] = 0;
				}
				
				if(list.get(i).x > 0) r[2] =  list.get(i).x % 10;
				else r[2] = 0;
				if(list.get(i).y > 0) r[3] =  list.get(i).y % 10;
				else r[3] = 0;
				
				for(int j = 0; j < 4; j++) {
					if(r[j] > 5) r[j] = 5;
				}
				
				Font.draw(String.valueOf(r[0]), screen, list.get(i).x - 8, list.get(i).y - 8, Color.get(-1, -1, -1, r[0]*10));
				Font.draw(String.valueOf(r[1]), screen, list.get(i).x, list.get(i).y - 8, Color.get(-1, -1, -1, r[1]*10));
				Font.draw(String.valueOf(r[2]), screen, list.get(i).x - 8, list.get(i).y, Color.get(-1, -1, -1, r[2]*10));
				Font.draw(String.valueOf(r[3]), screen, list.get(i).x, list.get(i).y, Color.get(-1, -1, -1, r[3]*10));
			}
		}
	}

}
