package de.thejackimonster.ld22.matrix;

import java.awt.event.KeyEvent;

import com.mojang.ld22.entity.Player;

import de.thejackimonster.ld22.modloader.BaseMod;
import de.thejackimonster.ld22.modloader.KeyBinding;
import de.thejackimonster.ld22.modloader.ModLoader;

public class mod_matrix extends BaseMod {

	public KeyBinding key_strg = new KeyBinding();
	public KeyBinding key_m = new KeyBinding();
	public KeyBinding key_n = new KeyBinding();

	@Override
	public void load() {
	}

	public void KeyboardEvent(int key, boolean pressed) {
		if(key == KeyEvent.VK_CONTROL) key_strg.toggle(pressed);
		if(key == KeyEvent.VK_M) key_m.toggle(pressed);
		if(key == KeyEvent.VK_N) key_n.toggle(pressed);
	}

	public void onTickByPlayer(Player player) {
		if(player.isrunning) {
			if(key_m.clicked) {
				if(player.level instanceof Matrix) {
					((Matrix)player.level).matrixMode = !((Matrix)player.level).matrixMode;
				}
			}
			if(key_n.clicked) {
				
			}
		}
	}

	@Override
	public String getVersion() {
		return "Alpha";
	}

}
