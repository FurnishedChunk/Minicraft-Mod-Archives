package de.thejackimonster.ld22.weapons;

import java.util.List;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.Mob;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Screen;

import de.thejackimonster.ld22.leveltree.Skill;
import de.thejackimonster.ld22.leveltree.mod_leveltree;
import de.thejackimonster.ld22.story.dialog.NPC;

public class Boomerang extends Entity {

	public Mob owner;
	public int xdir;
	public int ydir;
	public int damage;
	public boolean comeback;

	public Boomerang(Mob owner, int dirx, int diry, int dmg) {
		super("Boomerang");
		this.owner = owner;
		xdir = dirx;
		ydir = diry;
		damage = dmg;
		comeback = false;
		
		if(owner != null) {
			x=owner.x;
			y=owner.y;
		}
		
		if (owner instanceof Player) {
			if ( ((Player) owner).oneshotmobs ) {
				damage = 9999;
			}
		}
	}

	private int time;

	public void tick() {
		time++;
		
		int xa = xdir*2;
		int ya = ydir*2;
		
		if(owner == null) {
			remove();
			return;
		}
		
		if(comeback) {
			if(x > owner.x) x--;
			else if(x < owner.x) x++;
			else x+=0;
			
			if(y > owner.y) y--;
			else if(y < owner.y) y++;
			else y+=0;
			
			if(x == owner.x && y == owner.y) {
				if(owner instanceof Player) {
					//((Player) owner).inventory.add(new BoomerangItem());
					((Player) owner).activeItem = new BoomerangItem();
				}
				remove();
			}
		}
		List<Entity> entitylist = level.getEntities(x, y, x, y);
		for(int i = 0; i < entitylist.size(); i++) {
			Entity hit = entitylist.get(i);
			if(hit != null) {
				if (hit instanceof Mob && hit != owner) {
					hit.hurt(owner, damage, ((Mob) hit).dir ^ 1);
					comeback = true;
				}
			}
		}
		
		if(comeback) return;
		
		if(time > 10*10) comeback = true;
		
		if(Skill.weapon4.isCompleteDone() && mod_leveltree.coolDownSkill <= 0) {
			int r = 4;
			List<Entity> ents = level.getEntities(x-r*8, y-r*8, x+r*8, y+r*8);
			if(ents.size() > 1) {
				for(int i = 0; i < ents.size(); i++) {
					if((ents.get(i) instanceof Mob) && !(ents.get(i) instanceof Player) && !(ents.get(i) instanceof NPC)) {
						if(x < ents.get(i).x) x++;
						if(x > ents.get(i).x) x--;
						if(y < ents.get(i).y) y++;
						if(y > ents.get(i).y) y--;
						if(time % 45 == 0) mod_leveltree.coolDownSkill++;
						return;
					}
				}
			}
		}
		
		if(!move(xa, ya) || (!level.getTile(x/16, y/16).mayPass(level, x/16, y/16, this))) {
			comeback = true;
		}
	}

	public boolean isBlockableBy(Mob mob) {
		return false;
	}

	public void render(Screen screen) {
		if(time % 2 == 0) {
			screen.render(x, y, 4 + 11*32, Color.get(-1, 320, 540, -1), random.nextInt(4));
		} else {
			screen.render(x, y, 5 + 11*32, Color.get(-1, 320, 540, -1), random.nextInt(4));
		}
	}

}
