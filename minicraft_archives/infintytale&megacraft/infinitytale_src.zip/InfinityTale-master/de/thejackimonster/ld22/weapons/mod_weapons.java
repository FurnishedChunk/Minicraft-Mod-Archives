package de.thejackimonster.ld22.weapons;

import com.mojang.ld22.crafting.ItemRecipe;
import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.item.resource.Resource;

import de.thejackimonster.ld22.modloader.BaseMod;
import de.thejackimonster.ld22.modloader.ModLoader;

public class mod_weapons extends BaseMod {

	public static Entity boomerang = new Boomerang(null, 0, 0, 0);

	public static Item boome_rang = new BoomerangItem();

	static {
		try {
			ModLoader.wRecipes.add(new ItemRecipe(new BoomerangItem()).addCost(Resource.wood, 5));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void load() {
	}

	@Override
	public String getVersion() {
		return "Alpha";
	}

}
