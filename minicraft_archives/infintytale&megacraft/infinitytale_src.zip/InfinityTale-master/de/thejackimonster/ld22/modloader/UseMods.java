package de.thejackimonster.ld22.modloader;

import java.util.ArrayList;
import java.util.List;

import de.thejackimonster.ld22.bed.mod_bed;
import de.thejackimonster.ld22.loadandsave.mod_worldoptions;
import de.thejackimonster.ld22.redstone.mod_redstone;
import de.thejackimonster.ld22.story.dialog.mod_StoryMode;
import de.thejackimonster.ld22.vehicles.mod_minecarts;
import de.thejackimonster.ld22.weapons.mod_weapons;
import de.thejackimonster.ld22.leveltree.mod_leveltree;
import de.thejackimonster.ld22.matrix.mod_matrix;
import de.thejackimonster.ld22.options.mod_options_ingamemenu;
import de.thejackimonster.portal.mod_portal;

public class UseMods {

	private static final BaseMod[] mods = new BaseMod[256];

	public static void addMods() {
		mods[0] = new mod_worldoptions();
		mods[1] = new mod_redstone();
		mods[2] = new mod_leveltree();
		mods[3] = new mod_bed();
		mods[4] = new mod_StoryMode();
		mods[5] = new mod_weapons();
		mods[6] = new mod_matrix();
		mods[7] = new mod_options_ingamemenu();
		mods[8] = new mod_minecarts();
		mods[9] = new mod_portal();
	}

}
