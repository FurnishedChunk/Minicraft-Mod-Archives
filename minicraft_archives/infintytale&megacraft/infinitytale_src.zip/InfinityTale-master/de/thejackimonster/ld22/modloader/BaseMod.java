package de.thejackimonster.ld22.modloader;

import java.awt.event.KeyEvent;
import java.util.Random;

import com.mojang.ld22.Game;
import com.mojang.ld22.entity.Inventory;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.screen.DeadMenu;
import com.mojang.ld22.screen.Menu;

public abstract class BaseMod {

	public BaseMod() {
		ModLoader.mods.add(this);
	}

	public abstract void load();

	public void GenerateLevel(Level level, Random random, int i, int j)
    {
		return;
    }

	public void onTickInGame(Game game) {
		return;
	}

	public void onTickInMenu(Menu menu) {
		return;
	}

	public void onTickByPlayer(Player player) {
		return;
	}

	public abstract String getVersion();

	public String getName()
    {
        return getClass().getSimpleName();
    }

	public void KeyboardEvent(int key, boolean pressed)
    {
		return;
    }

	public void TakenFromCrafting(Player player, Item item, Inventory inventory)
    {
		return;
    }

    public void TakenFromFurnace(Player player, Item item)
    {
    	return;
    }

    public String toString()
    {
        return (new StringBuilder(String.valueOf(getName()))).append(' ').append(getVersion()).toString();
    }

    public void onItemPickup(Player player, Item item)
    {
    	return;
    }

}
