package de.thejackimonster.ld22.story.dialog;

import java.util.ArrayList;
import java.util.List;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.screen.Menu;
import com.mojang.ld22.sound.Sound;

public class DialogMenu extends Menu {

	public List<String> answerList = new ArrayList<String>();
	public List<String> dialogList = new ArrayList<String>();

	public final String dialog;

	private static final int line = 12;
	private int selected;
	private int level;

	public DialogMenu(String dialog, String... answers) {
		this.dialog = dialog;
		String text = "";
		int j = 0;
		List<String> s = new ArrayList<String>();
		for(int i = 0; i < dialog.length(); i++) {
			j++;
			if(String.valueOf(dialog.charAt(i)) != "_") {
				text = text + String.valueOf(dialog.charAt(i));
			}
			if(j > line || i+1 == dialog.length() || String.valueOf(dialog.charAt(i)) == "_") {
				dialogList.add(text);
				text = "";
				j = 0;
			}
		}
		for(int i = 0; i < answers.length; i++) {
			answerList.add(answers[i]);
		}
	}

	public void tick() {
		if(mod_StoryMode.key_r.clicked) {
			game.setMenu(null);
		}
		
		if(input.down.clicked) {
			selected++;
			Sound.toogle.play();
		}
		if(input.up.clicked) {
			selected--;
			Sound.toogle.play();
		}
		
		if(selected < 0) selected = answerList.size()-1;
		if(selected >= answerList.size()) selected = 0;
		
		if(input.attack.clicked || input.menu.clicked || input.cheatmenu.clicked) {
			Sound.select.play();
			say(dialog, selected);
		}
	}

	public void say(String dialog, int i) {
		selected = 0;
		DialogManager.say(dialog, i);
	}

	public void render(Screen screen) {
		Font.renderFrame(screen, "", 0, 0, line+2, screen.h/8-1);
		for(int i = 0; i < dialogList.size(); i++) {
			Font.draw(dialogList.get(i), screen, (8), (8 + i*10), Color.get(-1, -1, -1, 555));
		}
		
		int ypos = 16;
		for(int i = 0; i < answerList.size(); i++) {
			if(i == selected) {
				Font.renderFrame(screen, "", (screen.w/8 - 3 - answerList.get(i).length()), (ypos/8), (screen.w/8 - 3 - answerList.get(i).length())+answerList.get(i).length() + 2, (2 + ypos/8));
				Font.draw(">" + answerList.get(i), screen, (screen.w - 2*8 - answerList.get(i).length()*8), (8 + ypos), Color.get(-1, -1, -1, 555));
			} else {
				Font.renderFrame(screen, "", (screen.w/8 - 3 - answerList.get(i).length()/2), (ypos/8), (screen.w/8 - 3 - answerList.get(i).length()/2)+answerList.get(i).length() + 2, (2 + ypos/8));
				Font.draw(answerList.get(i), screen, (screen.w - 2*8 - (answerList.get(i).length()*8)/2), (8 + ypos), Color.get(-1, -1, -1, 555));
			}
			ypos += 32;
		}
	}
}
