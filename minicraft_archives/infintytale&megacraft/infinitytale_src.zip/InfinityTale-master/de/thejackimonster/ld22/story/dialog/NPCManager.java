package de.thejackimonster.ld22.story.dialog;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import com.mojang.ld22.gfx.Color;

public class NPCManager {

	public static List<NPC> npcList = new ArrayList<NPC>();

	public static NPC addNPC(NPC npc) {
		npcList.add(npc);
		return npc;
	}

	public static void remove(NPC npc) {
		if(npcList.contains(npc)) {
			npcList.remove(npc);
		}
	}

	public static NPC Karl = addNPC(new NPC("Karl", true, Color.get(-1, 100, 020, 532), DialogManager.karl_01));
	public static NPC Hans = addNPC(new NPC("Hans", true, Color.get(-1, 100, 020, 532), DialogManager.hans_01));
	public static NPC Dieter = addNPC(new NPC("Dieter", true, Color.get(-1, 100, 020, 532), DialogManager.dieter_01));
	public static NPC Frank = addNPC(new NPC("Frank", false, Color.get(-1, 100, 020, 532), DialogManager.frank_01));
	public static NPC Detlef = addNPC(new NPC("Detlef", true, 32-8,14,Color.get(-1, 333, 444, 532), DialogManager.detlef_01));

}
