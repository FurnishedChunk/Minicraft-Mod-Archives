package de.thejackimonster.ld22.story.dialog;

import java.util.Random;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.item.ResourceItem;
import com.mojang.ld22.item.ToolItem;
import com.mojang.ld22.item.ToolType;
import com.mojang.ld22.item.resource.Resource;

import de.thejackimonster.ld22.modloader.ModLoader;

public class DialogManager {

	public static DialogMenu karl_01 = new DialogMenu("I'm Karl.    Who are you?", "I don't know?!", "You!", "Notch?!");
	public static DialogMenu karl_02 = new DialogMenu("Oh,          I'm sorry!", "Bye!");
	public static DialogMenu karl_03 = new DialogMenu("What the..   You lie!", "Bye!");
	public static DialogMenu karl_04 = new DialogMenu("Oh my god,   this is..    Here, I hope,that this    sword can    help you!", "Thanks, bye!");
	public static DialogMenu karl_alternative = new DialogMenu("Hello,       Come later   again!", "Bye!");
	
	public static DialogMenu hans_01 = new DialogMenu("I'm Hans.    Do you       want sell    sand for     dirt,        because I    have so much dirt!", "Yes [1 Dirt]", "Yeah [10 Dirt]", "No!");
	public static DialogMenu hans_02 = new DialogMenu("You haven't  enough sand! Come later   again!", "Bye");
	
	public static DialogMenu dieter_01 = new DialogMenu("What are you doing here?", "I'm stranded.", "I fell down from the sky.", "I don't know?!");
	public static DialogMenu dieter_02 = new DialogMenu("Then you mustcraft a boat or you must  build a      house,       because at   night come   very very..  dangerous    monsters!", "How I can get wood?", "What kind of monsters?", "Okay, bye!");
	public static DialogMenu dieter_03 = new DialogMenu("Ha! Ha!      Good joke!   That's       impossible..", "Bye!");
	public static DialogMenu dieter_04 = new DialogMenu("An axe,      when you haveone of them, otherwise    with your    fists!", "Okay?!");
	public static DialogMenu dieter_05 = new DialogMenu("They come outin the       darkness and some of them explode!     Be carefull!", "Okay?!");
	
	public static DialogMenu frank_01 = new DialogMenu("Zzzzzz...    (He's        sleeping..)", "Hello?!", "Wake up!", "What ever!?.");
	public static DialogMenu frank_02 = new DialogMenu("What? ..yawn What is it?! I'm tired!", "Can you help me?", "Sorry!");
	
	public static DialogMenu detlef_01 = new DialogMenu("Do you need  a guard?     I can protectyou for      3 coal!", "Yes [3 coal]", "No");
	public static DialogMenu detlef_02 = new DialogMenu("You haven't  enough coal!", "Bye");
	public static DialogMenu detlef_03 = new DialogMenu("What?", "Wait here!", "Come with me!");

	public static void say(String dialog, int answer) {
		if(dialog == detlef_01.dialog) {
			if(answer == 0) {
				if(ModLoader.getGameInstance().player.inventory.count(new ResourceItem(Resource.coal)) >= 3) {
					ModLoader.getGameInstance().player.inventory.removeResource(Resource.coal, 3);
					NPCManager.Detlef.follow(ModLoader.getGameInstance().player, true);
					NPCManager.Detlef.dialog = detlef_03;
					ModLoader.getGameInstance().setMenu(null);
				} else {
					ModLoader.getGameInstance().setMenu(detlef_02);
				}
			}
			if(answer == 1) ModLoader.getGameInstance().setMenu(null);
		}
		if(dialog == detlef_02.dialog && answer == 0) ModLoader.getGameInstance().setMenu(null);
		if(dialog == detlef_03.dialog) {
			if(answer == 0) {
				NPCManager.Detlef.canWalk = false;
				NPCManager.Detlef.follow(null, false);
				ModLoader.getGameInstance().setMenu(null);
			}
			if(answer == 1) {
				NPCManager.Detlef.canWalk = true;
				NPCManager.Detlef.follow(ModLoader.getGameInstance().player, true);
				ModLoader.getGameInstance().setMenu(null);
			}
		}
		
		if(dialog == frank_01.dialog) {
			if(answer == 0) ModLoader.getGameInstance().setMenu(frank_01);
			if(answer == 1) {
				if(new Random().nextInt(3) == 0) {
					ModLoader.getGameInstance().setMenu(frank_02);
				} else {
					ModLoader.getGameInstance().setMenu(frank_01);
				}
			}
			if(answer == 2) ModLoader.getGameInstance().setMenu(null);
		}
		if(dialog == frank_02.dialog) {
			if(answer == 0) ModLoader.getGameInstance().setMenu(frank_01);
			if(answer == 1) {
				ModLoader.getGameInstance().setMenu(null);
			}
		}
		
		if(dialog == dieter_01.dialog) {
			if(answer == 0) ModLoader.getGameInstance().setMenu(dieter_02);
			if(answer == 1) ModLoader.getGameInstance().setMenu(dieter_03);
			if(answer == 2) ModLoader.getGameInstance().setMenu(null);
		}
		if(dialog == dieter_02.dialog) {
			if(answer == 0) ModLoader.getGameInstance().setMenu(dieter_04);
			if(answer == 1) ModLoader.getGameInstance().setMenu(dieter_05);
		}
		if((dialog == dieter_02.dialog && answer == 2) || (dialog == dieter_03.dialog && answer == 0) || (dialog == dieter_04.dialog && answer == 0) || (dialog == dieter_05.dialog && answer == 0)) ModLoader.getGameInstance().setMenu(null);
		
		if(dialog == hans_01.dialog) {
			if(answer == 2) {
				ModLoader.getGameInstance().setMenu(null);
			} else {
				int x = 1;
				if(answer == 0) x = 1;
				if(answer == 1) x = 10;
				for(int i = 0; i < x; i++) {
					if(ModLoader.getGameInstance().player.inventory.count(new ResourceItem(Resource.sand)) > 0) {
						ModLoader.getGameInstance().player.inventory.removeResource(Resource.sand, 1);
						ModLoader.getGameInstance().player.inventory.add(new ResourceItem(Resource.dirt));
					} else {
						x = i+1;
						ModLoader.getGameInstance().setMenu(hans_02);
					}
				}
			}
		}
		if(dialog == hans_02.dialog && answer == 0) ModLoader.getGameInstance().setMenu(null);
		
		if(dialog == karl_01.dialog) {
			if(answer == 0) ModLoader.getGameInstance().setMenu(karl_02);
			if(answer == 1) ModLoader.getGameInstance().setMenu(karl_03);
			if(answer == 2) ModLoader.getGameInstance().setMenu(karl_04);
			NPCManager.Karl.dialog = karl_alternative;
		}
		if((dialog == karl_02.dialog || dialog == karl_03.dialog || dialog == karl_alternative.dialog) && answer == 0) {
			ModLoader.getGameInstance().setMenu(null);
		}
		if(dialog == karl_04.dialog && answer == 0) {
			ModLoader.getGameInstance().player.inventory.add(new ToolItem(ToolType.sword, 2));
			ModLoader.getGameInstance().setMenu(null);
		}
	}
}
