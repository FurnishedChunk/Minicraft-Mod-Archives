package de.thejackimonster.ld22.story.character;

import java.awt.event.KeyEvent;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;

public class TextBox {

	private String text;
	private boolean enabled;
	private boolean onlyRead;

	public final int x0;
	public final int y0;
	public final int x1;
	public final int y1;

	public TextBox(String s, int x, int y, int w) {
		x0 = x;
		y0 = y;
		x1 = w;
		y1 = 4*5;
		enabled = false;
		onlyRead = false;
		setText(s);
	}

	public TextBox(String s, int x, int y, int w, boolean flag) {
		x0 = x;
		y0 = y;
		x1 = w;
		y1 = 4*5;
		enabled = false;
		onlyRead = flag;
		setText(s);
	}

	public String getText() {
		return text;
	}

	public void setEnabled(boolean flag) {
		if(!onlyRead) {
			enabled = flag;
		} else {
			enabled = false;
		}
	}

	public boolean getEnabled() {
		return enabled && !onlyRead;
	}

	public void Write(int key) {
		if((KeyEvent.getKeyText(key).length() == 1) &&
		  (Font.chars.indexOf(KeyEvent.getKeyText(key)) >= 0) &&
		  (text.length()*4 + 8 < x1/2)) {
			String s = KeyEvent.getKeyText(key);
			text += s;
		} else if(key == KeyEvent.VK_SPACE &&
				 (text.length()*4 + 8 < x1/2)) {
			text += " ";
		} else if(key == KeyEvent.VK_BACK_SPACE) {
			String s = "";
			for(int i = 0; i < text.length() - 1; i++) {
				s += String.valueOf(text.charAt(i));
			}
			text = s;
		}
	}

	public void render(Screen screen) {
		int col1 = 111;
		int col2 = 0;
		int col3 = 222;
		for (int j = y0/8; j <= y0/8+y1/8; j++) {
			for (int i = x0/8; i <= x0/8+x1/8; i++) {
				if (i == x0/8 && j == y0/8)
					screen.render(i*8, j*8, 0 + 13 * 32, Color.get(-1, col1, col2, col3), 0);
				else if (i == x0/8+x1/8 && j == y0/8)
					screen.render(i*8, j*8, 0 + 13 * 32, Color.get(-1, col1, col2, col3), 1);
				else if (i == x0/8 && j == y0/8+y1/8)
					screen.render(i*8, j*8, 0 + 13 * 32, Color.get(-1, col1, col2, col3), 2);
				else if (i == x0/8+x1/8 && j == y0/8+y1/8)
					screen.render(i*8, j*8, 0 + 13 * 32, Color.get(-1, col1, col2, col3), 3);
				else if (j == y0/8)
					screen.render(i*8, j*8, 1 + 13 * 32, Color.get(-1, col1, col2, col3), 0);
				else if (j == y0/8+y1/8)
					screen.render(i*8, j*8, 1 + 13 * 32, Color.get(-1, col1, col2, col3), 2);
				else if (i == x0/8)
					screen.render(i*8, j*8, 2 + 13 * 32, Color.get(-1, col1, col2, col3), 0);
				else if (i == x0/8+x1/8)
					screen.render(i*8, j*8, 2 + 13 * 32, Color.get(-1, col1, col2, col3), 1);
				else
					screen.render(i*8, j*8, 2 + 13 * 32, Color.get(col2, col2, col2, col2), 1);
			}
		}
		Font.draw(text, screen, x0 + x1/2 - (text.length()*4), y0/8*8 + y1/8*8/2, Color.get(col2, col2, col2, 555));
	}

	public void setText(String s) {
		text = "";
		for(int j = 0; j < s.length(); j++) {
			if(Font.chars.indexOf(s.charAt(j)) >= 0 &&
			  (text.length()*4 + 8 < x1/2)) {
				text += String.valueOf(s.charAt(j));
			}
		}
	}

}