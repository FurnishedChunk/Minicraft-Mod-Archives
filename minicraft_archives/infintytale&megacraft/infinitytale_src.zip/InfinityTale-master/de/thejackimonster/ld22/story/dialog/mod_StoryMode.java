package de.thejackimonster.ld22.story.dialog;

import java.awt.event.KeyEvent;
import java.util.Random;

import com.mojang.ld22.Game;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.level.tile.Tile;
import com.mojang.ld22.sound.Sound;

import de.thejackimonster.ld22.leveltree.LevelTreeMenu;
import de.thejackimonster.ld22.leveltree.Skill;
import de.thejackimonster.ld22.modloader.BaseMod;
import de.thejackimonster.ld22.modloader.KeyBinding;
import de.thejackimonster.ld22.modloader.ModLoader;
import de.thejackimonster.ld22.options.OptionFile;
import de.thejackimonster.ld22.story.character.NewCharacterMenu;

public class mod_StoryMode extends BaseMod {

	public static final KeyBinding key_r = new KeyBinding();

	public void KeyboardEvent(int key, boolean pressed) {
		if(key == OptionFile.keys[11]) key_r.toggle(pressed);
		if(ModLoader.getGameInstance().menu != null) {
			if(ModLoader.getGameInstance().menu instanceof NewCharacterMenu) {
				((NewCharacterMenu)ModLoader.getGameInstance().menu).onKeyClicked(key);
			}
		}
	}

	@Override
	public void load() {
	}

	@Override
	public String getVersion() {
		return "Beta";
	}

}
