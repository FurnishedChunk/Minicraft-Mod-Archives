package de.thejackimonster.ld22.options;

import java.awt.event.KeyEvent;

import com.mojang.ld22.Game;
import com.mojang.ld22.gfx.Color;

import de.thejackimonster.ld22.file.SystemFile;

public class OptionFile {

	public static boolean created = false;
	public static Game g;
	public static int difficulty = 0;
	public static String name = "Player";
	public static int color = Color.get(-1, 100, 220, 532);
	public static int a = -1;
	public static int b = 100;
	public static int c = 220;
	public static int d = 532;
	public static int[] keys = { KeyEvent.VK_W, KeyEvent.VK_A, KeyEvent.VK_S, KeyEvent.VK_D, KeyEvent.VK_Q, 
		KeyEvent.VK_V, KeyEvent.VK_ESCAPE, KeyEvent.VK_C, KeyEvent.VK_X, KeyEvent.VK_Y, KeyEvent.VK_E, 
		KeyEvent.VK_R };
	public static int[] bkeys = { KeyEvent.VK_W, KeyEvent.VK_A, KeyEvent.VK_S, KeyEvent.VK_D, KeyEvent.VK_Q, 
		KeyEvent.VK_V, KeyEvent.VK_ESCAPE, KeyEvent.VK_C, KeyEvent.VK_X, KeyEvent.VK_Y, KeyEvent.VK_E, 
		KeyEvent.VK_R };

	public static void create(Game game) {
		if(game == null || game.isApplet) return;
		created = true;
		g = game;
		SystemFile sf = new SystemFile("options.txt", game);
		sf.Create();
		sf.Close();
		readOpt();
		for(int i = 0; i < keys.length; i++) {
			if(keys[i] == 0) keys[i] = bkeys[i];
		}
		writeOpt();
	}

	public static void readOpt() {
		if(!created) return;
		SystemFile sf = new SystemFile("options.txt", g);
		sf.Create();
		sf.Reset();
		sf.Read();
		int i = 0;
		while(!sf.EndOfFile()) {
			String s = sf.ReadLn();
			if(i == 0) difficulty = Integer.parseInt(s);
			if(i == 1) name = s;
			if(i >= 2 && i <= 5) {
				if(i == 2) a = ((int)Double.parseDouble(s));
				if(i == 3) b = ((int)Double.parseDouble(s));
				if(i == 4) c = ((int)Double.parseDouble(s));
				if(i == 5) {
					d = (int)Double.parseDouble(s);
					color = Color.get(a, b, c, d);
				}
			}
			if((i-6) >= 0 && (i-6) < keys.length) keys[i-6] = Integer.parseInt(s);
			i++;
		}
		sf.Close();
	}

	public static void writeOpt() {
		if(!created) return;
		SystemFile sf = new SystemFile("options.txt", g);
		sf.Create();
		sf.Rewrite();
		sf.WriteLn(String.valueOf(difficulty));
		sf.WriteLn(name);
		sf.WriteLn(String.valueOf((double)a));
		sf.WriteLn(String.valueOf((double)b));
		sf.WriteLn(String.valueOf((double)c));
		sf.WriteLn(String.valueOf((double)d));
		for(int i = 0; i < keys.length; i++) {
			sf.WriteLn(String.valueOf(keys[i]));
		}
		sf.Write();
		sf.Close();
	}

}
