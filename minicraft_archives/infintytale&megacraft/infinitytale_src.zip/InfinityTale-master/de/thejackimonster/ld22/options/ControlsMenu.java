package de.thejackimonster.ld22.options;

import java.awt.event.KeyEvent;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.screen.Menu;
import com.mojang.ld22.sound.Sound;

public class ControlsMenu extends Menu {

	private int selX, selY;
	private boolean wait;
	private final boolean ingame;
	private int ticks;

	public ControlsMenu(boolean flag) {
		ingame = flag;
	}

	public void onKeyClicked(int key) {
		ticks++;
		if(wait && ticks % 3 == 0) {
			if((selY + selX*OptionFile.keys.length/2) >= 0 && (selY + selX*OptionFile.keys.length/2) < OptionFile.keys.length) {
				OptionFile.keys[(selY + selX*OptionFile.keys.length/2)] = key;
			}
			wait = false;
		}
	}

	public void tick() {
		if(!wait) {
			if(input.up.clicked) selY--;
			if(input.down.clicked) selY++;
			if(input.left.clicked) selX--;
			if(input.right.clicked) selX++;
			
			if(selY < 0) selY = 0;
			if(selY > OptionFile.keys.length/2) selY = OptionFile.keys.length/2;
			if(selX < 0) selX = 0;
			if(selX > 1) selX = 1;
			if(selY == OptionFile.keys.length/2) selX = 0;
			
			if(input.up.clicked || input.down.clicked || input.left.clicked || input.right.clicked) {
				Sound.select.play();
			}
			
			if(input.attack.clicked || input.menu.clicked) {
				Sound.toogle.play();
				if(selX == 0 && selY == OptionFile.keys.length/2) {
					if(!game.isApplet) OptionFile.writeOpt();
					game.setMenu(new OptionsMenu(ingame));
				} else {
					ticks = 0;
					if((selY + selX*OptionFile.keys.length/2) >= 0 && (selY + selX*OptionFile.keys.length/2) < OptionFile.keys.length) {
						OptionFile.keys[(selY + selX*OptionFile.keys.length/2)] = -1;
						wait = true;
					}
				}
			}
		}
	}

	public void render(Screen screen) {
		screen.clear(0);
		
		int x = 0;
		int y = 0;
		for(int i = 0; i < OptionFile.keys.length; i++) {
			x = screen.w/4;
			y = screen.h/10;
			if(y != 0) y += i * 12;
			if(i >= OptionFile.keys.length/2) {
				x += screen.w/2;
				y -= OptionFile.keys.length/2 * 12;
			}
			
			String msg = KeyEvent.getKeyText(OptionFile.keys[i]);
			
			if(selY != OptionFile.keys.length/2) {
				if(selY + selX*OptionFile.keys.length/2 == i) {
					msg = "> " + msg + " <";
				}
			}
			
			Font.draw(msg, screen, x - msg.length()*4, y, Color.get(-1, -1, -1, 555));
		}
		x -= screen.w/8;
		y += 16;
		String msg = "Done";
		
		if(selY == OptionFile.keys.length/2 && selX == 0) {
			msg = "> " + msg + " <";
		}
		
		Font.draw(msg, screen, x - msg.length()*4, y, Color.get(-1, -1, -1, 555));
	}
}
