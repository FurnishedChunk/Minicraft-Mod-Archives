package de.thejackimonster.ld22.options;

import java.awt.event.KeyEvent;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.screen.TitleMenu;
import com.mojang.ld22.sound.Sound;

import de.thejackimonster.ld22.leveltree.LevelTreeMenu;
import de.thejackimonster.ld22.modloader.BaseMod;
import de.thejackimonster.ld22.modloader.KeyBinding;
import de.thejackimonster.ld22.modloader.ModLoader;
import de.thejackimonster.ld22.story.character.NewCharacterMenu;

public class mod_options_ingamemenu extends BaseMod {

	public static KeyBinding key_esc = new KeyBinding();

	@Override
	public void load() {
		OptionFile.create(ModLoader.getGameInstance());
	}

	public void KeyboardEvent(int key, boolean pressed) {
		if(key == OptionFile.keys[6]) key_esc.toggle(pressed);
		
		if(ModLoader.getGameInstance().menu != null) {
			if(ModLoader.getGameInstance().menu instanceof ControlsMenu) {
				((ControlsMenu)ModLoader.getGameInstance().menu).onKeyClicked(key);
			}
		}
	}

	public void onTickByPlayer(Player player) {
		if(player != null) {
			if(player.game.menu == null) {
				if(key_esc.clicked) {
					player.game.setMenu(new IngameMenu());
					Sound.toogle.play();
				}
			}
			if(player.game.menu instanceof TitleMenu) {
				if(key_esc.clicked) {
					for(int i = 0; i < OptionFile.keys.length; i++) {
						OptionFile.keys[i] = OptionFile.bkeys[i];
					}
					OptionFile.writeOpt();
				}
			}
		}
	}

	@Override
	public String getVersion() {
		return "Alpha";
	}

}
