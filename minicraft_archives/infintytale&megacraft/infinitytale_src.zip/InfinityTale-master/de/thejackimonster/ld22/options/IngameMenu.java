package de.thejackimonster.ld22.options;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.screen.Menu;
import com.mojang.ld22.screen.TitleMenu;
import com.mojang.ld22.sound.Sound;

import de.thejackimonster.ld22.leveltree.AchievementListMenu;
import de.thejackimonster.ld22.loadandsave.WorldSaveLoadMenu;
import de.thejackimonster.ld22.modloader.ModLoader;

public class IngameMenu extends Menu {

	private int selected = 0;

	private static final String[] options = { "Back To Game", "Save World","Options","Save And Quit"};

	public void tick() {
		if(input.up.clicked) selected--;
		if(input.down.clicked) selected++;

		if(input.up.clicked || input.down.clicked){
			Sound.select.play();
		}
		
		if(selected < 0) selected = options.length-1;
		if(selected >= options.length) selected = 0;
		
		if(input.attack.clicked || input.menu.clicked) {
			Sound.toogle.play();
			if(selected == 0) game.setMenu(null);
			if(selected == 1 && !game.isApplet) new WorldSaveLoadMenu().saveMap(game);
			if(selected == 2) game.setMenu(new OptionsMenu(true));
			if(selected == 3) {
				if(!game.isApplet) new WorldSaveLoadMenu().saveMap(game);
				game.setMenu(new TitleMenu());
			}
		}
	}

	public void render(Screen screen) {
		int h2 = 2;
		int w2 = 16;
		int titleColor = Color.get(-1, 107, 8, 255);
		int xo = (screen.w - w2 * 8) / 2;
		int yo = 24;
		
		Font.renderFrame(screen, "", 9, 5, 22, 14);
		
		for (int y = 0; y < h2; y++) {
			for (int x = 0; x < w2; x++) {
				screen.render(xo + x * 8, yo + y * 8, x+14 + (y + 6) * 32, titleColor, 0);
			}
		}
		
		for (int i = 0; i < options.length; i++) {
			String msg = options[i];
			int col = Color.get(-1, 222, 222, 222);
			if (i == selected) {
				msg = "> " + msg + " <";
				col = Color.get(-1, 555, 555, 555);
			}
			Font.draw(msg, screen, (screen.w - msg.length() * 8) / 2, (8 + i) * 8-16, col);
		}
	}
}
