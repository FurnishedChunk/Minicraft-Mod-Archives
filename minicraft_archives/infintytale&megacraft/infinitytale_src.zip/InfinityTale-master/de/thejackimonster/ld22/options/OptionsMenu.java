package de.thejackimonster.ld22.options;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.screen.Menu;
import com.mojang.ld22.screen.TitleMenu;
import com.mojang.ld22.sound.Sound;

import de.thejackimonster.ld22.leveltree.AchievementListMenu;
import de.thejackimonster.ld22.loadandsave.WorldSaveLoadMenu;

public class OptionsMenu extends Menu {

	private int ticks;
	private int selected = 0;
	private int selDiff = 0;

	private static final String[] diff = { "Peacefull", "Easy", "Normal", "Hard"};
	private static final String[] options = { "Difficulty: ", "AutoSave: ", "Achievements..", "Controls..", "Done"};
	private final boolean ingame;

	public OptionsMenu(boolean flag) {
		ingame = flag;
		selDiff = OptionFile.difficulty;
	}

	public void tick() {
		if(ticks == 0) if(!game.isApplet) OptionFile.readOpt();
		ticks++;
		
		if(input.up.clicked) selected--;
		if(input.down.clicked) selected++;

		if(input.up.clicked || input.down.clicked){
			Sound.select.play();
		}
		
		if(selected < 0) selected = options.length-1;
		if(selected >= options.length) selected = 0;
		
		if(input.attack.clicked || input.menu.clicked) {
			Sound.toogle.play();
			if(selected == 0) selDiff++;
			if(selected == 1) {
				game.autosave = !game.autosave;
			}
			if(selected == 2) {
				if(!game.isApplet) saveChanges();
				game.setMenu(new AchievementListMenu(ingame));;
			}
			if(selected == 3) {
				if(!game.isApplet) saveChanges();
				game.setMenu(new ControlsMenu(ingame));;
			}
			if(selected == 4) {
				if(!game.isApplet) saveChanges();
				if(ingame) game.setMenu(new IngameMenu());
				if(!ingame) game.setMenu(new TitleMenu());
			}
		}
		
		if(selDiff >= diff.length) selDiff = 0;
		if(selDiff < 0) selDiff = diff.length-1;
	}

	public void saveChanges() {
		OptionFile.difficulty = selDiff;
		if(!game.isApplet) OptionFile.writeOpt();
	}

	public void render(Screen screen) {
		int h2 = 2;
		int w2 = 16;
		int titleColor = Color.get(-1, 107, 8, 255);
		int xo = (screen.w - w2 * 8) / 2;
		int yo = 24;
		
		Font.renderFrame(screen, "", 5, 5, 26, 13);
		
		for (int i = 0; i < options.length; i++) {
			String msg = options[i];
			int col = Color.get(-1, 222, 222, 222);
			
			if(i == 0) msg = msg + diff[selDiff];
			if(i == 1) {
				if(game.autosave) msg = msg + "ON";
				if(!game.autosave) msg = msg + "OFF";
			}
			
			if (i == selected) {
				msg = "> " + msg + " <";
				col = Color.get(-1, 555, 555, 555);
			}
			Font.draw(msg, screen, (screen.w - msg.length() * 8) / 2, (8 + i) * 8-16, col);
		}
	}

}
