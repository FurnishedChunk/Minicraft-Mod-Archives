package de.thejackimonster.ld22.redstone;

import java.util.ArrayList;
import java.util.List;

import com.mojang.ld22.entity.Furniture;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.entity.particle.TextParticle;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.item.ToolItem;
import com.mojang.ld22.item.ToolType;
import com.mojang.ld22.level.tile.Tile;

public class RedstoneTorch extends Furniture {

	public boolean on = false;
	private int ticks = 0;
	public int tickTime = 0;

	public RedstoneTorch() {
		super("RedstoneTorch");
		
		col = Color.get(-1, 110, 0, 552);
		sprite = 6;
	}

	public void tick() {
		super.tick();
		ticks++;
		int xt = x >> 4;
		int yt = y >> 4;
		
		boolean u = level.getTile(xt, yt - 1) == mod_redstone.wire;
		boolean d = level.getTile(xt, yt + 1) == mod_redstone.wire;
		boolean l = level.getTile(xt - 1, yt) == mod_redstone.wire;
		boolean r = level.getTile(xt + 1, yt) == mod_redstone.wire;
		
		List<RedstoneTile> connect = new ArrayList<RedstoneTile>();
		if(u) {
			connect.add((RedstoneTile)level.getTile(xt, yt - 1));
		}
		if(d) {
			connect.add((RedstoneTile)level.getTile(xt, yt + 1));
		}
		if(l) {
			connect.add((RedstoneTile)level.getTile(xt - 1, yt));
		}
		if(r) {
			connect.add((RedstoneTile)level.getTile(xt + 1, yt));
		}
		if(connect.size() > 0) {
			for(int i = 0; i < connect.size(); i++) {
				if(!connect.get(i).signal) {
					if(this.on) {
						connect.get(i).signal = true;
					}
				}
			}
		}
	}

	public boolean use(Player player, int attackDir) {
		 //	player.game.setMenu(new ContainerMenu(player, "Torch", inventory));
			
		if (on) {
			on = false;
			col = Color.get(-1, 110, 0, 552);
		} else {
			on = true;
			col = Color.get(-1, 110, 500, 480);
		}
		return true;
	}

	public int getLightRadius() {
		if (on) {	
			return 3;
		}
		return 0;
	}
}
