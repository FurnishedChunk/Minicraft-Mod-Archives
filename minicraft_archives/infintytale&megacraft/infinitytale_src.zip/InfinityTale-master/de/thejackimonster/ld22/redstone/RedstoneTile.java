package de.thejackimonster.ld22.redstone;

import java.util.ArrayList;
import java.util.List;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.ItemEntity;
import com.mojang.ld22.entity.Mob;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.entity.particle.SmashParticle;
import com.mojang.ld22.entity.particle.TextParticle;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.item.ResourceItem;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.level.tile.Tile;

public class RedstoneTile extends Tile {

	public boolean signal = false;
	private int ticks = 0;

	public RedstoneTile(int id) {
		super(id);
	}

	public void render(Screen screen, Level level, int x, int y) {
		int c = 100;
		if(signal) {
			c = 200;
		}
		int col = Color.get(level.dirtColor, c+100, c+200, c+300);

		boolean u = level.getTile(x, y - 1) == this;
		boolean d = level.getTile(x, y + 1) == this;
		boolean l = level.getTile(x - 1, y) == this;
		boolean r = level.getTile(x + 1, y) == this;

		int t1 = 2*32 - 3;
		int t2 = 2*32 - 2;
		int t3 = 3*32 - 3;
		int t4 = 3*32 - 2;
		if(u) {
			if(!l) {
				t1 = 1*32 - 11;
			}
			if(!r) {
				t2 = 1*32 - 10;
			}
		}
		if(d) {
			if(!l) {
				t3 = 1*32 - 9;
			}
			if(!r) {
				t4 = 1*32 - 8;
			}
		}
		if((u || d) && (!l || !d)) {
			if(!l) {
				t1 = 1*32 - 11;
				t3 = 1*32 - 9;
			}
			if(!r) {
				t2 = 1*32 - 10;
				t4 = 1*32 - 8;
			}
		}
		if(l) {
			if(!u) {
				t1 = 1*32 - 7;
			}
			if(!d) {
				t3 = 1*32 - 6;
			}
		}
		if(r) {
			if(!u) {
				t2 = 1*32 - 5;
			}
			if(!d) {
				t4 = 1*32 - 4;
			}
		}
		if((l || r) && (!u || !d)) {
			if(!u) {
				t1 = 1*32 - 7;
				t2 = 1*32 - 5;
			}
			if(!d) {
				t3 = 1*32 - 6;
				t4 = 1*32 - 4;
			}
		}
		int clear = 32*32 - 1;
		if((l || r) && ((!l) || (!r)) && (u || d) && ((!u) || (!d))) {
			if(u) {
				if(l) {
					t4 = clear;
				} else
				if(r) {
					t3 = clear;
				}
			} else
			if(d) {
				if(l) {
					t2 = clear;
				} else
				if(r) {
					t1 = clear;
				}
			}
		}
		screen.render(x * 16 + 0, y * 16 + 0, t1, col, 0);
		screen.render(x * 16 + 8, y * 16 + 0, t2, col, 0);
		screen.render(x * 16 + 0, y * 16 + 8, t3, col, 0);
		screen.render(x * 16 + 8, y * 16 + 8, t4, col, 0);
	}

	public boolean mayPass(Level level, int x, int y, Entity e) {
		return true;
	}

	public void hurt(Level level, int x, int y, Mob source, int dmg, int attackDir) {
		hurt(level, x, y, dmg);
	}

	public boolean interact(Level level, int xt, int yt, Player player, Item item, int attackDir) {
		if (player.payStamina(1)) {
			hurt(level, xt, yt, random.nextInt(10) + 10);
			return true;
		}
		return false;
	}

	public void hurt(Level level, int x, int y, int dmg) {
		int damage = level.getData(x, y) + dmg;
		level.add(new SmashParticle(x * 16 + 8, y * 16 + 8));
		level.add(new TextParticle("" + dmg, x * 16 + 8, y * 16 + 8, Color.get(-1, 500, 500, 500)));
		if (damage >= 1) {
			level.add(new ItemEntity(new ResourceItem(mod_redstone.redstone, 1), x * 16 + random.nextInt(10) + 3, y * 16 + random.nextInt(10) + 3));
			
			level.setTile(x, y, Tile.dirt, 0);
		} else {
			level.setData(x, y, damage);
		}
	}

	public void tick(Level level, int xt, int yt) {
		ticks++;
		int damage = level.getData(xt, yt);
		if (damage > 0) level.setData(xt, yt, damage - 1);

		boolean u = level.getTile(xt, yt - 1) == this;
		boolean d = level.getTile(xt, yt + 1) == this;
		boolean l = level.getTile(xt - 1, yt) == this;
		boolean r = level.getTile(xt + 1, yt) == this;
		
		List<RedstoneTile> connect = new ArrayList<RedstoneTile>();
		if(u) {
			connect.add((RedstoneTile)level.getTile(xt, yt - 1));
		}
		if(d) {
			connect.add((RedstoneTile)level.getTile(xt, yt + 1));
		}
		if(l) {
			connect.add((RedstoneTile)level.getTile(xt - 1, yt));
		}
		if(r) {
			connect.add((RedstoneTile)level.getTile(xt + 1, yt));
		}
		this.signal = false;
		if(connect.size() > 0) {
			for(int i = 0; i < connect.size(); i++) {
				if(!connect.get(i).signal) {
					if(this.signal) {
						connect.get(i).signal = true;
					}
				} else {
					if(!this.signal) {
						this.signal = true;
					}
				}
			}
		}
	}

	public int getLightRadius(Level level, int x, int y) {
		if(signal) {
			return 1;
		} else {
			return 0;
		}
	}

}
