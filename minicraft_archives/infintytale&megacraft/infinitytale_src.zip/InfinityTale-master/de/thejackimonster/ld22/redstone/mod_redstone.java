package de.thejackimonster.ld22.redstone;

import java.util.Random;

import com.mojang.ld22.Game;
import com.mojang.ld22.crafting.FurnitureRecipe;
import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.item.FurnitureItem;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.item.ResourceItem;
import com.mojang.ld22.item.resource.PlantableResource;
import com.mojang.ld22.item.resource.Resource;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.level.tile.OreTile;
import com.mojang.ld22.level.tile.Tile;

import de.thejackimonster.ld22.modloader.BaseMod;
import de.thejackimonster.ld22.modloader.ModLoader;

public class mod_redstone extends BaseMod {

	public static Tile wire = new RedstoneTile(50);

	public static Resource redstone = new PlantableResource("Redstone", 5 + 4 * 32 , wire,Color.get(-1, 100, 300, 500), Tile.grass, Tile.dirt,Tile.sand, Tile.farmland);

	public static Tile redstone_ore = new OreTile(51, redstone, 0);

	public static final Entity redstoneTorch = new RedstoneTorch();

	public static Item redstone_power = new ResourceItem(redstone);
	public static Item redstone_torch = new FurnitureItem(new RedstoneTorch());

	static {
		try {
			ModLoader.wRecipes.add(new FurnitureRecipe(RedstoneTorch.class).addCost(redstone, 1).addCost(Resource.wood, 1));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void load() {
	}

	public void GenerateLevel(Level level, Random random, int i, int j) {
		if(level.depth < -1) {
			if(level.getTile(i, j) == Tile.rock) {
				if(random.nextInt(30) == 0) {
					level.setTile(i, j, redstone_ore, 0);
					if(ModLoader.getGameInstance() != null) {
						if(ModLoader.getGameInstance().player != null) {
							if(ModLoader.getGameInstance().player.inventory != null) {
							//	ModLoader.getGameInstance().player.inventory.add(new ResourceItem(redstone));
							}
						}
					}
				}
			}
		}
	}

	@Override
	public String getVersion() {
		return "Alpha";
	}

}
