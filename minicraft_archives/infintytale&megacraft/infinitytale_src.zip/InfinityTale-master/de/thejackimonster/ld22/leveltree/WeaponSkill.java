package de.thejackimonster.ld22.leveltree;

import com.mojang.ld22.entity.Arrow;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.item.ToolItem;
import com.mojang.ld22.item.ToolType;

public class WeaponSkill extends SpecialSkill {

	private int weaponDamage;

	public WeaponSkill(String s, int x, int y, Skill parent, Item item, int i) {
		super(s, x, y, parent, item, i);
	}

	@Override
	public void use(Player player) {
		if(player.attackItem instanceof ToolItem) {
			weaponDamage = ((ToolItem)player.attackItem).level + level;
		}
	}

	@Override
	public int getAttack() {
		return weaponDamage;
	}

	@Override
	public void playerUse(Player player) {
		boolean flag = false;
		if(player.attackItem instanceof ToolItem && mod_leveltree.coolDownSkill == 0) {
			ToolItem tool = (ToolItem) player.attackItem;
			if(tool.type == ToolType.bow  && player.stamina-3>=0 && level == 1) {
				if(mod_leveltree.coolDownSkill <= 0 && Skill.weapon1.isCompleteDone()) {
					mod_leveltree.coolDownSkill += weaponDamage*5*3;
					flag = true;
				}
                player.level.add(new Arrow(player,0,-1,weaponDamage, flag));
                player.level.add(new Arrow(player,0,1,weaponDamage, flag));
                player.level.add(new Arrow(player,1,0,weaponDamage, flag));
                player.level.add(new Arrow(player,-1,0,weaponDamage, flag));
				
				flag = true;
			}
		}
		
		if(flag) {
			mod_leveltree.coolDownSkill += weaponDamage * 10;
		}
	}

}
