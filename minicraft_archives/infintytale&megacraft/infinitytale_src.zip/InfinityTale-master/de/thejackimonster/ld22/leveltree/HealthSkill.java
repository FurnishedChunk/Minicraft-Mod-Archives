package de.thejackimonster.ld22.leveltree;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.item.Item;

public class HealthSkill extends Skill {

	private int heal;

	public HealthSkill(String s, int x, int y, Skill parent, Item item, int i) {
		super(s, x, y, parent, item);
		this.heal = i;
	}

	@Override
	public void use(Player player) {
		if(onTick()) {
			player.heal(this.heal);
		}
	}

}
