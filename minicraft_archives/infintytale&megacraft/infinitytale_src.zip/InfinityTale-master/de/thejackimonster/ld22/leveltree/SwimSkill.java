package de.thejackimonster.ld22.leveltree;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.level.tile.Tile;

public class SwimSkill extends SpecialSkill {

	public SwimSkill(String s, int x, int y, Skill parent, Item item, int i) {
		super(s, x, y, parent, item, i);
	}

	@Override
	public void use(Player player) {
		Tile tile = player.level.getTile(player.x >> 4, player.y >> 4);
		if(tile == Tile.water || tile == Tile.lava) {
			if (player.tickTime % 60 == 0) {
				if (player.stamina > 0) {
					if (!player.energy && !player.walkoverwater){
						if(this.level == 0) {
							player.stamina++;
						} else if(this.level == 1) {
							player.walkoverwater = true;
						}
					}
				}
			}
		}
	}

	@Override
	public void playerUse(Player player) {
		//
	}

	@Override
	public int getAttack() {
		return 0;
	}

}
