package de.thejackimonster.ld22.leveltree;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.item.Item;

public class StaminaSkill extends Skill{

	private int stamina;

	public StaminaSkill(String name, int x, int y, Skill parent, Item item, int i) {
		super(name, x, y, parent, item);
		stamina = i;
	}

	@Override
	public void use(Player player) {
		if(onTick()) {
			if (player.stamina < player.maxStamina) player.stamina += this.stamina;
		}
	}

	public int needPoints() {
		return stamina;
	}

}
