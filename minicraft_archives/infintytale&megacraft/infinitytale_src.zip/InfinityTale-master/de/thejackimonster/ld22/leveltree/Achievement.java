package de.thejackimonster.ld22.leveltree;

import java.util.ArrayList;
import java.util.List;

import com.mojang.ld22.Game;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.item.Item;

public class Achievement {

	public static List<Achievement> achievementList = new ArrayList<Achievement>();

	public static Achievement newWorld = new Achievement("New World", "You have created a   world in InfinityTale!", null, Item.apple);
	public static Achievement openInventory = new Achievement("Open Inventory", "You have openedyour inventory!", newWorld, Item.chest);
	public static Achievement crafting = new Achievement("Workbench", "You have set   your workbench!", openInventory, Item.workbench);
	public static Achievement wood = new Achievement("In The Forest", "You have collectedyour first wood!  ", newWorld, Item.wood);

	public static Achievement craftPickaxe = new Achievement("Pickaxe", "You have crafted     your first pickaxe!  ", crafting, Item.woodenPickaxe);
	public static Achievement craftAxe = new Achievement("Axe", "You have craftedyour first axe! ", crafting, Item.woodenAxe);
	public static Achievement craftHoe = new Achievement("Hoe", "You have craftedyour first hoe! ", crafting, Item.woodenHoe);
	public static Achievement craftHammer = new Achievement("Hammer", "You have crafted your first hammer!", crafting, Item.woodenHammer);
	public static Achievement craftShovel = new Achievement("Shovel", "You have crafted your first shovel!", crafting, Item.woodenShovel);
	public static Achievement craftSword = new Achievement("Sword", "You have crafted your first sword!", crafting, Item.woodenSword);

	public static Achievement creeperNoob = new Achievement("Creeper!!!", "A creeper explored   with you to the death!", newWorld, Item.tnt);

	public Achievement(String name, String msg, Achievement parent, Item item) {
		title = name;
		text = msg;
		need = parent;
		itemc = item;
		done = false;
		achievementList.add(this);
	}

	public void renderIcon(Screen screen, int x, int y) {
		if(itemc != null) itemc.renderIcon(screen, x, y);
	}

	public boolean Done(Game game) {
		boolean flag = done;
		if(need != null) {
			if(need.Done(game)) done = true;
		} else {
			done = true;
		}
		if(done && (!flag)) {
			game.setMenu(new AchievementMenu(this));
		}
		return done;
	}

	public boolean isDone() {
		return done;
	}

	public final String title;
	public final String text;
	private final Achievement need;
	private final Item itemc;
	private boolean done;

}
