package de.thejackimonster.ld22.leveltree;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.screen.Menu;
import com.mojang.ld22.screen.TitleMenu;
import com.mojang.ld22.sound.Sound;

import de.thejackimonster.ld22.options.IngameMenu;
import de.thejackimonster.ld22.options.OptionsMenu;
import de.thejackimonster.ld22.options.mod_options_ingamemenu;

public class AchievementListMenu extends Menu {

	public int offA;
	public int selected;
	public final int size = 10;
	public boolean ingame;

	public AchievementListMenu(boolean flag) {
		selected = 0;
		offA = 0;
		ingame = flag;
	}

	public void tick() {
		if(input.up.clicked || input.down.clicked) {
			Sound.toogle.play();
			if(input.up.clicked) selected--;
			if(input.down.clicked) selected++;
			if(selected < 0) {
				if(offA > 0) {
					selected = size-1;
					offA--;
				} else {
					selected = 0;
				}
			}
			if(selected >= size) {
				if(offA < Achievement.achievementList.size()/size) {
					selected = 0;
					offA++;
				} else {
					selected = size-1;
				}
			}
			if(offA < 0) offA = 0;
			if(offA > Achievement.achievementList.size()/size) offA = Achievement.achievementList.size()/size - 1;
			if(offA*size+selected >= Achievement.achievementList.size()) selected--;
		}
		if(mod_options_ingamemenu.key_esc.clicked) {
			Sound.select.play();
			game.setMenu(new OptionsMenu(ingame));
		}
	}

	public void render(Screen screen) {
		screen.clear(0);
		int xx = 8*3;
		int yy = 8*5;
		int s = size;
		for(int i = 0; i < s; i++) {
			if(offA*s+i < Achievement.achievementList.size()) {
				int col = Color.get(-1, 555, 555, 555);
				if(!Achievement.achievementList.get(offA*s+i).isDone()) {
					col = Color.get(-1, 333, 333, 333);
				}
				String msg = Achievement.achievementList.get(offA*s+i).title;
				if(i == selected) {
					msg = ">  " + msg;
					String acm = Achievement.achievementList.get(offA*s+i).text;
					String msg1 = "";
					for(int j = 0; j < acm.length()/2; j++) msg1 = msg1 + String.valueOf(acm.charAt(j));
					Font.draw(msg1, screen, xx-1*8, yy-3*8, col);
					msg1 = "";
					for(int j = acm.length()/2; j < acm.length(); j++) msg1 = msg1 + String.valueOf(acm.charAt(j));
					Font.draw(msg1, screen, xx-1*8, yy-2*8, col);
				} else {
					msg = "   " + msg;
				}
				Achievement.achievementList.get(offA*s+i).renderIcon(screen, xx+2*8, yy+i*9);
				Font.draw(msg, screen, xx, yy+i*9, col);
			}
		}
	}

}
