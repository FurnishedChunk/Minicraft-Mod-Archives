package de.thejackimonster.ld22.leveltree;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.item.Item;

public class XPSkill extends Skill {

	private static int xp;

	public XPSkill(String s, int x, int y, Skill parent, Item item, int i) {
		super(s, x, y, parent, item);
		xp = i;
	}

	@Override
	public void use(Player player) {
		player.exp += xp;
	}

}
