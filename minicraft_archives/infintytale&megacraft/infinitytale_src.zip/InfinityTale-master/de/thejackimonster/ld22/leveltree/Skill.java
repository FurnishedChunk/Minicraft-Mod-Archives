package de.thejackimonster.ld22.leveltree;

import java.util.ArrayList;
import java.util.List;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.item.Item;

import de.thejackimonster.ld22.weapons.mod_weapons;

public abstract class Skill {

	public static List<Skill> skills = new ArrayList<Skill>();

	public static Skill health1 = new HealthSkill("Bread-time", 2, 1, null, Item.bread, 1);
	public static Skill health2 = new HealthSkill("Apples from paradise", 1, 1, health1, Item.apple, 2);
	public static Skill health3 = new HealthSkill("A heart for a hero", 1, 1, health2, Item.heartcontainer, 3);

	public static Skill stamina1 = new StaminaSkill("A little man", 2, 4, null, Item.powerglove, 1);
	public static Skill stamina2 = new StaminaSkill("Robin Hood", 1, 1, stamina1, Item.stonebow, 2);
	public static Skill stamina3 = new StaminaSkill("The king comes home", 1, 1, stamina2, Item.gembow, 3);

	public static Skill swimming1 = new SwimSkill("Dark waters..", 0, 3, stamina1, Item.ironbukket, 0);
	public static Skill swimming2 = new SwimSkill("I don't swim, I go!", 1, 1, swimming1, Item.water, 1);

	public static Skill attack1 = new AttackSkill("Damage!", 2, 9, null, Item.stoneSword, 0);
	public static Skill attack2 = new AttackSkill("I won't hurt you..", 1, 1, attack1, Item.ironAxe, 1);
	public static Skill attack3 = new AttackSkill("Knock knock, who's.. dead?", 1, 1, attack2, Item.gemHammer, 2);

	public static Skill weapon1 = new WeaponSkill("Angry Arrow", -1, 7, stamina2, Item.stonebow, 0);
	public static Skill weapon2 = new WeaponSkill("Compass-Bow", 1, 1, weapon1, Item.gembow, 1);
	public static Skill weapon3 = new WeaponSkill("Special-Regeneration++", -2, 8, stamina3, Item.powerglove, 2);
	public static Skill weapon4 = new WeaponSkill("Booooomeerr..rraaangg", 0, 11, stamina1, mod_weapons.boome_rang, 3);

	protected boolean done;
	protected int lvl;
	protected String name;
	protected int Xpos;
	protected int Ypos;
	protected Skill parent;
	protected Item item;

	public Skill(String s, int x, int y, Skill parent, Item item) {
		this.name = s;
		this.Xpos = x;
		this.Ypos = y;
		if(parent != null) {
			this.Xpos += parent.Xpos;
			this.Ypos += parent.Ypos;
		}
		this.done = false;
		this.lvl = 0;
		this.parent = parent;
		this.item = item;
		addSkill(this, s);
	}

	private static void addSkill(Skill skill, String name) {
		boolean flag = true;
		for(int i = 0; i < skills.size(); i++) {
			if(skills.get(i).getName().equalsIgnoreCase(name)) {
				flag = false;
			}
		}
		if(flag) {
			skills.add(skill);
		}
	}

	public int needPoints() {
		return 1;
	}

	public boolean Done(int points) {
		if(points >= needPoints()) {
			this.done = true;
		}
		return this.done;
	}

	public int getLevel() {
		return this.lvl;
	}

	public int MAXLevel() {
		return 1;
	}

	private int tick = 0;

	public boolean onTick() {
		tick++;
		if(tick > 600) {
			tick = 0;
			return true;
		}
		return false;
	}

	public void LevelUp() {
		if(this.lvl < MAXLevel()) this.lvl++;
	}

	public abstract void use(Player player);

	public Item getRenderItem() {
		return this.item;
	}

	public String getName() {
		return this.name;
	}

	public Skill getParent() {
		return this.parent;
	}

	public boolean isCompleteDone() {
		return (getLevel() == MAXLevel() && done);
	}

	public int getX() {
		return this.Xpos;
	}

	public int getY() {
		return this.Ypos;
	}

}
