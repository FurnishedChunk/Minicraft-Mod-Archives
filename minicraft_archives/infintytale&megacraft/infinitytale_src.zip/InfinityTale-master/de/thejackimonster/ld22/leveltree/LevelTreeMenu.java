package de.thejackimonster.ld22.leveltree;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.screen.Menu;
import com.mojang.ld22.sound.Sound;

public class LevelTreeMenu extends Menu{
    private int ticks = 0;
	private int choosed = 0;


	public LevelTreeMenu() {
		ticks = -2;
	}

	public void tick() {
		ticks++;
		if(input.up.clicked) {
			toggleItem(-1);
		} else
		if(input.down.clicked) {
			toggleItem(1);
		} else
		if(input.attack.clicked || input.menu.clicked) {
			Skill(game.player);
		} else
		if(mod_leveltree.key_e.clicked && ticks >= 0) {
			Sound.toogle.play();
			game.setMenu(null);
		}
	}

	public void Skill(Player player) {
		Sound.select.play();
		if(player != null) {
			int points = player.plevel;
			if(!Skill.skills.get(choosed).isCompleteDone()) {
				if(Skill.skills.get(choosed).Done(points)) {
					player.plevel -= Skill.skills.get(choosed).needPoints();
					Skill.skills.get(choosed).LevelUp();
				}
			}
		}
	}

	public void toggleItem(int i) {
		choosed += i;
		control();
		boolean end = false;
		while((Skill.skills.get(choosed).parent != null) && (!end)) {
			if(!Skill.skills.get(choosed).parent.isCompleteDone()) {
				choosed += i;
				control();
			} else {
				end = true;
			}
		}
		Sound.toogle.play();
	}

	public void control() {
		if(choosed < 0) {
			choosed = Skill.skills.size()-1;
		} else
		if(choosed >= Skill.skills.size()) {
			choosed = 0;
		}
	}

	public void render(Screen screen) {
		control();
		screen.clear(Color.get(000, 000, 000, 000));
		String text = "Skillpoints: " + String.valueOf(game.player.plevel) + " ";
		Font.draw(text, screen, screen.w - text.length()*8, 0, Color.get(-1, 111, 222, 333));
		for(int i = 0; i < Skill.skills.size(); i++) {
			String msg = Skill.skills.get(i).getName();
			int x = Skill.skills.get(i).getX()*8;
			int y = Skill.skills.get(i).getY()*8;
			Skill.skills.get(i).getRenderItem().renderIcon(screen, x, y);
			int col = Color.get(-1, 333, 333, 333);
			if(Skill.skills.get(i).parent != null) {
				if(!Skill.skills.get(i).parent.isCompleteDone()) {
					col = Color.get(-1, 111, 111, 111);
				}
			}
			if(Skill.skills.get(i).isCompleteDone()) {
				col = Color.get(-1, 555, 555, 555);
			}
			Font.draw(msg, screen, x + 8, y, col);
			if(choosed == i) {
				Font.draw(">", screen, x - 8, y, Color.get(-1, 111, 222, 333));
			}
		}
	}
}
