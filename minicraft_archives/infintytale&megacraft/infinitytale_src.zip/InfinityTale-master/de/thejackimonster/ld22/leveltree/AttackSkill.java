package de.thejackimonster.ld22.leveltree;

import java.util.List;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.Mob;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.item.Item;

public class AttackSkill extends SpecialSkill {

	public AttackSkill(String s, int x, int y, Skill parent, Item item, int i) {
		super(s, x, y, parent, item, i);
	}

	@Override
	public void use(Player player) {
		if(this.level == 2) {
			List<Entity> list = player.level.getEntities(player.x-1, player.y-1, player.x+1, player.y+1);
			for(int i = 0; i < list.size(); i++) {
				if((list.get(i) instanceof Mob) && (!(list.get(i) instanceof Player))) {
					((Mob)list.get(i)).hurt(player, player.getAttackDamage(list.get(i)), player.dir);
				}
			}
		}
	}

	@Override
	public void playerUse(Player player) {
		//
	}

	@Override
	public int getAttack() {
		return this.level*2;
	}

}
