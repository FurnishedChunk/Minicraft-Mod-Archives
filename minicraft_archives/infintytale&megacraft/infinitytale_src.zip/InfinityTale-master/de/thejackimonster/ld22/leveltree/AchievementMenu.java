package de.thejackimonster.ld22.leveltree;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.screen.FreeMenu;

public class AchievementMenu extends FreeMenu {

	private final Achievement acm;
	private int tickc;
	private final int sec;

	public AchievementMenu(Achievement achievement) {
		sec = 5;
		acm = achievement;
	}

	public void tick() {
		tickc++;
		if ((tickc / 60 == sec && tickc % 60 == 0) || input.attack.clicked || input.menu.clicked) {
			game.setMenu(null);
		}
	}


	public void render(Screen screen) {
		int w = 28*8;
		int h = 4*8;
		int x = screen.w/2 - w/2;
		int y = screen.h - h;
		Font.renderFrame(screen, acm.title, x/8, y/8, (x+w)/8, (y+h)/8);
		acm.renderIcon(screen, x+8, y+h/2);
		String msg = "";
		for(int i = 0; i < acm.text.length()/2; i++) msg = msg + String.valueOf(acm.text.charAt(i));
		Font.draw(msg, screen, x+8+10, y+h/3, Color.get(-1, 111, 222, 333));
		msg = "";
		for(int i = acm.text.length()/2; i < acm.text.length(); i++) msg = msg + String.valueOf(acm.text.charAt(i));
		Font.draw(msg, screen, x+8+10, y+h/3*2, Color.get(-1, 111, 222, 333));
	}
}
