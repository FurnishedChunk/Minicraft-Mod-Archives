package de.thejackimonster.ld22.leveltree;

import java.awt.event.KeyEvent;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.sound.Sound;

import de.thejackimonster.ld22.loadandsave.WorldSaveLoadMenu;
import de.thejackimonster.ld22.modloader.BaseMod;
import de.thejackimonster.ld22.modloader.KeyBinding;
import de.thejackimonster.ld22.options.OptionFile;

public class mod_leveltree extends BaseMod {

	public static final KeyBinding key_e = new KeyBinding();
	public static int coolDownSkill;

	@Override
	public void load() {
	}

	public void KeyboardEvent(int key, boolean pressed) {
		if(key == OptionFile.keys[10]) key_e.toggle(pressed);
	}

	private int tick, ticks;

	public void onTickByPlayer(Player player) {
		tick++;
		ticks++;
		boolean cool = false;
		if(player != null && tick > 3) {
			if(player.game.menu == null) {
				if(key_e.clicked) {
					player.game.setMenu(new LevelTreeMenu());
					Sound.toogle.play();
					tick = 0;
				}
			}
		}
		for(int i = 0; i < Skill.skills.size(); i++) {
			if(Skill.skills.get(i).isCompleteDone()) {
				Skill.skills.get(i).use(player);
				if(Skill.skills.get(i) instanceof WeaponSkill) cool = true;
			}
		}
		
		if(!cool) return;
		
		if(Skill.weapon3.isCompleteDone() && ticks % 59 == 0) coolDownSkill--;
		if(ticks % 60 == 0) {
			coolDownSkill--;
		}
		if(coolDownSkill < 0) coolDownSkill = 0;
		if(coolDownSkill > 60) coolDownSkill = 60;
	}

	@Override
	public String getVersion() {
		return "Alpha";
	}

}
