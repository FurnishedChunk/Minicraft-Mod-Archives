package de.thejackimonster.ld22.leveltree;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.item.Item;

public abstract class SpecialSkill extends Skill {

	protected int level;

	public SpecialSkill(String s, int x, int y, Skill parent, Item item, int i) {
		super(s, x, y, parent, item);
		this.level = i;
	}

	public abstract void use(Player player);

	public abstract int getAttack();

	public abstract void playerUse(Player player);

	public int needPoints() {
		return level+1;
	}

}
