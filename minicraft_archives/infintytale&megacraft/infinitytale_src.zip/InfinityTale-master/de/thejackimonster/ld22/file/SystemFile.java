package de.thejackimonster.ld22.file;

import java.io.File;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;
import java.util.Scanner;

import com.mojang.ld22.Game;

public class SystemFile {

	public boolean applet;
	public String FileName;
	private Formatter formatter;
	private Scanner scanner;
	public String Text;
	public List<String> Lines = new ArrayList<String>();
	private int filePos;
	private boolean end;
	public boolean isNew;

	public SystemFile(String s, Game game) {
		FileName = s;
		Text = "";
		filePos = 0;
		end = false;
		isNew = false;
		applet = game.isApplet;
	}

	public void Create() {
		if(applet) return;
		System.out.println("Create File: " + FileName);
		File file = new File(FileName);
		if(!file.exists()) {
			try {
				file.createNewFile();
				isNew = true;
			} catch (Exception e) {
				System.out.println("You have an error! -Create()");
			}
		}
	}

	public void Reset() {
		if(applet) return;
		try {
			scanner = new Scanner(new File(FileName));
		} catch (Exception e) {
			System.out.println("You have an error! -Reset()");
		}
		filePos = 0;
		end = false;
	}

	public void Rewrite() {
		if(applet) return;
		try {
			formatter = new Formatter(FileName);
		} catch (Exception e) {
			System.out.println("You have an error! -Rewrite()");
		}
		filePos = 0;
		end = false;
	}

	public void Read() {
		if(applet) return;
		if(scanner != null) {
			Text = "";
			int i = 0;
			while(scanner.hasNext()) {
				Lines.add(scanner.next());
				if(i > 0) {
					Text = Text + " ";
				}
				Text = Text + Lines.get(i);
				i++;
			}
		}
	}

	public String ReadLn() {
		if(applet) return "";
		String s = "0";
		if(scanner != null) {
			Read();
			if(filePos < Lines.size()) {
				s = Lines.get(filePos);
				filePos++;
			} else {
				end = true;
			}
		}
		if(filePos == Lines.size()) {
			end = true;
		}
		return s;
	}

	public void Write() {
		if(applet) return;
		if(formatter != null) {
			for(int i = 0; i < Lines.size(); i++) {
				if(i > 0) {
					Text = Text + " ";
				}
				Text = Text + Lines.get(i);
			}
			formatter.format("%s", Text);
		}
	}

	public void WriteLn(String s) {
		if(applet) return;
		if(formatter != null) {
			Lines.add(s);
			filePos++;
		}
	}

	public boolean EndOfFile() {
		if(applet) return false;
		return end;
	}

	public void Close() {
		if(applet) return;
		if(formatter != null) {
			formatter.close();
		}
		if(scanner != null) {
			scanner.close();
		}
	}

}
