package de.thejackimonster.ld22.loadandsave;

import com.mojang.ld22.Game;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.screen.Menu;
import com.mojang.ld22.screen.WorldMenu;
import com.mojang.ld22.sound.Sound;

import de.thejackimonster.ld22.file.SystemFile;

public class WorldSaveLoadMenu extends Menu {
	private int tick = 0;

	public WorldSaveLoadMenu() {
	}

	public void tick() {
		tick++;
		if(tick > 600) {
			game.setMenu(null);
		}
	}

	public void saveMap(Game game) {
		if(game != null ) {
		 if(!game.issavingmap) {
          SaveLevel save = new SaveLevel("world", game);
          System.out.println("[SYSTEM][I/O] Saving map");
          save.start();
		 }
		}
	}

	public void loadMap(Game game) {
       LoadLevel load = new LoadLevel("world", game);
       System.out.println("[SYSTEM][I/O] Loading map");
       load.start();
	}

	public void render(Screen screen) {
		String msg = "Save map..";
		int col = Color.get(-1, 222, 222, 222);
		Font.draw(msg, screen, (screen.w - msg.length() * 8) / 2, (screen.h - 8) / 2, col);
	}
}