package de.thejackimonster.ld22.loadandsave;

import com.mojang.ld22.Game;
import com.mojang.ld22.entity.Chest;
import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.Furniture;
import com.mojang.ld22.entity.Inventory;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.item.FurnitureItem;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.item.ResourceItem;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.level.tile.Tile;
import com.mojang.ld22.sound.Sound;

import de.thejackimonster.ld22.file.SystemFile;
import de.thejackimonster.ld22.leveltree.Skill;
import de.thejackimonster.ld22.matrix.Matrix;

public class LoadLevel extends Thread{

	public static String path;
    public Game game;
	public LoadLevel(String s,Game game) {
		this.path = s;
        this.game = game;
	}

	
	public void run() {
		if(game.isApplet) return;
		game.isloadingmap = true;
		Sound.test.play();
		SystemFile file = new SystemFile("world", game);
		file.Create();
		boolean flag = file.isNew;
		file.Close();
		if((!flag) && (game != null)) {
			int d = game.player.level.depth;
			LoadLevel llevel = this;
			llevel.loadPlayer(game);
			llevel.loadSkills();
			for(int i = 0; i < game.levels.length; i++) {
				game.levels[i] = llevel.getLevel(game, i);
			}
			game.changeLevel(0);
		} else
		if(flag && game != null) {
		//saveMap(game);
		}
		game.setMenu(null);
		game.isloadingmap = false;
	}
	
	public void loadSkills() {
		if(game.isApplet) return;
		SystemFile file = new SystemFile(this.path + "_skills", game);
		file.Create();
		file.Reset();
		int i = 0;
		while(!file.EndOfFile()) {
			int x = Integer.parseInt(file.ReadLn());
			if(i < Skill.skills.size()) {
				if(x > 0) {
					Skill.skills.get(i).Done(Skill.skills.get(i).needPoints());
					while(Skill.skills.get(i).getLevel() < x && (!Skill.skills.get(i).isCompleteDone())) {
						Skill.skills.get(i).LevelUp();
					}
				}
			}
			i++;
		}
		file.Close();
	}

	public void loadPlayer(Game game) {
		if(game.isApplet) return;
		game.player.inventory.items.clear();
		game.player.inventory = new Inventory();
		SystemFile file = new SystemFile(this.path + "_player", game);
		file.Create();
		file.Reset();
		game.player.x = Integer.parseInt(file.ReadLn());
		game.player.y = Integer.parseInt(file.ReadLn());
		game.respawnx = Integer.parseInt(file.ReadLn());
     	game.respawny = Integer.parseInt(file.ReadLn());
		game.player.health = Integer.parseInt(file.ReadLn());
		game.player.stamina = Integer.parseInt(file.ReadLn());
		game.player.plevel = Integer.parseInt(file.ReadLn());
		game.player.exp = Integer.parseInt(file.ReadLn());
		game.lightlvl = Integer.parseInt(file.ReadLn());
		game.currentLevel = Integer.parseInt(file.ReadLn());
		while(!file.EndOfFile()) {
			Item item = Item.items.get(Integer.parseInt(file.ReadLn()));
			if (item instanceof ResourceItem) {
				ResourceItem resItem = new ResourceItem(((ResourceItem) item).resource);
				game.player.inventory.add(resItem);
			} else if (item instanceof FurnitureItem) {
				FurnitureItem furItem = null;
				Entity ent = null;
				try {
					ent = Entity.entities.get(Entity.getIDOfName(item.getName())).getClass().newInstance();
				} catch (Exception e) {
					e.printStackTrace();
				}
				if(ent != null) {
					if(ent instanceof Furniture) {
						Furniture fur = (Furniture)ent;
						furItem = new FurnitureItem(fur);
					}
				} else {
					furItem = (FurnitureItem)item;
				}
				if(furItem != null) {
					game.player.inventory.add(furItem);
				}
			} else {
				game.player.inventory.add(item);
			}
		}
		file.Close();
	}

	public Level getLevel(Game game, int c) {
		if(game.isApplet) return null;
		SystemFile file = new SystemFile(this.path + String.valueOf(c), game);
		file.Create();
		file.Reset();
		int w = Integer.parseInt(file.ReadLn());
		int h = Integer.parseInt(file.ReadLn());
		int l = Integer.parseInt(file.ReadLn());
		int p = Integer.parseInt(file.ReadLn());
		Level level = null;
		if(p == 5) {
			level = new Matrix(false, game,w, h, l, null,w/64,2,2,2,2);
		} else {
			level = new Matrix(false, game,w, h, l, game.player.game.levels[p],w/64,2,2,2,2);
		}
		for(int i = 0; i < w; i++) {
			for(int j = 0; j < h; j++) {
				level.setTile(i, j, Tile.tiles[Integer.parseInt(file.ReadLn())], 0);
			}
		}
		file.Close();
		SystemFile file1 = new SystemFile(this.path + String.valueOf(c) + "_chests", game);
		file1.Create();
		file1.Reset();
		file = new SystemFile(this.path + String.valueOf(c) + "_entities", game);
		file.Create();
		file.Reset();
		while(!file.EndOfFile()) {
			int x = Integer.parseInt(file.ReadLn());
			int y = Integer.parseInt(file.ReadLn());
			int type = Entity.getIDOfName(file.ReadLn());
			if(Entity.entities.get(type) instanceof Furniture) {
				try {
					Entity entity = Entity.entities.get(type).getClass().newInstance();
					entity.x = x;
					entity.y = y;
					level.add(entity);
					if(entity instanceof Chest) {
						Chest chest = (Chest) entity;
						SystemFile file2 = new SystemFile(this.path + String.valueOf(c) + "_chest" + file1.ReadLn(), game);
						file2.Create();
						file2.Reset();
						while(!file2.EndOfFile()) {
							Item item = Item.items.get(Integer.parseInt(file2.ReadLn()));
							if (item instanceof ResourceItem) {
								ResourceItem resItem = new ResourceItem(((ResourceItem) item).resource);
								chest.inventory.add(resItem);
							} else if (item instanceof FurnitureItem) {
								FurnitureItem furItem = null;
								Entity ent = null;
								try {
									ent = Entity.entities.get(Entity.getIDOfName(item.getName())).getClass().newInstance();
								} catch (Exception e) {
									e.printStackTrace();
								}
								if(ent != null) {
									if(ent instanceof Furniture) {
										Furniture fur = (Furniture)ent;
										furItem = new FurnitureItem(fur);
									}
								} else {
									furItem = (FurnitureItem)item;
								}
								if(furItem != null) {
									game.player.inventory.add(furItem);
								}
							} else {
								chest.inventory.add(item);
							}
						}
						file2.Close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		file.Close();
		file1.Close();
		
		return level;
	}
}
