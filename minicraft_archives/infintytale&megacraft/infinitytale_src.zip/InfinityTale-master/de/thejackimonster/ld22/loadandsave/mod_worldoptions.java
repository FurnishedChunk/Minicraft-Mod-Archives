package de.thejackimonster.ld22.loadandsave;

import java.awt.event.KeyEvent;
import java.util.Random;

import com.mojang.ld22.Game;
import com.mojang.ld22.entity.ItemEntity;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.item.ResourceItem;
import com.mojang.ld22.screen.Menu;
import com.mojang.ld22.sound.Sound;

import de.thejackimonster.ld22.modloader.BaseMod;
import de.thejackimonster.ld22.modloader.KeyBinding;
import de.thejackimonster.portal.PortalItem;
import de.thejackimonster.portal.PortalTile;

public class mod_worldoptions extends BaseMod{

	public static final KeyBinding key_f = new KeyBinding();
	public static final KeyBinding key_q = new KeyBinding();

	@Override
	public void load() {
	}

	public void KeyboardEvent(int key, boolean pressed) {
		if(key == KeyEvent.VK_F) key_f.toggle(pressed);
		if(key == KeyEvent.VK_Q) key_q.toggle(pressed);
	}

	private int tick;

	public void onTickByPlayer(Player player) {
		tick++;
		if(player != null && tick > 3) {
			if(player.game.menu == null) {
				if(key_f.clicked && (!player.game.isApplet)  && (!player.game.isloadingmap)) {
					new WorldSaveLoadMenu().saveMap(player.game);
					//player.game.setMenu(new WorldSaveLoadMenu());
					Sound.special.play();
					tick = 0;
				}
			}
			Item item = player.activeItem;
			if(key_q.clicked && item != null) {
				if(item instanceof PortalItem) {
					PortalTile.useCanon();
				} else {
					if(player.activeItem instanceof ResourceItem) {
						if(player.inventory.count(player.activeItem) > 0) {
							player.inventory.removeResource(((ResourceItem)player.activeItem).resource, 1);
							if(player.inventory.count(player.activeItem) <= 0) {
								player.activeItem = null;
							}
						} else {
							player.activeItem = null;
						}
					} else {
						player.activeItem = null;
					}
					int drop = (new Random().nextInt(4)+1 + new Random().nextInt(4)+1);
					drop *= 2.5;
					int xx = 0;
					int yy = 0;
					switch(player.dir) {
					case 0:
						yy = 1;
						break;
					case 1:
						yy = -1;
						break;
					case 2:
						xx = -1;
						break;
					case 3:
						xx = 1;
						break;
					default:
	                	break;
					}
					player.level.add(new ItemEntity(item, player.x + xx*drop, player.y + yy*drop));
					Sound.pickup.play();
					tick = 0;
				}
			}
		}
	}

	@Override
	public String getVersion() {
		return "Beta";
	}
}
