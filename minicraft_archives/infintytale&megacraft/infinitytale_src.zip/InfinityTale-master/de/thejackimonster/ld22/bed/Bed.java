package de.thejackimonster.ld22.bed;

import java.util.ArrayList;
import java.util.List;

import com.mojang.ld22.entity.Furniture;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.entity.particle.TextParticle;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.item.ToolItem;
import com.mojang.ld22.item.ToolType;
import com.mojang.ld22.level.tile.Tile;

public class Bed extends Furniture {

	public boolean on = false;
	private int ticks = 0;
	public int tickTime = 0;

	public Bed() {
		super("Bed");
		col = Color.get(-1, Color.getRGB(80, 44, 22), Color.getRGB(112, 7, 7), Color.getRGB(253, 253, 253));
		sprite = 8;
	}

	public boolean use(Player player, int attackDir) {
		player.game.respawnx = this.x;
		player.game.respawny = this.y;
		if(player.game.lightlvl < 3 && !player.game.rising) {
			player.game.lightlvl = 2;
			player.game.rising = true;
			
			return true;
		}
		return false;
	}

}

