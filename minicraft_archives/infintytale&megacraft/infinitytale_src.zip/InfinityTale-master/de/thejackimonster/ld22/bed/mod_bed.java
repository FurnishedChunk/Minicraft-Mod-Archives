package de.thejackimonster.ld22.bed;

import com.mojang.ld22.crafting.FurnitureRecipe;
import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.item.FurnitureItem;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.item.resource.Resource;

import de.thejackimonster.ld22.modloader.BaseMod;
import de.thejackimonster.ld22.modloader.ModLoader;

public class mod_bed extends BaseMod {

	public static Entity useBed = new Bed();

	public static Item bed = new FurnitureItem(new Bed());

	static {
		try {
			ModLoader.wRecipes.add(new FurnitureRecipe(Bed.class).addCost(Resource.cloth, 10).addCost(Resource.wood, 10));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void load() {
	}

	@Override
	public String getVersion() {
		return "Alpha";
	}

}
