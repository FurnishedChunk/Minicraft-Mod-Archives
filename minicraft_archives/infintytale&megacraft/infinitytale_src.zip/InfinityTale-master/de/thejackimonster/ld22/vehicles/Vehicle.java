package de.thejackimonster.ld22.vehicles;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.Mob;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.entity.Torch;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.item.FurnitureItem;
import com.mojang.ld22.item.PowerGloveItem;
import com.mojang.ld22.level.tile.Tile;

public class Vehicle extends Entity {

	protected int pushTime = 0;
	private int pushDir = -1;
	public int col, sprite;
	public final Tile[] canMoveOn;
	protected int mx, my;
	public Mob mover = null;

	public Vehicle(String name, int sp, int c, Tile... tiles) {
		super(name);
		sprite = sp;
		col = c;
		canMoveOn = tiles;
	}

	public void tick() {
		if(mover != null) {
			if(mover.removed || mover.health <= 0) {
				mover = null;
			}
		}
		if(mover instanceof Player) {
			playerControl(((Player)mover));
		}
		
		if (pushDir == 0) {
			my = 1;
		}
		if (pushDir == 1) {
			my = -1;
		}
		if (pushDir == 2) {
			mx = -1;
		}
		if (pushDir == 3) {
			mx = 1;
		}
		
		if(mx != 0 || my != 0) {
			if(!move(mx, my)) {
				mx = 0;
				my = 0;
			}
			if(x != 0 && y != 0) {
				drive(x/16, y/16);
			} else {
				drive(0, 0);
			}
		}

		pushDir = -1;
		if (pushTime > 0) pushTime--;
	}

	public void playerControl(Player p) {
		if(p.game.input.up.clicked) my = -1;
		if(p.game.input.down.clicked) my = 1;
		if(p.game.input.left.clicked) mx = -1;
		if(p.game.input.right.clicked) mx = 1;
	}

	public void render(Screen screen) {
		screen.render(x - 8, y - 8 - 4, sprite * 2 + 8 * 32, col, 0);
		screen.render(x - 0, y - 8 - 4, sprite * 2 + 8 * 32 + 1, col, 0);
		screen.render(x - 8, y - 0 - 4, sprite * 2 + 8 * 32 + 32, col, 0);
		screen.render(x - 0, y - 0 - 4, sprite * 2 + 8 * 32 + 33, col, 0);
	}

	public void drive(int xt, int yt) {
		boolean flag = false;
		for(int i = 0; i < canMoveOn.length; i++) {
			if(level.getTile(xt, yt).id == canMoveOn[i].id) {
				if(mx < 0 && mx > -2) mx--;
				if(mx < 0 && mx < 2) mx++;
				if(mx > 0 && my > -2) my--;
				if(mx > 0 && my < 2) my++;
				flag = true;
			}
		}
		if(!flag) {
			mx = 0;
			my = 0;
		}
	}

	public boolean use(Player player, int attackDir) {
		if(player.toDrive == null && mover == null) {
			player.toDrive = this;
			mover = player;
		} else {
			player.toDrive = null;
			mover = null;
		}
		return true;
	}

	public boolean blocks(Entity e) {
		return true;
	}

	protected void touchedBy(Entity entity) {
		if (entity instanceof Mob && pushTime == 0) {
			if(((Mob) entity).toDrive != this) {
				pushDir = ((Mob) entity).dir;
				pushTime = 9;
				if(!(entity instanceof Player) && mover == null) {
					((Mob) entity).toDrive = this;
					mover = ((Mob) entity);
				}
			}
		}
	}

}
