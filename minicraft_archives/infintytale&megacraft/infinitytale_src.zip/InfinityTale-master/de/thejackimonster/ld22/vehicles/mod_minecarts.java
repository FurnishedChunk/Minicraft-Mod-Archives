package de.thejackimonster.ld22.vehicles;

import com.mojang.ld22.entity.Entity;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.level.tile.Tile;

import de.thejackimonster.ld22.modloader.BaseMod;

public class mod_minecarts extends BaseMod {

	public static final Entity mineCart = new Minecart();
	public static final Entity Boat = new Boat();

	public static Item minecart = new VehicleItem(new Minecart());
	public static Item boat = new VehicleItem(new Boat());

	@Override
	public void load() {
	}

	public void onTickByPlayer(Player player) {
	}

	@Override
	public String getVersion() {
		return "Alpha";
	}

}
