package de.thejackimonster.ld22.vehicles;

import com.mojang.ld22.entity.ItemEntity;
import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.gfx.Font;
import com.mojang.ld22.gfx.Screen;
import com.mojang.ld22.item.Item;
import com.mojang.ld22.level.Level;
import com.mojang.ld22.level.tile.Tile;

public class VehicleItem extends Item {
	public Vehicle vehicle;
	public boolean placed = false;

	public VehicleItem(Vehicle vehc) {
		super(vehc.name);
		this.vehicle = vehc;
	}

	public int getColor() {
		return vehicle.col;
	}

	public int getSprite() {
		return vehicle.sprite + 10 * 32;
	}

	public void renderIcon(Screen screen, int x, int y) {
		screen.render(x, y, getSprite(), getColor(), 0);
	}

	public void renderInventory(Screen screen, int x, int y) {
		screen.render(x, y, getSprite(), getColor(), 0);
		Font.draw(vehicle.name, screen, x + 8, y, Color.get(-1, 555, 555, 555));
	}

	public void onTake(ItemEntity itemEntity) {
	}

	public boolean canAttack() {
		return false;
	}

	public boolean interactOn(Tile tile, Level level, int xt, int yt, Player player, int attackDir) {
		if (tile.mayPass(level, xt, yt, vehicle)) {
			vehicle.x = xt * 16 + 8;
			vehicle.y = yt * 16 + 8;
			level.add(vehicle);
			placed = true;
			return true;
		}
		return false;
	}

	public boolean isDepleted() {
		return placed;
	}
	
	public String getName() {
		return vehicle.name;
	}
}