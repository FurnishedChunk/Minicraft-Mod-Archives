package de.thejackimonster.ld22.vehicles;

import java.awt.Point;

import com.mojang.ld22.entity.Player;
import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.level.tile.Tile;

public class Minecart extends Vehicle {

	public Point lastTile;

	public Minecart() {
		super("Minecart", 5, Color.get(-1, 453, 234, 230), Tile.hole);
	}

	public void playerControl(Player p) {
	}

	public boolean canSwim() {
		return false;
	}

	public void tick() {
		super.tick();
		int dir = 0;
		boolean[] dirs = new boolean[4];
		dirs[0] = false;
		dirs[1] = false;
		dirs[2] = false;
		dirs[3] = false;
		for(int i = 0; i < canMoveOn.length; i++) {
			if(level.getTile((x)/16 - 1, (y)/16).id == canMoveOn[i].id) {
				dirs[0] = true;
				dir++;
			}
			if(level.getTile((x)/16 + 1, (y)/16).id == canMoveOn[i].id) {
				dirs[1] = true;
				dir++;
			}
			if(level.getTile((x)/16, (y)/16 - 1).id == canMoveOn[i].id) {
				dirs[2] = true;
				dir++;
			}
			if(level.getTile((x)/16, (y)/16 + 1).id == canMoveOn[i].id) {
				dirs[3] = true;
				dir++;
			}
		}
		if(lastTile == null) {
			lastTile = new Point((x)/16, (y)/16);
		}
		
		if(dir > 0 && (mx != 0 || my != 0) && 
		  (lastTile.x == (x)/16 && lastTile.y == (y)/16) ||
		  (pushTime > 0)) {
			for(int i = 0; i < 4; i++) {
				if(dirs[i] && random.nextInt(dir) == 0) {
					lastTile.x = (x)/16;
					lastTile.y = (y)/16;
					if(i == 0) {
						mx = -1;
						my = 0;
						lastTile.x--;
					}
					if(i == 1) {
						mx = 1;
						my = 0;
						lastTile.x++;
					}
					if(i == 2) {
						mx = 0;
						my = -1;
						lastTile.y--;
					}
					if(i == 3) {
						mx = 0;
						my = 1;
						lastTile.y++;
					}
				}
			}
		}
	}

}
