package de.thejackimonster.ld22.vehicles;

import com.mojang.ld22.gfx.Color;
import com.mojang.ld22.level.tile.Tile;

public class Boat extends Vehicle {

	public Boat() {
		super("Boat", 5, Color.get(-1, 351, 324, 534), Tile.water);
	}

	public boolean canSwim() {
		return true;
	}

}
