echo Minicraft Compiler - dillyg10
echo Starting...
cd minicraft_source/src/com/mojang/ld22
javac */*/*.java */*.java *.java
echo Done, run Start_game.sh to start the game!
