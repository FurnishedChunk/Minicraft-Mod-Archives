echo Minicraft Starter - dillyg10
echo Starting game…
cd minicraft_source/src
echo Done have fun :P
java com.mojang.ld22.Game
echo Finished