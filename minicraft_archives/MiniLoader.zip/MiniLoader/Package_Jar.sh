echo Minicraft Jar Packager - dillyg10
echo This will compile ALL of your existing files into a neat jar file, that you can double click on to open.
echo Compiling...
cd minicraft_source/src
jar cvfm Minicraft.jar manifest.txt com/mojang/ld22 ./*.wav ./*.png
echo Sucess! 
echo Go into the src folder, and there will be a minicraft.jar file there, you may rename it to whatever you like
