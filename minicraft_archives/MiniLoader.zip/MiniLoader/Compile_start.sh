echo Minicraft Compiler and Starter - dillyg10
echo Compiling
cd minicraft_source/src/com/mojang/ld22
javac */*/*.java */*.java *.java
echo Done starting game...
cd .. 
cd .. 
cd ..
echo Done have fun :P
java com.mojang.ld22.Game
echo Finished exiting


