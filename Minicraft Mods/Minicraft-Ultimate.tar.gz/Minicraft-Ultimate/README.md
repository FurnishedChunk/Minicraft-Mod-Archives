# Minicraft-Ultimate
The ultimate version of Notch's Minicraft.

See more in the README_IF_YOU_WANT.txt file located in /[any version]/DATA/Source/.

(C) 2017-2018 Deven Blake.

You are free to distribute this, modify it, or do whatever you want as long as you cite the creator(s). If you're in doubt on whether or not you can do something with this code, just do it. I don't care too much about people plaigarising this.

I only made the launcher and packaged Minicraft and its mods. I didn't create nor worked on Minicraft itself or any of the mods and lack the ability to make changes to the individual programs.

Minicraft Ultimate is a launcher for Minicraft, a game by Notch for the Ludum Dare competition. 
It includes:
- the original Minicraft
- the Zyby Minicraft Flash port with saving
- Minicraft Plus
- Minicraft Deluxe
