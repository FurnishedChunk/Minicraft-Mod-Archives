Retrieving these versions of the game was very difficult. First I had to compile the original source code of the Vanilla version
of Minicraft, because there was no compiled file out there. This is very complicated if you've never had to compile a single
line of Java before, and an entire game was written in it. I had to download the JDK installation file from the Java website and
set the JAVA_HOME path in my Windows Environment to begin, and then I needed Apache's terrific ANT program, with a couple edits
to my paths. After I had finally set ANT_HOME and everything, I compiled the "build.xml" file and went to convert my new JAR to
an EXE so it would be usable on Windows. Next, I went on the site "playminicraft.com" and downloaded the Minicraft Plus and
Minicraft Delux mods. The nature of Minicraft modding is that each mod is its own JAR, and simply an edit on the original
source. These were both JARs, of course, and I found that I could convert them with Launch4j, a tool designed for the purpose,
and converted the files. I then went to the Adobe Flash version of Minicraft, created and hosted on "Zyby.com", did "Inspect
Element" in Google Chrome, and downloaded the SWF file. It turned out this SWF was the fourth iteration of the mod, so I
downloaded the other versions as well. These were converted to EXE with the SWF to EXE converter tool created by an anonymous
coder or two (I can't find the people responcible for making it). The icons for these files were unchangeable, however, since
the terrific Resource Hacker couldn't change them without corrupting a couple important lines of code. I finally made the Batch
launcher for the collection, and it was finished.