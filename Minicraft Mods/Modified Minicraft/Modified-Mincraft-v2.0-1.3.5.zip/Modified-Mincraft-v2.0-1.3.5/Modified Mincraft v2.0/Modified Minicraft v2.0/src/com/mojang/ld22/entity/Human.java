package com.mojang.ld22.entity;

public class Human {

}
