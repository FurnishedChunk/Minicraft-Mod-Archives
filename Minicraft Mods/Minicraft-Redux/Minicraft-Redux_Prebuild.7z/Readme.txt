This build is unofficial and is provided on the Minicraft Mod Archive.



For detailed information about this mod, please refer to the following URL.

https://github.com/FurnishedChunk/Minicraft-Mod-Archives/blob/master/Minicraft%20Mods/Minicraft-Redux/readme.md