*Minicraft Texture Pack Editor*
Created By David

Original Description:
This is a modded version of vanilla minicraft to include a little extra feature. When you press U anywhere in the game, it will update the textures in the game with the icons.png image in the same folder.

This allows texture making a lot easier because you can just click off-screen, edit (and save), then just go back in the game and update. No more closing the game and dragging it into the jar file!