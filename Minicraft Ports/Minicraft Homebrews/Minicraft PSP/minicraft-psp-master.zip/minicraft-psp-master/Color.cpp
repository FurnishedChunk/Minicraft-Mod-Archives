//this file is just a stub for Makefile to make Color.o
//look to the Color.h for the actual code
