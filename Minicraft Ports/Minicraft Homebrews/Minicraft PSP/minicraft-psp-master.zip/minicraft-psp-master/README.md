minicraft-psp
=============

Playstation Portable port of Notch's Minicraft

Specs
=====

Made with MinPSPW using oslib_mod in Eclipse.
Follow [this guide](http://www.jetdrone.com/static/articles/pspeclipse.pdf) to setup your workspace to be able to build this for PSP
