//this file is just a stub for Makefile to make ListItem.o
//look to the ListItem.h for the actual code
