#ifndef LISTITEM_H_
#define LISTITEM_H_

#include "../Screen.h"

class ListItem
{
public:
	virtual void renderInventory(Screen * screen, int i, int j)
	{

	}
};

#endif /* LISTITEM_H_ */
