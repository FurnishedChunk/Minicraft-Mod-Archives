//this file is just a stub for Makefile to make Typeable.o
//look to the Typeable.h for the actual code

