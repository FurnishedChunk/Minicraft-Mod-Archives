//this file is just a stub for Makefile to make FurnitureRecipe.o
//look to the FurnitureRecipe.h for the actual code

