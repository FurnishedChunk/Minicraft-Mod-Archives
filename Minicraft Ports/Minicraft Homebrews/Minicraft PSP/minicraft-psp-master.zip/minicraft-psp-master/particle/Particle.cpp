//this file is just a stub for Makefile to make Particle.o
//look to the Particle.h for the actual code
//but there is not much of actual code there
