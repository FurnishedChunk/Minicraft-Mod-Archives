# Minicraft3DS
3DS Homebrew port of Notch's ludum dare game "Minicraft"

Dependencies:

ctrulib by smea: https://github.com/smealum/ctrulib

sf2dlib by xerpi: https://github.com/xerpi/sf2dlib

sfillib by xerpi: https://github.com/xerpi/sfillib

zlib: http://www.zlib.net/

Current Version: Version 1.0

You can do anything with the source code (besides sell it) as long as you give proper credit to the right people. 
If you are going to make a mod of this version, be sure to give credit to Markus "Notch" Perrson because he did create the original game after all.

This source code is subject to a lot of change for better optimization/cleanliness.

Forum thread: https://gbatemp.net/threads/release-beta-minicraft-3ds-homebrew-edition.399295/
