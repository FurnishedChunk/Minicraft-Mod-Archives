#Minicraft for Android

The original game, made by Notch (http://notch.tumblr.com/) can be found here https://s3.amazonaws.com/ld48/ld22/index.html
This is my attempt at porting it to Android.

##To do

- Save & Resume game
- Optimisation so that game run smoother with less memory footprint 
- Testing: not sure if game works at lower levels yet.

##Download
You can download the .apk here:

https://github.com/shawntan/minicraft-android/raw/master/bin/Minicraft.apk
